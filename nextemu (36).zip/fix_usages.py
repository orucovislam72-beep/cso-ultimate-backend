import os
import glob

def process_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()
    
    # replace filePath with path
    content = content.replace('game.filePath', 'game.path')
    content = content.replace('filePath =', 'path =')
    
    # Update AsyncImage in MainActivity.kt
    if "MainActivity.kt" in filepath:
        content = content.replace(
'''                                    val demoId = if (game.title.contains("God", true)) "UCES00710" else "ULES00151"
                                    AsyncImage(
                                        model = "https://art.gametdb.com/psp/coverEN/$demoId.png",''',
'''                                    val coverUrl = game.coverArt ?: "https://art.gametdb.com/psp/coverEN/${if (game.title.contains("God", true)) "UCES00710" else "ULES00151"}.png"
                                    AsyncImage(
                                        model = coverUrl,''')
        # Also in Grid view items (around line 590)
        content = content.replace(
'''                            val demoId = if (game.title.contains("God", true)) "UCES00710" else "ULES00151"
                            AsyncImage(
                                model = "https://art.gametdb.com/psp/coverEN/$demoId.png",''',
'''                            val coverUrl = game.coverArt ?: "https://art.gametdb.com/psp/coverEN/${if (game.title.contains("God", true)) "UCES00710" else "ULES00151"}.png"
                            AsyncImage(
                                model = coverUrl,''')
        # Also in List view items (around line 630)
        content = content.replace(
'''                            val demoId = if (game.title.contains("God", true)) "UCES00710" else "ULES00151"
                            AsyncImage(
                                model = "https://art.gametdb.com/psp/coverEN/$demoId.png",''',
'''                            val coverUrl = game.coverArt ?: "https://art.gametdb.com/psp/coverEN/${if (game.title.contains("God", true)) "UCES00710" else "ULES00151"}.png"
                            AsyncImage(
                                model = coverUrl,''')

    with open(filepath, 'w') as f:
        f.write(content)

for root, _, files in os.walk('app/src/main/java'):
    for f in files:
        if f.endswith('.kt'):
            process_file(os.path.join(root, f))
