import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

test_code = """
static std::string runCsoTests() {
    std::ostringstream ss;
    ss << "--- CSO Format Tests ---\\n";
    
    // Create a dummy ISO and CSO file
    const char* iso_path = "/tmp/test.iso";
    const char* cso_path = "/tmp/test.cso";
    
    // 1. Create dummy ISO (16 KB)
    std::vector<uint8_t> iso_data(16384);
    for (int i = 0; i < 16384; i++) iso_data[i] = i & 0xFF;
    
    FILE* f_iso = fopen(iso_path, "wb");
    if (f_iso) { fwrite(iso_data.data(), 1, iso_data.size(), f_iso); fclose(f_iso); }
    
    // 2. Create dummy CSO
    CsoHeader header;
    memcpy(header.magic, "CISO", 4);
    header.header_size = sizeof(CsoHeader);
    header.total_bytes = iso_data.size();
    header.block_size = 2048;
    header.version = 1;
    header.align = 0;
    
    uint32_t total_blocks = 16384 / 2048;
    std::vector<uint32_t> index_table(total_blocks + 1);
    
    std::vector<uint8_t> cso_body;
    for (uint32_t i = 0; i < total_blocks; i++) {
        index_table[i] = sizeof(CsoHeader) + (total_blocks + 1) * 4 + cso_body.size();
        index_table[i] |= 0x80000000; // Plain block
        for (int j = 0; j < 2048; j++) cso_body.push_back(iso_data[i * 2048 + j]);
    }
    index_table[total_blocks] = sizeof(CsoHeader) + (total_blocks + 1) * 4 + cso_body.size();
    
    FILE* f_cso = fopen(cso_path, "wb");
    if (f_cso) {
        fwrite(&header, 1, sizeof(header), f_cso);
        fwrite(index_table.data(), 4, index_table.size(), f_cso);
        fwrite(cso_body.data(), 1, cso_body.size(), f_cso);
        fclose(f_cso);
    }
    
    int fd_iso = open(iso_path, O_RDONLY);
    int fd_cso = open(cso_path, O_RDONLY);
    
    if (fd_iso >= 0 && fd_cso >= 0) {
        IsoReader iso_reader(fd_iso, 16384);
        CsoReader cso_reader(fd_cso);
        
        ss << "CSO Valid: " << (cso_reader.isValid() ? "YES" : "NO") << "\\n";
        
        // Random access cross-block test
        uint8_t buf1[1024];
        uint8_t buf2[1024];
        
        iso_reader.read(1500, buf1, 1024);
        cso_reader.read(1500, buf2, 1024);
        
        ss << "Cross-block read match: " << (memcmp(buf1, buf2, 1024) == 0 ? "YES" : "NO") << "\\n";
    }
    
    unlink(iso_path);
    unlink(cso_path);
    
    return ss.str();
}
"""

# Insert before JNI functions
content = re.sub(r'#ifdef __ANDROID__\nint main', test_code + '\n#ifdef __ANDROID__\nint main', content)

# Also expose runCsoTests in the CPU Tests output or executeNativeScript
content = content.replace('ss << "--- End of Native Tests ---\\n";', 'ss << runCsoTests();\n    ss << "--- End of Native Tests ---\\n";')

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
