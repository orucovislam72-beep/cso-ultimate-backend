import re

with open('/app/applet/app/src/main/java/com/example/GameplayScreen.kt', 'r') as f:
    text = f.read()

imports = [
    "import androidx.compose.ui.graphics.nativeCanvas",
    "import androidx.compose.runtime.mutableIntStateOf",
]

for imp in imports:
    if imp not in text:
        text = text.replace("import androidx.compose.runtime.*", "import androidx.compose.runtime.*\n" + imp)

with open('/app/applet/app/src/main/java/com/example/GameplayScreen.kt', 'w') as f:
    f.write(text)

