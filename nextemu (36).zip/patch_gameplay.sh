#!/bin/bash
FILE="app/src/main/java/com/example/GameplayScreen.kt"

# Read the file and we will replace VirtualButton definition and where it is used.
