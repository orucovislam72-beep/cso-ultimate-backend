import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

content = content.replace('fseek(f.fp, f.extent * 2048 + f.offset, SEEK_SET);\n        std::vector<uint8_t> buf(read_size);\n        size_t actual_read = fread(buf.data(), 1, read_size, f.fp);',
                          'std::vector<uint8_t> buf(read_size);\n        size_t actual_read = f.fp->read(f.extent * 2048 + f.offset, buf.data(), read_size);')

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
