import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

# 1. Update VfsFile struct
content = content.replace('struct VfsFile {\n    bool isIsoFile;\n    uint32_t isoExtent;\n    uint32_t isoSize;\n    uint32_t offset;\n    FILE* fp;\n    bool isDir;\n    std::string path;\n};',
                          'struct VfsFile {\n    bool isIsoFile;\n    uint32_t isoExtent;\n    uint32_t isoSize;\n    uint32_t offset;\n    std::shared_ptr<IDiscImage> fp;\n    bool isDir;\n    std::string path;\n};')

# 2. Fix eboot rawHeader read
content = content.replace('fseek(fp, eboot_ext * 2048, SEEK_SET);\n    if (fread(rawHeader.data(), 1, 128, fp) != 128) {',
                          'if (fp->read(eboot_ext * 2048, rawHeader.data(), 128) != 128) {')

# 3. Fix ebootBuf read
content = content.replace('fseek(fp, eboot_ext * 2048, SEEK_SET);\n    size_t bytesRead = fread(ebootBuf.data(), 1, eboot_size, fp);',
                          'size_t bytesRead = fp->read(eboot_ext * 2048, ebootBuf.data(), eboot_size);')

# 4. Fix fseek/fread in pvd reads
content = content.replace('fseek(fp, 16 * 2048, SEEK_SET);\n        if (fread(pvd, 1, 2048, fp) == 2048) {',
                          'if (fp->read(16 * 2048, pvd, 2048) == 2048) {')

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
