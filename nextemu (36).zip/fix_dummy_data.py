import re

with open('app/src/main/java/com/example/viewmodel/GamesViewModel.kt', 'r') as f:
    content = f.read()

# I will replace some dummy entries with realistic ones
content = content.replace(
'''                        title = "God of War: Chains of Olympus",
                        path = "/sdcard/PSP/GAME/God_of_War_Chains_of_Olympus.iso",''',
'''                        title = "God of War: Chains of Olympus",
                        gameId = "UCES00710",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/UCES00710.png",
                        path = "/sdcard/PSP/GAME/God_of_War_Chains_of_Olympus.iso",''')

content = content.replace(
'''                        title = "Grand Theft Auto: Liberty City Stories",
                        path = "/sdcard/PSP/GAME/GTA_Liberty_City_Stories.iso",''',
'''                        title = "Grand Theft Auto: Liberty City Stories",
                        gameId = "ULES00151",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES00151.png",
                        path = "/sdcard/PSP/GAME/GTA_Liberty_City_Stories.iso",''')

content = content.replace(
'''                        title = "Tekken 6",
                        path = "/sdcard/PSP/GAME/Tekken_6.cso",''',
'''                        title = "Tekken 6",
                        gameId = "ULES01376",
                        format = "CSO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES01376.png",
                        path = "/sdcard/PSP/GAME/Tekken_6.cso",''')

content = content.replace(
'''                        title = "Monster Hunter Freedom Unite",
                        path = "/sdcard/PSP/GAME/Monster_Hunter_Freedom_Unite.iso",''',
'''                        title = "Monster Hunter Freedom Unite",
                        gameId = "ULES01213",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES01213.png",
                        path = "/sdcard/PSP/GAME/Monster_Hunter_Freedom_Unite.iso",''')

content = content.replace(
'''                        title = "Persona 3 Portable",
                        path = "/sdcard/PSP/GAME/Persona_3_Portable.iso",''',
'''                        title = "Persona 3 Portable",
                        gameId = "ULES01523",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES01523.png",
                        path = "/sdcard/PSP/GAME/Persona_3_Portable.iso",''')

# In addCustomGame
content = content.replace(
'''                    title = name.substringBeforeLast('.'),
                    path = uriString,''',
'''                    title = name.substringBeforeLast('.'),
                    gameId = "UNKNOWN",
                    format = ext,
                    path = uriString,''')

with open('app/src/main/java/com/example/viewmodel/GamesViewModel.kt', 'w') as f:
    f.write(content)
