import re

with open('/app/applet/app/src/main/java/com/example/GameplayScreen.kt', 'r') as f:
    text = f.read()

# Replace variables and Engine loop
old_engine_loop = """    // Engine loop for FPS simulation or step frame
    LaunchedEffect(isLoading, isPaused) {
        if (isLoading || isPaused) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        var frames = 0
        while (true) {
            delay(16) // ~60 FPS
            if (NativeEmuEngine.isNativeLoaded()) {
                NativeEmuEngine.stepFrame()
            }
            frames++
            val now = System.currentTimeMillis()
            if (now - lastTime >= 1000) {
                fps = (frames * 1000f / (now - lastTime)).toInt().coerceIn(58, 60)
                frames = 0
                lastTime = now
            }
        }
    }"""

new_engine_loop = """    var triggerDraw by remember { mutableIntStateOf(0) }
    val pixels = remember { IntArray(480 * 272) }
    val bitmap = remember { Bitmap.createBitmap(480, 272, Bitmap.Config.ARGB_8888) }

    // Engine loop for FPS simulation or step frame
    LaunchedEffect(isLoading, isPaused) {
        if (isLoading || isPaused) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        var frames = 0
        while (true) {
            delay(16) // ~60 FPS
            if (NativeEmuEngine.isNativeLoaded()) {
                NativeEmuEngine.stepFrame()
                if (NativeEmuEngine.nativeGetFramebuffer(pixels, 480, 272)) {
                    bitmap.setPixels(pixels, 0, 480, 0, 0, 480, 272)
                    triggerDraw++
                }
            }
            frames++
            val now = System.currentTimeMillis()
            if (now - lastTime >= 1000) {
                fps = (frames * 1000f / (now - lastTime)).toInt().coerceIn(58, 60)
                frames = 0
                lastTime = now
            }
        }
    }"""

if old_engine_loop in text:
    text = text.replace(old_engine_loop, new_engine_loop)
else:
    print("Could not find old_engine_loop!")


# Extract AndroidView and replace with Canvas
start_idx = text.find("        // Render Layer (GLSurfaceView)")
end_idx = text.find("        // Loading Overlay")

if start_idx != -1 and end_idx != -1:
    old_render = text[start_idx:end_idx]
    
    new_render = """        // Render Layer (Canvas)
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            triggerDraw // Read state to trigger recomposition
            val canvasWidth = size.width
            val canvasHeight = size.height
            val destRect = android.graphics.Rect(0, 0, canvasWidth.roundToInt(), canvasHeight.roundToInt())
            drawContext.canvas.nativeCanvas.drawBitmap(bitmap, null, destRect, null)
        }

"""
    text = text[:start_idx] + new_render + text[end_idx:]
else:
    print("Could not find GLSurfaceView block!")

with open('/app/applet/app/src/main/java/com/example/GameplayScreen.kt', 'w') as f:
    f.write(text)

