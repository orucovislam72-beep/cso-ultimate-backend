with open('app/src/main/java/com/nextemu/psp/AiAssistantScreen.kt', 'r') as f:
    text = f.read()

# Replace the messy duplicated block with a clean one
old_block = '''    try {
        // хак для обхода бага на старых девайсах
        val firebaseApp = com.google.firebase.FirebaseApp.getInstance()
    } catch (e: Exception) {
        return@withContext "Firebase не настроен. AI недоступен."
    }
    try {
        val apiKey = try {
        // хак для обхода бага на старых девайсах
        val firebaseApp = com.google.firebase.FirebaseApp.getInstance()
    } catch (e: Exception) {
        return@withContext "Firebase не настроен. AI недоступен."
    }
    val apiKey = try {
            com.nextemu.psp.BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
        } catch (_: Exception) {
            null
        } ?: System.getenv("GEMINI_API_KEY") ?: ""'''

new_block = '''    try {
        // хак для обхода бага на старых девайсах
        val firebaseApp = com.google.firebase.FirebaseApp.getInstance()
    } catch (e: Exception) {
        return@withContext "Firebase не настроен. AI недоступен."
    }
    try {
        val apiKey = try {
            com.nextemu.psp.BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
        } catch (_: Exception) {
            null
        } ?: System.getenv("GEMINI_API_KEY") ?: ""'''

if old_block in text:
    text = text.replace(old_block, new_block)
else:
    print("Could not find the messy block, please investigate!")

with open('app/src/main/java/com/nextemu/psp/AiAssistantScreen.kt', 'w') as f:
    f.write(text)
