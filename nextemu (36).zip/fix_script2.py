import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

content = content.replace('return "Not implemented directly via script, use openIso";',
                          'return env->NewStringUTF("Not implemented directly via script, use openIso");')
content = content.replace('return "No image loaded";',
                          'return env->NewStringUTF("No image loaded");')
content = content.replace('return ss_info.str();',
                          'return env->NewStringUTF(ss_info.str().c_str());')

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
