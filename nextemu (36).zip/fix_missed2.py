import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

# 1. pvd read (probably in extractIcon/getGameInfo or similar)
content = content.replace('fseek(fp, 16 * 2048, SEEK_SET);\n    if (fread(pvd, 1, 2048, fp) != 2048) {',
                          'if (fp->read(16 * 2048, pvd, 2048) != 2048) {')

# 2. fclose(it->second.fp)
content = content.replace('if (it->second.fp) fclose(it->second.fp);',
                          'if (it->second.fp) it->second.fp = nullptr;')

# 3. fseek/fread in sceIoRead
content = content.replace('fseek(f.fp, f.extent * 2048 + f.offset, SEEK_SET);\n        size_t actual_read = fread(buf.data(), 1, read_size, f.fp);',
                          'size_t actual_read = f.fp->read(f.extent * 2048 + f.offset, buf.data(), read_size);')

# 4. fclose in cleanup
content = content.replace('if (pair.second.fp) fclose(pair.second.fp);',
                          'if (pair.second.fp) pair.second.fp = nullptr;')

# Also search for any other fseek(fp
content = re.sub(r'fseek\(fp,\s*(.+?),\s*SEEK_SET\);\n\s*if\s*\(fread\((.+?),\s*1,\s*(.+?),\s*fp\)\s*==\s*(.+?)\)',
                 r'if (fp->read(\1, \2, \3) == \4)', content)
content = re.sub(r'fseek\(fp,\s*(.+?),\s*SEEK_SET\);\n\s*if\s*\(fread\((.+?),\s*1,\s*(.+?),\s*fp\)\s*!=\s*(.+?)\)',
                 r'if (fp->read(\1, \2, \3) != \4)', content)
content = re.sub(r'fseek\(f\.fp,\s*(.+?),\s*SEEK_SET\);\n\s*size_t actual_read = fread\((.+?),\s*1,\s*(.+?),\s*f\.fp\);',
                 r'size_t actual_read = f.fp->read(\1, \2, \3);', content)

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
