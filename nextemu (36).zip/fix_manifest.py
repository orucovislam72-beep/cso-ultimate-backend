import re

with open('app/src/main/AndroidManifest.xml', 'r') as f:
    am = f.read()

# Fix the malformed <application> tag
am = am.replace('<application\n        <meta-data', '<application\n')

# Now add meta-data properly inside <application>
if '<meta-data' not in am:
    am = am.replace('<application', '<application>\n        <meta-data\n            android:name="firebase_crashlytics_collection_enabled"\n            android:value="false" />\n')

# Actually, the easiest way is to rewrite from scratch since it's small
with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write('''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MyApplication">
        <meta-data
            android:name="firebase_crashlytics_collection_enabled"
            android:value="false" />
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.MyApplication">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
''')

