#!/bin/bash
FILE="app/src/main/cpp/native-lib.cpp"

# 1. Insert struct after includes or at a suitable place.
# We can search for the first struct or just put it after includes.
sed -i '/#include <jni.h>/a \
\
struct PspPadState {\
    uint32_t buttons = 0;\
    uint8_t lx = 128, ly = 128;\
};\
static PspPadState g_padState;\
' $FILE

# 2. Update hle_sceCtrlReadBufferPositive
sed -i 's/internalWriteMemory32(pad_ptr + 4, 0);/internalWriteMemory32(pad_ptr + 4, g_padState.buttons);/g' $FILE
sed -i 's/internalWriteMemory8(pad_ptr + 8, 128);/internalWriteMemory8(pad_ptr + 8, g_padState.lx);/g' $FILE
sed -i 's/internalWriteMemory8(pad_ptr + 9, 128);/internalWriteMemory8(pad_ptr + 9, g_padState.ly);/g' $FILE

# 3. Add JNI function at the end
cat << 'JNI' >> $FILE

extern "C" JNIEXPORT void JNICALL
Java_com_example_engine_NativeEmuEngine_nativeSetButtonState(JNIEnv *env, jobject thiz, jint buttons, jint lx, jint ly) {
    g_padState.buttons = (uint32_t)buttons;
    g_padState.lx = (uint8_t)lx;
    g_padState.ly = (uint8_t)ly;
}
JNI
