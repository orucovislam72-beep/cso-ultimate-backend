import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

script_additions = """    if (s.find("emu.mount ") == 0) {
        return "Not implemented directly via script, use openIso";
    }
    if (s == "emu.imageinfo" || s == "emu.imageinfo()") {
        auto img = openGameImage();
        if (!img) return "No image loaded";
        std::ostringstream ss_info;
        ss_info << "Format: " << img->format() << "\\n"
           << "Size: " << (img->size() / 1024 / 1024) << " MB\\n";
        auto cso = std::dynamic_pointer_cast<CsoReader>(img);
        if (cso) ss_info << "Block size: " << cso->blockSize() << "\\nCompression: supported\\n";
        ss_info << "ISO9660: OK\\n";
        GameInfo info = parseIso(img);
        ss_info << "PSP_GAME: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\\n"
                << "PARAM.SFO: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\\n"
                << "EBOOT.BIN: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING");
        return ss_info.str();
    }
    if (s == "emu.gameinfo" || s == "emu.gameinfo()") {
        auto img = openGameImage();
        if (!img) return "No image loaded";
        GameInfo info = parseIso(img);
        std::ostringstream ss_info;
        ss_info << "Title: " << info.title << "\\n"
           << "Game ID: " << info.gameId << "\\n"
           << "PSP_GAME: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\\n"
           << "PARAM.SFO: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\\n";
        return ss_info.str();
    }
"""

content = content.replace('std::ostringstream ss;\n    if (s == "sys.native") {',
                          'std::ostringstream ss;\n' + script_additions + '    if (s == "sys.native") {')

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
