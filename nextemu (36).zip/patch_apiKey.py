with open('app/src/main/java/com/nextemu/psp/AiAssistantScreen.kt', 'r') as f:
    text = f.read()

text = text.replace(
'''    try {
            com.nextemu.psp.BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
        } catch (_: Exception) {
            null
        } ?: System.getenv("GEMINI_API_KEY") ?: ""''',
'''    val apiKey = try {
            com.nextemu.psp.BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
        } catch (_: Exception) {
            null
        } ?: System.getenv("GEMINI_API_KEY") ?: ""''')

with open('app/src/main/java/com/nextemu/psp/AiAssistantScreen.kt', 'w') as f:
    f.write(text)
