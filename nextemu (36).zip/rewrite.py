import re

with open('app/src/main/java/com/example/GameplayScreen.kt', 'r') as f:
    content = f.read()

# Update VirtualButton
new_virtual_button = """@Composable
fun VirtualButton(
    label: String,
    accentColor: Color = Color.White,
    onPress: () -> Unit,
    onRelease: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier = Modifier
            .size(44.dp)
            .background(Color(0xFF2A2A3C).copy(alpha = 0.6f), CircleShape)
            .border(1.5.dp, accentColor.copy(alpha = 0.8f), CircleShape)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        if (event.changes.any { it.pressed } && !event.changes.all { it.previousPressed }) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onPress()
                        } else if (event.changes.all { !it.pressed }) {
                            onRelease()
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = accentColor,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
"""

content = re.sub(r'@Composable\s*fun VirtualButton.*?(?=@Composable)', new_virtual_button, content, flags=re.DOTALL)

# Same for VirtualTriggerButton
new_virtual_trigger_button = """@Composable
fun VirtualTriggerButton(
    label: String,
    accentColor: Color,
    onPress: () -> Unit,
    onRelease: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier = Modifier
            .background(accentColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .border(1.dp, accentColor.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        if (event.changes.any { it.pressed } && !event.changes.all { it.previousPressed }) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onPress()
                        } else if (event.changes.all { !it.pressed }) {
                            onRelease()
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
    }
}
"""
content = re.sub(r'@Composable\s*fun VirtualTriggerButton.*?(?=@Composable)', new_virtual_trigger_button, content, flags=re.DOTALL)

# Update state variables in GameplayScreen
state_vars = """
    val context = LocalContext.current
    var currentButtons by remember { mutableIntStateOf(0) }
    var analogLx by remember { mutableIntStateOf(128) }
    var analogLy by remember { mutableIntStateOf(128) }
    
    fun updatePadState() {
        NativeEmuEngine.nativeSetButtonState(currentButtons, analogLx, analogLy)
    }
    
    fun onBtnPress(mask: Int) {
        currentButtons = currentButtons or mask
        updatePadState()
    }
    
    fun onBtnRelease(mask: Int) {
        currentButtons = currentButtons and mask.inv()
        updatePadState()
    }
"""
content = re.sub(r'val context = LocalContext\.current', state_vars, content, count=1)

# Now update all VirtualButton usages
content = content.replace('VirtualButton("▲", Color.White) { actionLog = "UP" }', 'VirtualButton("▲", Color.White, { onBtnPress(0x0010) }, { onBtnRelease(0x0010) })')
content = content.replace('VirtualButton("◄", Color.White) { actionLog = "LEFT" }', 'VirtualButton("◄", Color.White, { onBtnPress(0x0080) }, { onBtnRelease(0x0080) })')
content = content.replace('VirtualButton("►", Color.White) { actionLog = "RIGHT" }', 'VirtualButton("►", Color.White, { onBtnPress(0x0020) }, { onBtnRelease(0x0020) })')
content = content.replace('VirtualButton("▼", Color.White) { actionLog = "DOWN" }', 'VirtualButton("▼", Color.White, { onBtnPress(0x0040) }, { onBtnRelease(0x0040) })')

content = content.replace('VirtualButton("△", Color(0xFF4CAF50)) { actionLog = "△" }', 'VirtualButton("△", Color(0xFF4CAF50), { onBtnPress(0x1000) }, { onBtnRelease(0x1000) })')
content = content.replace('VirtualButton("✕", Color(0xFF2196F3)) { actionLog = "✕" }', 'VirtualButton("✕", Color(0xFF2196F3), { onBtnPress(0x4000) }, { onBtnRelease(0x4000) })')
content = content.replace('VirtualButton("◻", Color(0xFFFF9800)) { actionLog = "◻" }', 'VirtualButton("◻", Color(0xFFFF9800), { onBtnPress(0x8000) }, { onBtnRelease(0x8000) })')
content = content.replace('VirtualButton("◯", Color(0xFFE91E63)) { actionLog = "◯" }', 'VirtualButton("◯", Color(0xFFE91E63), { onBtnPress(0x2000) }, { onBtnRelease(0x2000) })')

# Triggers
content = content.replace('VirtualTriggerButton("L", Color.White) { actionLog = "L Trigger" }', 'VirtualTriggerButton("L", Color.White, { onBtnPress(0x0100) }, { onBtnRelease(0x0100) })')
content = content.replace('VirtualTriggerButton("R", Color.White) { actionLog = "R Trigger" }', 'VirtualTriggerButton("R", Color.White, { onBtnPress(0x0200) }, { onBtnRelease(0x0200) })')

# Select and Start (these are normal Buttons right now)
start_button = """Button(
                            onClick = {},
                            modifier = Modifier.pointerInput(Unit) {
                                awaitPointerEventScope {
                                    while(true) {
                                        val event = awaitPointerEvent()
                                        if (event.changes.any { it.pressed }) onBtnPress(0x0008)
                                        else onBtnRelease(0x0008)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C3E).copy(alpha = 0.7f)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("START", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }"""
content = re.sub(r'Button\(\s*onClick = \{ actionLog = "START" \}[^)]*\)\s*\{[^}]*\}', start_button, content)

select_button = """Button(
                            onClick = {},
                            modifier = Modifier.pointerInput(Unit) {
                                awaitPointerEventScope {
                                    while(true) {
                                        val event = awaitPointerEvent()
                                        if (event.changes.any { it.pressed }) onBtnPress(0x0001)
                                        else onBtnRelease(0x0001)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C3E).copy(alpha = 0.7f)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("SELECT", fontSize = 10.sp, color = Color.LightGray)
                        }"""
content = re.sub(r'Button\(\s*onClick = \{ actionLog = "SELECT" \}[^)]*\)\s*\{[^}]*\}', select_button, content)

# Analog
analog_new = """AnalogStick(
                            onMove = { x, y -> 
                                analogLx = (128 + x * 127).toInt().coerceIn(0, 255)
                                analogLy = (128 + y * 127).toInt().coerceIn(0, 255)
                                updatePadState()
                            },
                            onRelease = { 
                                analogLx = 128
                                analogLy = 128
                                updatePadState()
                            }
                        )"""
content = re.sub(r'AnalogStick\(\s*onMove = \{[^\}]*\}[^\}]*\},\s*onRelease = \{[^\}]*\}\s*\)', analog_new, content)

with open('app/src/main/java/com/example/GameplayScreen.kt', 'w') as f:
    f.write(content)

