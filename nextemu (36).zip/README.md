# NextEmu v2.0
PSP/PSX/GBA эмулятор на Android

Этот проект разрабатывался вручную командой NextEmu Project.
Мы вложили много сил в оптимизацию C++ ядра и UI на Jetpack Compose!
