import re

with open('app/src/main/java/com/nextemu/psp/MainActivity.kt', 'r') as f:
    text = f.read()

# Remove fun SettingsScreen() and its content until the end or next function
# It starts at the end of the file based on previous tail
# I'll look for @Composable\nfun SettingsScreen()
# and fun AboutScreen()

text = re.sub(r'@Composable\s+fun\s+SettingsScreen\(\)\s*\{.*?\}\s*$', '', text, flags=re.DOTALL)
text = re.sub(r'fun\s+AboutScreen\(\)\s*\{.*?\}', '', text, flags=re.DOTALL)

# Also remove helper components if they are now in SettingsScreen.kt
text = re.sub(r'@Composable\s+fun\s+SettingsCategory\(.*?\)\s*\{.*?\}', '', text, flags=re.DOTALL)
text = re.sub(r'@Composable\s+fun\s+SettingsToggleItem\(.*?\)\s*\{.*?\}', '', text, flags=re.DOTALL)
text = re.sub(r'@Composable\s+fun\s+SettingsSliderItem\(.*?\)\s*\{.*?\}', '', text, flags=re.DOTALL)
text = re.sub(r'@Composable\s+fun\s+SettingsDropdownItem\(.*?\)\s*\{.*?\}', '', text, flags=re.DOTALL)

with open('app/src/main/java/com/nextemu/psp/MainActivity.kt', 'w') as f:
    f.write(text)
