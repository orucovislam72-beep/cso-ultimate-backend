import re

with open('app/src/main/java/com/nextemu/psp/ScriptConsoleScreen.kt', 'r') as f:
    text = f.read()

# Add imports for NativeEmuEngine
if 'import com.nextemu.psp.engine.NativeEmuEngine' not in text:
    text = text.replace('import androidx.compose.ui.text.font.FontFamily', 'import androidx.compose.ui.text.font.FontFamily\nimport com.nextemu.psp.engine.NativeEmuEngine')

# 1. emu.cpu()
cpu_old = 'if (input == "emu.cpu()") return "PC: 0x08000000\\nRegisters: ..."'
cpu_new = 'if (input == "emu.cpu()") return NativeEmuEngine.nativeGetCpuState()'
if cpu_old in text:
    text = text.replace(cpu_old, cpu_new)
else:
    # Just insert it manually if not found
    text = re.sub(r'if \(input == "emu\.cpu\(\)"\) return ".*?"', cpu_new, text)

# 2. emu.ips()
ips_old = 'if (input == "emu.ips()") return "IPS: 0"'
ips_new = 'if (input == "emu.ips()") return "Инструкций/сек: %,d".format(java.util.Locale.US, NativeEmuEngine.nativeGetIPS())'
if ips_old in text:
    text = text.replace(ips_old, ips_new)
else:
    text = re.sub(r'if \(input == "emu\.ips\(\)"\) return ".*?"', ips_new, text)

# 3. emu.memread
if 'if (input.startsWith("emu.memread "))' not in text:
    # Add it
    # Find a good place, maybe before "if (input.startsWith("emu.screenshot()"))"
    insert_str = """
    if (input.startsWith("emu.memread ")) {
        val addrStr = input.removePrefix("emu.memread ").trim().removePrefix("0x")
        try {
            val addr = addrStr.toLong(16)
            val value = NativeEmuEngine.readMemory32(addr)
            return "0x%08X = 0x%08X".format(addr, value)
        } catch (e: Exception) {
            return "Error: Invalid address format"
        }
    }
"""
    text = text.replace('if (input == "emu.screenshot()")', insert_str + 'if (input == "emu.screenshot()")')

with open('app/src/main/java/com/nextemu/psp/ScriptConsoleScreen.kt', 'w') as f:
    f.write(text)

