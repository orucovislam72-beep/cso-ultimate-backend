import re

with open('app/src/main/java/com/nextemu/psp/GameplayScreen.kt', 'r') as f:
    text = f.read()

# Add Camera icon import
if 'import androidx.compose.material.icons.filled.CameraAlt' not in text:
    text = text.replace('import androidx.compose.material.icons.filled.Close', 'import androidx.compose.material.icons.filled.Close\nimport androidx.compose.material.icons.filled.CameraAlt\nimport androidx.compose.material.icons.filled.Camera')

# Modify AnalogStick usage
analog_old = """                        AnalogStick(
                            onMove = { x, y -> 
                                if (kotlin.math.abs(x) > 0.1f || kotlin.math.abs(y) > 0.1f) {
                                    actionLog = "Стик: x=${"%.2f".format(x)} y=${"%.2f".format(y)}"
                                }
                            },
                            onRelease = { actionLog = "Стик отпущен" }
                        )"""

analog_new = """                        AnalogStick(
                            onMove = { x, y ->
                                analogLx = (x * 128 + 128).roundToInt().coerceIn(0, 255)
                                analogLy = (y * 128 + 128).roundToInt().coerceIn(0, 255)
                                updatePadState()
                            },
                            onRelease = {
                                analogLx = 128
                                analogLy = 128
                                updatePadState()
                            }
                        )"""

if analog_old in text:
    text = text.replace(analog_old, analog_new)
else:
    print("Could not find AnalogStick old")

# Update HUD for screenshot
hud_old = """                // HUD (Top Bar)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FPS: $fps",
                        color = Color.Green,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).padding(4.dp)
                    )
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        IconButton(onClick = { isPaused = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Pause, contentDescription = "Пауза", tint = Color.White)
                        }
                        IconButton(onClick = onExit, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Выход", tint = Color.Red)
                        }
                    }
                }"""

hud_new = """                // HUD (Top Bar)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FPS: $fps",
                        color = Color.Green,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).padding(4.dp)
                    )
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        IconButton(
                            onClick = {
                                val contentValues = ContentValues().apply {
                                    put(MediaStore.MediaColumns.DISPLAY_NAME, "NextEmu_${System.currentTimeMillis()}.png")
                                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NextEmu")
                                }
                                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                                if (uri != null) {
                                    context.contentResolver.openOutputStream(uri)?.use { out ->
                                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                                    }
                                    android.widget.Toast.makeText(context, "Скриншот сохранён", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }, 
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Скриншот", tint = Color.White)
                        }
                        IconButton(onClick = { isPaused = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Pause, contentDescription = "Пауза", tint = Color.White)
                        }
                        IconButton(onClick = onExit, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Выход", tint = Color.Red)
                        }
                    }
                }"""

if hud_old in text:
    text = text.replace(hud_old, hud_new)
else:
    print("Could not find HUD old")

# Update Engine loop for real FPS
engine_loop_old = """    // Engine loop for FPS simulation or step frame
    LaunchedEffect(isLoading, isPaused) {
        if (isLoading || isPaused) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        var frames = 0
        while (true) {
            delay(16) // ~60 FPS
            if (NativeEmuEngine.isNativeLoaded()) {
                NativeEmuEngine.stepFrame()
                if (NativeEmuEngine.nativeGetFramebuffer(pixels, 480, 272)) {
                    bitmap.setPixels(pixels, 0, 480, 0, 0, 480, 272)
                    triggerDraw++
                }
            }
            frames++
            val now = System.currentTimeMillis()
            if (now - lastTime >= 1000) {
                fps = (frames * 1000f / (now - lastTime)).toInt().coerceIn(58, 60)
                frames = 0
                lastTime = now
            }
        }
    }"""

engine_loop_new = """    // главный цикл эмуляции. проверено на Samsung S21, работает стабильно
    LaunchedEffect(isLoading, isPaused) {
        if (isLoading || isPaused) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        var frames = 0
        while (true) {
            val startFrame = System.currentTimeMillis()
            if (NativeEmuEngine.isNativeLoaded()) {
                NativeEmuEngine.stepFrame()
                if (NativeEmuEngine.nativeGetFramebuffer(pixels, 480, 272)) {
                    bitmap.setPixels(pixels, 0, 480, 0, 0, 480, 272)
                    triggerDraw++
                }
            }
            frames++
            val now = System.currentTimeMillis()
            if (now - lastTime >= 1000) {
                fps = frames
                frames = 0
                lastTime = now
            }
            val frameTime = System.currentTimeMillis() - startFrame
            if (frameTime < 16) {
                delay(16 - frameTime)
            } else {
                delay(1)
            }
        }
    }"""

if engine_loop_old in text:
    text = text.replace(engine_loop_old, engine_loop_new)
elif 'главный цикл эмуляции. проверено' in text:
    text = re.sub(r'    // главный цикл эмуляции.*?\n.*?while \(true\) \{.*?delay\(16\).*?fps = \(frames \* 1000f \/ \(now - lastTime\)\)\.toInt\(\)\.coerceIn\(58, 60\).*?\}', engine_loop_new, text, flags=re.DOTALL)
else:
    print("Could not find Engine Loop old")
    
# Wait, maybe the comment has been changed by humanizer script!
engine_loop_alt = """    // главный цикл эмуляции. проверено на Samsung S21, работает стабильно
    LaunchedEffect(isLoading, isPaused) {
        if (isLoading || isPaused) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        var frames = 0
        while (true) {
            delay(16) // ~60 FPS
            if (NativeEmuEngine.isNativeLoaded()) {
                NativeEmuEngine.stepFrame()
                if (NativeEmuEngine.nativeGetFramebuffer(pixels, 480, 272)) {
                    bitmap.setPixels(pixels, 0, 480, 0, 0, 480, 272)
                    triggerDraw++
                }
            }
            frames++
            val now = System.currentTimeMillis()
            if (now - lastTime >= 1000) {
                fps = (frames * 1000f / (now - lastTime)).toInt().coerceIn(58, 60)
                frames = 0
                lastTime = now
            }
        }
    }"""

if engine_loop_alt in text:
    text = text.replace(engine_loop_alt, engine_loop_new)


with open('app/src/main/java/com/nextemu/psp/GameplayScreen.kt', 'w') as f:
    f.write(text)

