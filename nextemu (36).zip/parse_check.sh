grep -in -B 2 -A 5 "findInDir" app/src/main/cpp/native-lib.cpp
echo "------"
grep -in -B 2 -A 10 "loadEboot" app/src/main/cpp/native-lib.cpp
