package com.nextemu.psp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameFileDao {
    @Query("SELECT * FROM games ORDER BY lastPlayedTimestamp DESC")
    fun getAllGames(): Flow<List<GameFile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGame(game: GameFile)

    @Query("UPDATE games SET lastPlayedTimestamp = :timestamp WHERE id = :id")
    suspend fun updateLastPlayed(id: Int, timestamp: Long)

    @Query("UPDATE games SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: Int, isFav: Boolean)

    @Query("DELETE FROM games WHERE id = :id")
    suspend fun deleteGame(id: Int)
}

