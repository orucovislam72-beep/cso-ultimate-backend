package com.nextemu.psp

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import coil.compose.AsyncImage
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.nextemu.psp.data.EmulatorDatabase
import com.nextemu.psp.data.GameFile
import com.nextemu.psp.data.GameRepository
import com.nextemu.psp.ui.theme.MyApplicationTheme
import com.nextemu.psp.viewmodel.GamesViewModel
import com.nextemu.psp.viewmodel.GamesViewModelFactory
import com.nextemu.psp.viewmodel.PlatformFilter
import com.nextemu.psp.viewmodel.SortOrder
import com.nextemu.psp.engine.NativeEmuEngine
import kotlinx.coroutines.launch

fun getFileName(context: Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/')
        if (cut != null && cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result ?: "Unknown_File"
}

fun getFileSizeString(context: Context, uri: Uri): String {
    try {
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex != -1 && !it.isNull(sizeIndex)) {
                        val bytes = it.getLong(sizeIndex)
                        return formatBytes(bytes)
                    }
                }
            }
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                return formatBytes(pfd.statSize)
            }
        } else if (uri.scheme == "file" || uri.path != null) {
            val file = java.io.File(uri.path ?: "")
            if (file.exists()) return formatBytes(file.length())
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return "ISO File"
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
    return String.format("%.1f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (NativeEmuEngine.isNativeLoaded()) {
            val savesDir = filesDir.absolutePath + "/saves"
            NativeEmuEngine.nativeSetSavesDir(savesDir)
        }
        setContent {
            MyApplicationTheme {
                EmulatorFrontendApp()
            }
        }
    }
}

@Composable
fun EmulatorFrontendApp() {
    val context = LocalContext.current
    val database = remember { EmulatorDatabase.getDatabase(context) }
    val repository = remember { GameRepository(database.gameFileDao()) }
    val viewModel: GamesViewModel = viewModel(factory = GamesViewModelFactory(repository))

    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Library) }

    val showBottomBar = currentScreen is AppScreen.Library ||
            currentScreen is AppScreen.AiAssistant ||
            currentScreen is AppScreen.ScriptConsole ||
            currentScreen is AppScreen.Settings ||
            currentScreen is AppScreen.About

    if (currentScreen is AppScreen.Gameplay) {
        GameplayScreen(
            game = (currentScreen as AppScreen.Gameplay).game,
            onExit = { currentScreen = AppScreen.Library }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                if (showBottomBar) {
                    ScrollableTabRow(
                        selectedTabIndex = when(currentScreen) {
                            is AppScreen.Library -> 0
                            is AppScreen.AiAssistant -> 1
                            is AppScreen.ScriptConsole -> 2
                            is AppScreen.Settings -> 3
                            is AppScreen.About -> 4
                            else -> 0
                        },
                        containerColor = Color(0xFF050D1A),
                        contentColor = Color.White,
                        edgePadding = 16.dp,
                        indicator = { tabPositions ->
                            val currentTab = when(currentScreen) {
                                is AppScreen.Library -> 0
                                is AppScreen.AiAssistant -> 1
                                is AppScreen.ScriptConsole -> 2
                                is AppScreen.Settings -> 3
                                is AppScreen.About -> 4
                                else -> 0
                            }
                            TabRowDefaults.Indicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[currentTab]),
                                color = Color(0xFF00E676),
                                height = 3.dp
                            )
                        }
                    ) {
                        Tab(
                            selected = currentScreen is AppScreen.Library,
                            onClick = { currentScreen = AppScreen.Library },
                            text = { Text("Игры", fontSize = 13.sp) },
                            icon = { Icon(Icons.Default.Gamepad, contentDescription = null) },
                            selectedContentColor = Color(0xFF00E676),
                            unselectedContentColor = Color(0xFF94A3B8)
                        )
                        Tab(
                            selected = currentScreen is AppScreen.AiAssistant,
                            onClick = { currentScreen = AppScreen.AiAssistant },
                            text = { Text("AI Помощник", fontSize = 13.sp) },
                            icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) },
                            selectedContentColor = Color(0xFF00E676),
                            unselectedContentColor = Color(0xFF94A3B8)
                        )
                        Tab(
                            selected = currentScreen is AppScreen.ScriptConsole,
                            onClick = { currentScreen = AppScreen.ScriptConsole },
                            text = { Text("Консоль", fontSize = 13.sp) },
                            icon = { Icon(Icons.Default.Terminal, contentDescription = null) },
                            selectedContentColor = Color(0xFF00E676),
                            unselectedContentColor = Color(0xFF94A3B8)
                        )
                        Tab(
                            selected = currentScreen is AppScreen.Settings,
                            onClick = { currentScreen = AppScreen.Settings },
                            text = { Text("Настройки", fontSize = 13.sp) },
                            icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                            selectedContentColor = Color(0xFF00E676),
                            unselectedContentColor = Color(0xFF94A3B8)
                        )
                        Tab(
                            selected = currentScreen is AppScreen.About,
                            onClick = { currentScreen = AppScreen.About },
                            text = { Text("Справка", fontSize = 13.sp) },
                            icon = { Icon(Icons.Default.Info, contentDescription = null) },
                            selectedContentColor = Color(0xFF00E676),
                            unselectedContentColor = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .background(Color(0xFF050D1A))
            ) {
                when (val screen = currentScreen) {
                    is AppScreen.Welcome -> WelcomeScreen(
                        onStart = { currentScreen = AppScreen.Library }
                    )
                    is AppScreen.Library -> GamesLibraryScreen(
                        viewModel = viewModel,
                        onGameClick = { currentScreen = AppScreen.GameDetails(it) },
                        onPlayGame = { game ->
                            viewModel.markGamePlayed(game)
                            currentScreen = AppScreen.Gameplay(game)
                        }
                    )
                    is AppScreen.AiAssistant -> AiAssistantScreen()
                    is AppScreen.ScriptConsole -> ScriptConsoleScreen()
                    is AppScreen.Settings -> SettingsScreen()
                    is AppScreen.About -> AboutScreen()
                    is AppScreen.GameDetails -> GameDetailsScreen(
                        game = screen.game,
                        onBack = { currentScreen = AppScreen.Library },
                        onPlay = {
                            viewModel.markGamePlayed(screen.game)
                            currentScreen = AppScreen.Gameplay(screen.game)
                        },
                        onToggleFavorite = { viewModel.toggleFavorite(it) }
                    )
                    else -> {}
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesLibraryScreen(
    viewModel: GamesViewModel,
    onGameClick: (GameFile) -> Unit,
    onPlayGame: (GameFile) -> Unit
) {
    val games by viewModel.games.collectAsState()
    val platformFilter by viewModel.platformFilter.collectAsState()
    val currentSortOrder by viewModel.sortOrder.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var isGridView by remember { mutableStateOf(true) }
    var isScanning by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val context = LocalContext.current
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val takeFlags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: Exception) {
                // Ignore if not supported by provider
            }
            val fileName = getFileName(context, uri)
            val fileSize = getFileSizeString(context, uri)
            viewModel.addCustomGame(uri.toString(), fileName, fileSize)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp, top = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NextEmu",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Библиотека Игр (${games.size})",
                    fontSize = 12.sp,
                    color = Color(0xFF00E676)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { isGridView = !isGridView }) {
                    Icon(
                        if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                        contentDescription = "Вид",
                        tint = Color.White
                    )
                }

                var sortMenuExpanded by remember { mutableStateOf(false) }

                Box {
                    IconButton(onClick = { sortMenuExpanded = true }) {
                        Icon(Icons.Default.Sort, contentDescription = "Сортировка", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = sortMenuExpanded,
                        onDismissRequest = { sortMenuExpanded = false },
                        modifier = Modifier.background(Color(0xFF152238))
                    ) {
                        DropdownMenuItem(
                            text = { Text("По дате запуска", color = Color.White) },
                            onClick = {
                                viewModel.setSortOrder(SortOrder.DATE_PLAYED)
                                sortMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("По названию", color = Color.White) },
                            onClick = {
                                viewModel.setSortOrder(SortOrder.TITLE)
                                sortMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("По рейтингу", color = Color.White) },
                            onClick = {
                                viewModel.setSortOrder(SortOrder.RATING)
                                sortMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("По размеру", color = Color.White) },
                            onClick = {
                                viewModel.setSortOrder(SortOrder.SIZE)
                                sortMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Поиск по названию или жанру...", fontSize = 13.sp, color = Color(0xFF64748B)) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Очистить", tint = Color(0xFF94A3B8))
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF152238),
                unfocusedContainerColor = Color(0xFF152238),
                focusedBorderColor = Color(0xFF2979FF),
                unfocusedBorderColor = Color(0xFF1E3252),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        // Platform Filter Tabs
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf(
                PlatformFilter.ALL to "Все",
                PlatformFilter.PSP to "RPG",
                PlatformFilter.PSX to "Action",
                PlatformFilter.GBA to "Racing",
                PlatformFilter.FAVORITES to "Sports"
            )

            items(tabs) { (filter, label) ->
                val isSelected = platformFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.setPlatformFilter(filter) },
                    label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF2979FF),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF152238),
                        labelColor = Color(0xFF94A3B8)
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = Color(0xFF1E3252),
                        selectedBorderColor = Color(0xFF2979FF)
                    )
                )
            }
        }

        // Action Row (File Picker & Scanner)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF))
            ) {
                Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Импорт ISO/CSO", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    coroutineScope.launch {
                        isScanning = true
                        kotlinx.coroutines.delay(1200)
                        viewModel.scanAndAddDummyGame()
                        isScanning = false
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E676))
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Сканировать", fontSize = 12.sp, color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
            }
        }

        if (isScanning) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                color = Color(0xFF00E676),
                trackColor = Color(0xFF152238)
            )
        }

        // Recent Games (Недавно запущенные)
        if (games.isNotEmpty()) {
            val recentGames = games.sortedByDescending { it.lastPlayedTimestamp }.take(5)
            if (recentGames.isNotEmpty() && recentGames.first().lastPlayedTimestamp > 0) {
                Column(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                    Text("Недавно запущенные", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(recentGames) { game ->
                            Card(
                                modifier = Modifier.size(100.dp, 140.dp).clickable { onGameClick(game) },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    val coverUrl = game.coverArt ?: "https://art.gametdb.com/psp/coverEN/${if (game.title.contains("God", true)) "UCES00710" else "ULES00151"}.png"
                                    AsyncImage(
                                        model = coverUrl,
                                        contentDescription = "Обложка",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(alpha = 0.6f))) {
                                        Text(game.title, color = Color.White, fontSize = 10.sp, maxLines = 1, modifier = Modifier.padding(4.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Games Content
        if (games.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Gamepad,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = Color(0xFF2979FF)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "Игры не найдены",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Нажмите 'Импорт ISO/CSO' или 'Сканировать' для добавления игр в вашу коллекцию.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            if (isGridView) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(games, key = { it.id }) { game ->
                        GameGridCard(
                            game = game,
                            onClick = { onGameClick(game) },
                            onPlay = { onPlayGame(game) },
                            onToggleFavorite = { viewModel.toggleFavorite(game) }
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(games, key = { it.id }) { game ->
                        GameItemCard(
                            game = game,
                            onClick = { onGameClick(game) },
                            onPlay = { onPlayGame(game) },
                            onToggleFavorite = { viewModel.toggleFavorite(game) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GameGridCard(
    game: GameFile,
    onClick: () -> Unit,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            // Header Row with Platform badge and Star
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (game.platform.uppercase()) {
                        "PSX" -> Color(0xFFE91E63)
                        "GBA" -> Color(0xFFFF9800)
                        else -> Color(0xFF2979FF)
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = game.platform.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        if (game.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Избранное",
                        tint = if (game.isFavorite) Color(0xFFFFAB00) else Color(0xFF64748B),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Body clickable
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClick() },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val demoId = if (game.title.contains("God", true)) "UCES00710" else "ULES00151"
                AsyncImage(
                    model = "https://art.gametdb.com/psp/coverEN/$demoId.png",
                    contentDescription = "Обложка",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(80.dp, 110.dp).clip(RoundedCornerShape(6.dp))
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = game.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${game.genre} • ${game.fileSize}",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Direct Play Button
            Button(
                onClick = onPlay,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("ИГРАТЬ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}

@Composable
fun GameItemCard(
    game: GameFile,
    onClick: () -> Unit,
    onPlay: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onClick() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                val demoId = if (game.title.contains("God", true)) "UCES00710" else "ULES00151"
                AsyncImage(
                    model = "https://art.gametdb.com/psp/coverEN/$demoId.png",
                    contentDescription = "Обложка",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(50.dp, 70.dp).clip(RoundedCornerShape(4.dp))
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = when (game.platform.uppercase()) {
                                "PSX" -> Color(0xFFE91E63)
                                "GBA" -> Color(0xFFFF9800)
                                else -> Color(0xFF2979FF)
                            },
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Text(
                                text = game.platform.uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        Text(
                            game.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "${game.genre} • ${game.fileSize}",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(32.dp)) {
                    Icon(
                        if (game.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Избранное",
                        tint = if (game.isFavorite) Color(0xFFFFAB00) else Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Button(
                    onClick = onPlay,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ИГРАТЬ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

