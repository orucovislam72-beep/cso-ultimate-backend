package com.nextemu.psp.data

import kotlinx.coroutines.flow.Flow

class GameRepository(private val gameFileDao: GameFileDao) {
    val allGames: Flow<List<GameFile>> = gameFileDao.getAllGames()

    suspend fun insert(game: GameFile) {
        gameFileDao.insertGame(game)
    }

    suspend fun updateLastPlayed(id: Int, timestamp: Long) {
        gameFileDao.updateLastPlayed(id, timestamp)
    }

    suspend fun toggleFavorite(id: Int, currentFav: Boolean) {
        gameFileDao.updateFavorite(id, !currentFav)
    }

    suspend fun delete(id: Int) {
        gameFileDao.deleteGame(id)
    }
}

