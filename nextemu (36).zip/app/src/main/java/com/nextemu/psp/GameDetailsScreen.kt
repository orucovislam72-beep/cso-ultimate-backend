package com.nextemu.psp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.nextemu.psp.data.GameFile
import com.nextemu.psp.engine.NativeEmuEngine
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameDetailsScreen(
    game: GameFile,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onToggleFavorite: (GameFile) -> Unit = {}
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var isFav by remember { mutableStateOf(game.isFavorite) }
    var cheat60Fps by remember { mutableStateOf(true) }
    var cheatHdTextures by remember { mutableStateOf(false) }

    var currentGameId by remember { mutableStateOf("") }
    var currentTitle by remember { mutableStateOf(game.title) }

    LaunchedEffect(game.path) {
        if ((currentGameId.isEmpty() || currentGameId == "UNKNOWN") && NativeEmuEngine.isNativeLoaded()) {
            try {
                NativeEmuEngine.openIso(context, game.path)
                val infoJson = NativeEmuEngine.nativeGetGameInfo()
                if (infoJson.contains("\"gameId\":")) {
                    val matchId = Regex("\"gameId\":\\s*\"([^\"]+)\"").find(infoJson)
                    matchId?.groupValues?.get(1)?.let { id ->
                        if (id.isNotBlank() && id != "UNKNOWN") {
                            currentGameId = id
                        }
                    }
                }
                if (infoJson.contains("\"title\":")) {
                    val matchTitle = Regex("\"title\":\\s*\"([^\"]+)\"").find(infoJson)
                    matchTitle?.groupValues?.get(1)?.let { t ->
                        if (t.isNotBlank() && t != "Unknown") {
                            currentTitle = t
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val savedSlots = remember {
        mutableStateMapOf(
            1 to "12.08.2026 18:42 (1.2 MB)",
            2 to "Пустой слот",
            3 to "Пустой слот",
            4 to "Пустой слот",
            5 to "Пустой слот"
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(currentTitle, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        isFav = !isFav
                        onToggleFavorite(game)
                    }) {
                        Icon(
                            if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Избранное",
                            tint = if (isFav) Color(0xFFFFAB00) else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0E1726))
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color(0xFF050D1A))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = when (game.platform.uppercase()) {
                                    "PSX" -> Color(0xFFE91E63)
                                    "GBA" -> Color(0xFFFF9800)
                                    else -> Color(0xFF2979FF)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = game.platform.uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFAB00), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${game.rating}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = currentTitle,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Жанр: ${game.genre} | ID: ${if (currentGameId.isNotEmpty()) currentGameId else "N/A"} | Размер: ${game.fileSize}",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = game.path,
                                fontSize = 11.sp,
                                color = Color(0xFF64748B),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            // Big Play Button
            item {
                Button(
                    onClick = onPlay,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF))
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ЗАПУСТИТЬ ЭМУЛЯТОР", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            // Cheats & Enhancements Section
            item {
                Text(
                    "Чит-коды и Улучшения (NESL Core)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("60 FPS Unlocked Patch", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("Снятие лимита кадров 30 FPS", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                            Switch(
                                checked = cheat60Fps,
                                onCheckedChange = { cheat60Fps = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E676))
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF1E3252))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("HD Texture Upscaling 4x", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("Авто-подгрузка высокочетких текстур", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                            Switch(
                                checked = cheatHdTextures,
                                onCheckedChange = { cheatHdTextures = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E676))
                            )
                        }
                    }
                }
            }

            // Save States Section
            item {
                Text(
                    "Менеджер Сохранений (Save States)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            items(5) { index ->
                val slot = index + 1
                val slotInfo = savedSlots[slot] ?: "Пустой слот"
                val isOccupied = slotInfo != "Пустой слот"

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Слот #$slot", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text(slotInfo, color = if (isOccupied) Color(0xFF00E676) else Color(0xFF64748B), fontSize = 11.sp)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (isOccupied) {
                                OutlinedButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Загружен Save State из слота #$slot")
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Загрузить", fontSize = 12.sp, color = Color.White)
                                }
                            }

                            Button(
                                onClick = {
                                    val nowStr = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                                    savedSlots[slot] = "$nowStr (1.2 MB)"
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Сохранено в слот #$slot!")
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Сохранить", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

