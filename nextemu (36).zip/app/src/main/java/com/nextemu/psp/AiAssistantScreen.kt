package com.nextemu.psp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: String = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
)

private val geminiOkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen() {
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                sender = "AI",
                text = "Привет! Я NextEmu Gemini AI — твой эксперт по эмуляции retro-игр PSP, PSX и GBA.\n\nЗадай мне вопрос про прохождение, секретные коды, оптимизацию FPS или настройку шейдеров!"
            )
        )
    }

    val quickPrompts = listOf(
        "🎮 Как победить Босса в God of War?",
        "⚡ Лучшие настройки PPSSPP для Tekken 6",
        "🚗 Коды и читы для GTA Liberty City",
        "💻 Код скрипта NESL для 60 FPS"
    )

    fun sendMessage(userPrompt: String) {
        if (userPrompt.isBlank()) return
        val textToSend = userPrompt.trim()
        inputText = ""

        messages.add(ChatMessage(sender = "USER", text = textToSend))

        coroutineScope.launch {
            isLoading = true
            listState.animateScrollToItem(messages.size - 1)

            val aiResponse = queryGeminiAi(textToSend)
            messages.add(ChatMessage(sender = "AI", text = aiResponse))
            isLoading = false
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF2979FF).copy(alpha = 0.2f),
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFF00E676),
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                "Gemini AI Помощник",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Эмулятор PSP / PSX / GBA Assistant",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF00E676)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        messages.clear()
                        messages.add(
                            ChatMessage(
                                sender = "AI",
                                text = "Чат очищен. Спроси меня о прохождении любой игры!"
                            )
                        )
                    }) {
                        Icon(Icons.Default.Clear, contentDescription = "Очистить чат")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0E1726)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(Color(0xFF050D1A))
        ) {
            // Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatBubble(msg)
                }

                if (isLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color(0xFF00E676),
                                strokeWidth = 2.dp
                            )
                            Text(
                                "Gemini генерирует ответ...",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // Quick Prompt Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickPrompts) { prompt ->
                    SuggestionChip(
                        onClick = { sendMessage(prompt) },
                        label = { Text(prompt, fontSize = 11.sp, color = Color.White) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = Color(0xFF152238)
                        ),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            enabled = true,
                            borderColor = Color(0xFF1E3252)
                        )
                    )
                }
            }

            // Input Bar
            Surface(
                color = Color(0xFF0E1726),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Задай вопрос AI игровому гиду...", fontSize = 13.sp) },
                        modifier = Modifier.weight(1f),
                        maxLines = 3,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF152238),
                            unfocusedContainerColor = Color(0xFF152238),
                            focusedBorderColor = Color(0xFF2979FF),
                            unfocusedBorderColor = Color(0xFF1E3252)
                        )
                    )

                    IconButton(
                        onClick = { sendMessage(inputText) },
                        enabled = inputText.isNotBlank() && !isLoading,
                        modifier = Modifier
                            .background(
                                if (inputText.isNotBlank()) Color(0xFF2979FF) else Color(0xFF1E3252),
                                CircleShape
                            )
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Отправить",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.sender == "USER"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Surface(
                shape = CircleShape,
                color = Color(0xFF00E676).copy(alpha = 0.2f),
                modifier = Modifier
                    .padding(end = 8.dp)
                    .size(32.dp)
            ) {
                Icon(
                    Icons.Default.Psychology,
                    contentDescription = null,
                    tint = Color(0xFF00E676),
                    modifier = Modifier.padding(6.dp)
                )
            }
        }

        Surface(
            color = if (isUser) Color(0xFF2979FF) else Color(0xFF152238),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            border = if (!isUser) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252)) else null,
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = msg.text,
                    color = Color.White,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = msg.timestamp,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }

        if (isUser) {
            Surface(
                shape = CircleShape,
                color = Color(0xFF2979FF).copy(alpha = 0.2f),
                modifier = Modifier
                    .padding(start = 8.dp)
                    .size(32.dp)
            ) {
                Icon(
                    Icons.Default.Gamepad,
                    contentDescription = null,
                    tint = Color(0xFF2979FF),
                    modifier = Modifier.padding(6.dp)
                )
            }
        }
    }
}

suspend fun queryGeminiAi(prompt: String): String = withContext(Dispatchers.IO) {
    try {
        val apiKey = try {
            com.nextemu.psp.BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
        } catch (_: Exception) {
            null
        } ?: System.getenv("GEMINI_API_KEY") ?: ""

        if (apiKey.isNotBlank() && apiKey != "DEFAULT_KEY") {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val systemContext = "Ты — NextEmu AI, эксперт по ретро-геймингу, эмуляции PSP, PSX и GBA, гайдам и чит-кодам. Отвечай дружелюбно, точно и по делу на русском языке."

            val jsonReq = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "$systemContext\n\nВопрос пользователя: $prompt"))
                        })
                    })
                })
            }

            val requestBody = jsonReq.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = geminiOkHttpClient.newCall(request).execute()
            response.use { res ->
                if (res.isSuccessful) {
                    val responseStr = res.body?.string() ?: ""
                    val jsonRes = JSONObject(responseStr)
                    val candidates = jsonRes.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val first = candidates.getJSONObject(0)
                        val content = first.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val text = parts.getJSONObject(0).optString("text", "")
                            if (text.isNotBlank()) {
                                return@withContext text
                            }
                        }
                    }
                }
            }
        }
    } catch (_: Exception) {
        // Fallback to offline expert rules
    }

    // Offline AI Expert Logic
    val lower = prompt.lowercase()
    when {
        lower.contains("god of war") || lower.contains("босс") || lower.contains("гидр") -> {
            "⚔️ **Совет по God of War (PSP):**\n" +
            "1. В бою с Гидрой блокируйте комбо триггером L1.\n" +
            "2. Используйте уклонение (L1 + Правый аналог).\n" +
            "3. Для нанесения максимального урона используйте связку ◻ + ◻ + △ (Plume of Prometheus).\n" +
            "4. Нажимайте вовремя QTE кнопки (△, ✕, ◯, ◻) когда над боссом загорается иконка!"
        }
        lower.contains("tekken") || lower.contains("fps") || lower.contains("настройк") -> {
            "⚡ **Оптимизация PPSSPP для Tekken 6:**\n" +
            "• **Рендерер:** Vulkan (бэкенд)\n" +
            "• **Разрешение:** 2x PSP (для баланса чёткости и 60 FPS)\n" +
            "• **Пропуск кадров:** Выкл (или 1 если слабый процессор)\n" +
            "• **Буферизованный рендеринг:** Включен\n" +
            "• **Анизотропная фильтрация:** 4x"
        }
        lower.contains("gta") || lower.contains("код") || lower.contains("чит") -> {
            "🚗 **Читы для GTA Liberty City Stories (PSP):**\n" +
            "• **Полное здоровье:** L1, R1, ✕, L1, R1, ◻, L1, R1\n" +
            "• **Броня:** L1, R1, ◯, L1, R1, ✕, L1, R1\n" +
            "• **Набор оружия 1:** L1, R1, ◻, L1, R1, △, L1, R1\n" +
            "• **$250,000:** L1, R1, △, L1, R1, ◯, L1, R1"
        }
        lower.contains("nesl") || lower.contains("скрипт") || lower.contains("консол") -> {
            "💻 **Пример NESL скрипта для тумблера 60 FPS:**\n" +
            "```nesl\n" +
            "// NextEmu NESL Script v2.0\n" +
            "cpu.set_clock(333);\n" +
            "gpu.vulkan_enable(true);\n" +
            "display.vsync(1);\n" +
            "print(\"Direct C++ NDK Engine Boost Applied!\");\n" +
            "```"
        }
        else -> {
            "🎮 **Игровой Совет NextEmu:**\n" +
            "Эмулятор поддерживает обратную совместимость для PSP (ISO/CSO), PSX (BIN/CUE) и GBA. Вы можете сохранять прогресс в любой момент через менеджер сохранений (Save State), а также подключать геймпады DualSense и Xbox по Bluetooth!"
        }
    }
}
