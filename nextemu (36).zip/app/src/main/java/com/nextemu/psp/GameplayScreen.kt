package com.nextemu.psp

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.KeyEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nextemu.psp.data.GameFile
import com.nextemu.psp.engine.NativeEmuEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

@Composable
fun GameplayScreen(game: GameFile, onExit: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val focusRequester = remember { FocusRequester() }

    var isPaused by remember { mutableStateOf(false) }
    var isTurbo by remember { mutableStateOf(false) }
    var showPerfOverlay by remember { mutableStateOf(true) }
    var showQuickMenu by remember { mutableStateOf(false) }
    var hapticsEnabled by remember { mutableStateOf(true) }
    var buttonOpacity by remember { mutableFloatStateOf(0.35f) }

    var fps by remember { mutableIntStateOf(60) }
    var ips by remember { mutableLongStateOf(0L) }
    var frameTimeMs by remember { mutableLongStateOf(16L) }
    var isLoading by remember { mutableStateOf(true) }

    // Controller state bitmask
    var buttonsState by remember { mutableIntStateOf(0) }
    var analogLx by remember { mutableIntStateOf(128) }
    var analogLy by remember { mutableIntStateOf(128) }

    val vibrator = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun triggerHaptic() {
        if (!hapticsEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(15)
            }
        } catch (e: Exception) {
            // Ignore vibration error
        }
    }

    fun updatePadState() {
        if (NativeEmuEngine.isNativeLoaded()) {
            NativeEmuEngine.nativeSetButtonState(buttonsState, analogLx, analogLy)
        }
    }

    fun onBtnPress(bit: Int) {
        buttonsState = buttonsState or bit
        updatePadState()
        triggerHaptic()
    }

    fun onBtnRelease(bit: Int) {
        buttonsState = buttonsState and bit.inv()
        updatePadState()
    }

    // Emulator frame buffers
    val pixels = remember { IntArray(480 * 272) }
    val bitmap = remember { Bitmap.createBitmap(480, 272, Bitmap.Config.ARGB_8888) }
    var triggerDraw by remember { mutableIntStateOf(0) }

    // Initialize game in engine
    LaunchedEffect(game.path) {
        isLoading = true
        if (NativeEmuEngine.isNativeLoaded()) {
            val success = NativeEmuEngine.openIso(context, game.path)
            if (!success) {
                snackbarHostState.showSnackbar("Не удалось открыть образ игры: ${game.title}")
            }
        }
        delay(600)
        isLoading = false
    }

    // Request focus for hardware keyboard/controller keys
    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (e: Exception) {
            // Ignore
        }
    }

    // Engine loop
    LaunchedEffect(isLoading, isPaused, isTurbo) {
        if (isLoading || isPaused) return@LaunchedEffect
        var lastTime = System.currentTimeMillis()
        var frames = 0
        val targetDelay = if (isTurbo) 4L else 16L

        while (true) {
            val startFrame = System.currentTimeMillis()
            if (NativeEmuEngine.isNativeLoaded()) {
                NativeEmuEngine.stepFrame()
                if (NativeEmuEngine.nativeGetFramebuffer(pixels, 480, 272)) {
                    bitmap.setPixels(pixels, 0, 480, 0, 0, 480, 272)
                    triggerDraw++
                }
            }
            frames++
            val now = System.currentTimeMillis()
            val elapsed = now - lastTime
            if (elapsed >= 1000) {
                fps = (frames * 1000 / elapsed.coerceAtLeast(1)).toInt()
                frames = 0
                lastTime = now
                if (NativeEmuEngine.isNativeLoaded()) {
                    ips = NativeEmuEngine.nativeGetIPS()
                }
            }
            val frameComputeTime = System.currentTimeMillis() - startFrame
            frameTimeMs = frameComputeTime
            val delayMs = (targetDelay - frameComputeTime).coerceAtLeast(1L)
            delay(delayMs)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050D1A))
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                val bit = when (keyEvent.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W -> NativeEmuEngine.BTN_UP
                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S -> NativeEmuEngine.BTN_DOWN
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> NativeEmuEngine.BTN_LEFT
                    KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> NativeEmuEngine.BTN_RIGHT
                    KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_K -> NativeEmuEngine.BTN_CROSS
                    KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_L -> NativeEmuEngine.BTN_CIRCLE
                    KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_J -> NativeEmuEngine.BTN_SQUARE
                    KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_I -> NativeEmuEngine.BTN_TRIANGLE
                    KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_Q -> NativeEmuEngine.BTN_L1
                    KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_E -> NativeEmuEngine.BTN_R1
                    KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_ENTER -> NativeEmuEngine.BTN_START
                    KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_TAB -> NativeEmuEngine.BTN_SELECT
                    else -> 0
                }
                if (bit != 0) {
                    if (keyEvent.type == KeyEventType.KeyDown) {
                        onBtnPress(bit)
                    } else if (keyEvent.type == KeyEventType.KeyUp) {
                        onBtnRelease(bit)
                    }
                    true
                } else {
                    false
                }
            }
    ) {
        // Game Canvas
        if (!isLoading) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .align(Alignment.Center)
            ) {
                val dummy = triggerDraw
                val screenW = size.width
                val screenH = size.height
                val targetH = screenW * 272f / 480f
                val offsetY = (screenH - targetH) / 2f

                drawImage(
                    image = bitmap.asImageBitmap(),
                    dstSize = androidx.compose.ui.unit.IntSize(screenW.toInt(), targetH.toInt()),
                    dstOffset = IntOffset(0, offsetY.toInt())
                )
            }
        }

        if (isLoading) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(56.dp),
                    color = Color(0xFF00E676),
                    strokeWidth = 4.dp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Инициализация ядра PSP: ${game.title}...",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            // HUD & Controls
            Column(modifier = Modifier.fillMaxSize()) {
                // Top HUD
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Performance info badge
                    if (showPerfOverlay) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.75f),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E3252))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "FPS: $fps",
                                    color = if (fps >= 55) Color(0xFF00E676) else if (fps >= 30) Color(0xFFFFD54F) else Color(0xFFFF5252),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${frameTimeMs}ms",
                                    color = Color(0xFF90CAF9),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                if (ips > 0) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${ips / 1000}k IPS",
                                        color = Color(0xFFB0BEC5),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                if (isTurbo) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = Color(0xFFFF9800),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            "2x TURBO",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    // Top Quick Action Icons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { isTurbo = !isTurbo },
                            modifier = Modifier
                                .size(36.dp)
                                .background(if (isTurbo) Color(0xFFFF9800) else Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(
                                Icons.Default.FastForward,
                                contentDescription = "Turbo",
                                tint = if (isTurbo) Color.Black else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = {
                                val contentValues = ContentValues().apply {
                                    put(MediaStore.MediaColumns.DISPLAY_NAME, "NextEmu_${game.title.replace(" ", "_")}_${System.currentTimeMillis()}.png")
                                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NextEmu")
                                }
                                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                                if (uri != null) {
                                    context.contentResolver.openOutputStream(uri)?.use { out ->
                                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                                    }
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Скриншот сохранён в Галерею (NextEmu)")
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(Icons.Default.CameraAlt, "Screenshot", tint = Color.White, modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = { showQuickMenu = true },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(Icons.Default.Tune, "Меню настроек", tint = Color(0xFF00E676), modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = { isPaused = !isPaused },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(
                                if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                "Pause",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onExit,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Red.copy(alpha = 0.8f), CircleShape)
                        ) {
                            Icon(Icons.Default.Close, "Выход", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Triggers (L1 / R1)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    VirtualTriggerButton(
                        label = "L1",
                        opacity = buttonOpacity,
                        onPress = { onBtnPress(NativeEmuEngine.BTN_L1) },
                        onRelease = { onBtnRelease(NativeEmuEngine.BTN_L1) }
                    )
                    VirtualTriggerButton(
                        label = "R1",
                        opacity = buttonOpacity,
                        onPress = { onBtnPress(NativeEmuEngine.BTN_R1) },
                        onRelease = { onBtnRelease(NativeEmuEngine.BTN_R1) }
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Bottom Controls (D-Pad, Stick, Select/Start, Action Buttons)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Left Column: D-Pad & Analog Stick
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // D-Pad Cross Layout
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            VirtualButton(
                                label = "▲",
                                opacity = buttonOpacity,
                                onPress = { onBtnPress(NativeEmuEngine.BTN_UP) },
                                onRelease = { onBtnRelease(NativeEmuEngine.BTN_UP) }
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                VirtualButton(
                                    label = "◄",
                                    opacity = buttonOpacity,
                                    onPress = { onBtnPress(NativeEmuEngine.BTN_LEFT) },
                                    onRelease = { onBtnRelease(NativeEmuEngine.BTN_LEFT) }
                                )
                                Spacer(modifier = Modifier.width(36.dp))
                                VirtualButton(
                                    label = "►",
                                    opacity = buttonOpacity,
                                    onPress = { onBtnPress(NativeEmuEngine.BTN_RIGHT) },
                                    onRelease = { onBtnRelease(NativeEmuEngine.BTN_RIGHT) }
                                )
                            }
                            VirtualButton(
                                label = "▼",
                                opacity = buttonOpacity,
                                onPress = { onBtnPress(NativeEmuEngine.BTN_DOWN) },
                                onRelease = { onBtnRelease(NativeEmuEngine.BTN_DOWN) }
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Analog Stick
                        AnalogStick(
                            onMove = { x, y ->
                                analogLx = (x * 127f + 128f).roundToInt().coerceIn(0, 255)
                                analogLy = (y * 127f + 128f).roundToInt().coerceIn(0, 255)
                                updatePadState()
                            },
                            onRelease = {
                                analogLx = 128
                                analogLy = 128
                                updatePadState()
                            }
                        )
                    }

                    // Center: Select & Start Buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        SmallVirtualButton(
                            label = "SELECT",
                            opacity = buttonOpacity,
                            onPress = { onBtnPress(NativeEmuEngine.BTN_SELECT) },
                            onRelease = { onBtnRelease(NativeEmuEngine.BTN_SELECT) }
                        )
                        SmallVirtualButton(
                            label = "START",
                            opacity = buttonOpacity,
                            onPress = { onBtnPress(NativeEmuEngine.BTN_START) },
                            onRelease = { onBtnRelease(NativeEmuEngine.BTN_START) }
                        )
                    }

                    // Right Column: PSP Action Buttons (Triangle, Square, Circle, Cross)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        VirtualButton(
                            label = "△",
                            textColor = Color(0xFF00E676),
                            opacity = buttonOpacity,
                            onPress = { onBtnPress(NativeEmuEngine.BTN_TRIANGLE) },
                            onRelease = { onBtnRelease(NativeEmuEngine.BTN_TRIANGLE) }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            VirtualButton(
                                label = "□",
                                textColor = Color(0xFFFF80AB),
                                opacity = buttonOpacity,
                                onPress = { onBtnPress(NativeEmuEngine.BTN_SQUARE) },
                                onRelease = { onBtnRelease(NativeEmuEngine.BTN_SQUARE) }
                            )
                            Spacer(modifier = Modifier.width(36.dp))
                            VirtualButton(
                                label = "○",
                                textColor = Color(0xFFFF5252),
                                opacity = buttonOpacity,
                                onPress = { onBtnPress(NativeEmuEngine.BTN_CIRCLE) },
                                onRelease = { onBtnRelease(NativeEmuEngine.BTN_CIRCLE) }
                            )
                        }
                        VirtualButton(
                            label = "✕",
                            textColor = Color(0xFF448AFF),
                            opacity = buttonOpacity,
                            onPress = { onBtnPress(NativeEmuEngine.BTN_CROSS) },
                            onRelease = { onBtnRelease(NativeEmuEngine.BTN_CROSS) }
                        )
                    }
                }
            }
        }

        // Pause Overlay
        if (isPaused) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .widthIn(max = 360.dp)
                        .padding(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF152238)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2979FF))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "ПАУЗА ЭМУЛЯТОРА",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = game.title,
                            fontSize = 13.sp,
                            color = Color(0xFF00E676)
                        )
                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = { isPaused = false },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ПРОДОЛЖИТЬ", fontWeight = FontWeight.Bold, color = Color.Black)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedButton(
                            onClick = {
                                if (NativeEmuEngine.isNativeLoaded()) {
                                    val ok = NativeEmuEngine.saveState(1)
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(if (ok) "Быстрое сохранение в Слот #1 выполнено!" else "Ошибка сохранения")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Быстрое Сохранение (Слот 1)", color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = {
                                if (NativeEmuEngine.isNativeLoaded()) {
                                    val ok = NativeEmuEngine.loadState(1)
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(if (ok) "Загружено состояние из Слота #1!" else "Ошибка загрузки")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Restore, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Быстрая Загрузка (Слот 1)", color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        TextButton(onClick = onExit) {
                            Text("Выйти в библиотеку", color = Color(0xFFFF5252))
                        }
                    }
                }
            }
        }

        // Quick Settings Sheet
        if (showQuickMenu) {
            AlertDialog(
                onDismissRequest = { showQuickMenu = false },
                title = { Text("Быстрые Настройки", color = Color.White, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFF152238),
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Индикатор FPS / IPS", color = Color.White, fontSize = 14.sp)
                            Switch(
                                checked = showPerfOverlay,
                                onCheckedChange = { showPerfOverlay = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E676))
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Виброотклик (Haptic)", color = Color.White, fontSize = 14.sp)
                            Switch(
                                checked = hapticsEnabled,
                                onCheckedChange = { hapticsEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E676))
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Прозрачность кнопок: ${(buttonOpacity * 100).toInt()}%",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                        Slider(
                            value = buttonOpacity,
                            onValueChange = { buttonOpacity = it },
                            valueRange = 0.15f..0.85f,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFF00E676), activeTrackColor = Color(0xFF00E676))
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Сохранения (Save States):", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (slot in 1..3) {
                                OutlinedButton(
                                    onClick = {
                                        if (NativeEmuEngine.isNativeLoaded()) {
                                            val ok = NativeEmuEngine.saveState(slot)
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar(if (ok) "Сохранено в Слот $slot" else "Ошибка")
                                            }
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(4.dp)
                                ) {
                                    Text("Save $slot", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showQuickMenu = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF))
                    ) {
                        Text("Готово", color = Color.White)
                    }
                }
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 64.dp)
        )
    }
}

@Composable
fun VirtualButton(
    label: String,
    textColor: Color = Color.White,
    opacity: Float = 0.35f,
    onPress: () -> Unit,
    onRelease: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .size(54.dp)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        isPressed = true
                        onPress()
                        waitForUpOrCancellation()
                        isPressed = false
                        onRelease()
                    }
                }
            },
        shape = CircleShape,
        color = if (isPressed) Color(0xFF00E676).copy(alpha = 0.6f) else Color.White.copy(alpha = opacity),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isPressed) Color(0xFF00E676) else Color.White.copy(alpha = 0.3f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (isPressed) Color.Black else textColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun VirtualTriggerButton(
    label: String,
    opacity: Float = 0.35f,
    onPress: () -> Unit,
    onRelease: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .width(84.dp)
            .height(42.dp)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        isPressed = true
                        onPress()
                        waitForUpOrCancellation()
                        isPressed = false
                        onRelease()
                    }
                }
            },
        shape = RoundedCornerShape(10.dp),
        color = if (isPressed) Color(0xFF2979FF).copy(alpha = 0.7f) else Color.White.copy(alpha = opacity),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isPressed) Color(0xFF2979FF) else Color.White.copy(alpha = 0.3f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun SmallVirtualButton(
    label: String,
    opacity: Float = 0.35f,
    onPress: () -> Unit,
    onRelease: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier
            .width(72.dp)
            .height(32.dp)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        isPressed = true
                        onPress()
                        waitForUpOrCancellation()
                        isPressed = false
                        onRelease()
                    }
                }
            },
        shape = RoundedCornerShape(16.dp),
        color = if (isPressed) Color(0xFF00E676).copy(alpha = 0.6f) else Color.White.copy(alpha = opacity),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isPressed) Color(0xFF00E676) else Color.White.copy(alpha = 0.3f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun AnalogStick(
    onMove: (Float, Float) -> Unit,
    onRelease: () -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val radius = 55f

    Box(
        modifier = Modifier
            .size(96.dp)
            .background(Color.White.copy(alpha = 0.12f), CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.toInt(), offsetY.toInt()) }
                .size(46.dp)
                .background(Color(0xFF2979FF).copy(alpha = 0.6f), CircleShape)
                .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val newX = offsetX + dragAmount.x
                            val newY = offsetY + dragAmount.y
                            val dist = sqrt(newX * newX + newY * newY)
                            if (dist <= radius) {
                                offsetX = newX
                                offsetY = newY
                            } else {
                                offsetX = newX * radius / dist
                                offsetY = newY * radius / dist
                            }
                            onMove(offsetX / radius, offsetY / radius)
                        },
                        onDragEnd = {
                            offsetX = 0f
                            offsetY = 0f
                            onRelease()
                        },
                        onDragCancel = {
                            offsetX = 0f
                            offsetY = 0f
                            onRelease()
                        }
                    )
                }
        )
    }
}
