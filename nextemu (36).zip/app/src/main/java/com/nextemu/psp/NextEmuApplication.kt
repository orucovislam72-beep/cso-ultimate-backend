package com.nextemu.psp

import android.app.Application

class NextEmuApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Firebase отключён — используем заглушку
    }
}
