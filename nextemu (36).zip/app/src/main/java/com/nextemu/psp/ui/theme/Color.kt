package com.nextemu.psp.ui.theme

import androidx.compose.ui.graphics.Color

val PspBluePrimary = Color(0xFF2979FF)
val PspBlueVariant = Color(0xFF1565C0)
val PlasmaGreen = Color(0xFF00E676)
val PlasmaGreenDark = Color(0xFF00A852)

val DarkBackground = Color(0xFF050D1A)
val DarkSurface = Color(0xFF0E1726)
val DarkCardSurface = Color(0xFF152238)
val DarkBorder = Color(0xFF1E3252)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF94A3B8)
val TextAccent = Color(0xFF00E676)

val TagPsp = Color(0xFF2979FF)
val TagPsx = Color(0xFFE91E63)
val TagGba = Color(0xFFFF9800)

