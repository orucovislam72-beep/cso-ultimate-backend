package com.nextemu.psp.engine

import android.content.Context
import android.net.Uri
import android.util.Log
import java.io.File

object NativeEmuEngine {
    private const val TAG = "NativeEmuEngine"
    private var isLoaded = false

    // PSP Button bitmask constants
    const val BTN_SELECT = 0x0001
    const val BTN_START = 0x0008
    const val BTN_UP = 0x0010
    const val BTN_RIGHT = 0x0020
    const val BTN_DOWN = 0x0040
    const val BTN_LEFT = 0x0080
    const val BTN_L1 = 0x0100
    const val BTN_R1 = 0x0200
    const val BTN_TRIANGLE = 0x1000
    const val BTN_CIRCLE = 0x2000
    const val BTN_CROSS = 0x4000
    const val BTN_SQUARE = 0x8000

    init {
        try {
            System.loadLibrary("nextemu")
            isLoaded = true
            Log.i(TAG, "Native library 'nextemu' loaded successfully.")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Failed to load native library 'nextemu'", e)
            isLoaded = false
        }
    }

    fun isNativeLoaded(): Boolean = isLoaded

    external fun getEngineVersion(): String
    external fun initCore(gamePath: String): Boolean
    external fun initCoreFd(fd: Int, fileSize: Long, gamePath: String): Boolean
    external fun getCoreStatus(): String
    external fun stepFrame(): String
    external fun executeNativeScript(script: String): String
    
    // стейт-машина
    external fun saveState(slot: Int): Boolean
    external fun loadState(slot: Int): Boolean
    
    // доступ к памяти (грязный хак)
    external fun readMemory32(addr: Long): Int
    external fun writeMemory32(addr: Long, value: Int)
    
    // CPU State
    external fun nativeGetCpuState(): String
    
    // Game Info
    external fun nativeGetGameInfo(): String
    
    // GPU
    external fun nativeGpuStep()
    external fun nativeGpuSetDisplayList(addr: Long)
    
    // Save State Setup
    external fun nativeSetSavesDir(path: String)
    
    // ELF & Performance
    external fun nativeLoadElf(path: String): Boolean
    external fun nativeGetIPS(): Long
    external fun nativeRunCpuTests(): String
    external fun nativeRunHleTests(): String
    external fun nativeRunGeTests(): String
    external fun nativeRunGpuTests(): String
    external fun nativeGetFramebuffer(outPixels: IntArray, width: Int, height: Int): Boolean
    external fun nativeSetButtonState(buttons: Int, lx: Int, ly: Int)

    /**
     * Safely opens an ISO file regardless of whether it is a content:// URI or a local file path.
     * Verifies availability, gets file descriptor, and passes to native C++ core.
     */
    fun openIso(context: Context, pathOrUri: String): Boolean {
        if (!isLoaded) {
            Log.e(TAG, "Cannot open ISO: Native engine not loaded")
            return false
        }
        if (pathOrUri.isBlank()) {
            Log.e(TAG, "Cannot open ISO: Path or URI is blank")
            return false
        }

        try {
            if (pathOrUri.startsWith("content://")) {
                val uri = Uri.parse(pathOrUri)
                try {
                    val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    context.contentResolver.takePersistableUriPermission(uri, flags)
                } catch (e: Exception) {
                    // Ignore if persistable permissions not supported by URI provider
                }

                val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd != null) {
                    val fd = pfd.detachFd()
                    val size = pfd.statSize
                    Log.i(TAG, "Successfully opened content URI. FD: $fd, Size: $size bytes")
                    return initCoreFd(fd, size, pathOrUri)
                } else {
                    Log.e(TAG, "Failed to obtain FileDescriptor for URI: $pathOrUri")
                    return false
                }
            } else {
                val file = File(pathOrUri)
                if (file.exists() && file.canRead()) {
                    val size = file.length()
                    Log.i(TAG, "Opened local file: ${file.absolutePath}, Size: $size bytes")
                    return initCoreFd(-1, size, file.absolutePath)
                } else {
                    try {
                        val pfd = context.contentResolver.openFileDescriptor(Uri.fromFile(file), "r")
                        if (pfd != null) {
                            val fd = pfd.detachFd()
                            val size = pfd.statSize
                            return initCoreFd(fd, size, file.absolutePath)
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Fallback FileDescriptor failed for path: $pathOrUri", e)
                    }
                    Log.e(TAG, "File does not exist or is not readable: $pathOrUri")
                    return false
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException opening ISO: ${e.message}", e)
            return false
        } catch (e: Exception) {
            Log.e(TAG, "Error opening ISO: ${e.message}", e)
            return false
        }
    }
}
