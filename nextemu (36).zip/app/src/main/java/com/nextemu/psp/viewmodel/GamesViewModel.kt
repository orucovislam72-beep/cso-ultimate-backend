package com.nextemu.psp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nextemu.psp.data.GameFile
import com.nextemu.psp.data.GameRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SortOrder { TITLE, DATE_PLAYED, RATING, SIZE }
enum class PlatformFilter { ALL, PSP, PSX, GBA, FAVORITES }

class GamesViewModel(private val repository: GameRepository) : ViewModel() {
    private val _sortOrder = MutableStateFlow(SortOrder.DATE_PLAYED)
    val sortOrder: StateFlow<SortOrder> = _sortOrder

    private val _platformFilter = MutableStateFlow(PlatformFilter.ALL)
    val platformFilter: StateFlow<PlatformFilter> = _platformFilter

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    init {
        viewModelScope.launch {
            val existingGames = repository.allGames.first()
            if (existingGames.isEmpty()) {
                val now = System.currentTimeMillis()
                val sampleGames = listOf(
                    GameFile(
                        title = "God of War: Chains of Olympus",
                        gameId = "UCES00710",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/UCES00710.png",
                        path = "/sdcard/PSP/GAME/God_of_War_Chains_of_Olympus.iso",
                        platform = "PSP",
                        fileSize = "1.5 GB",
                        genre = "Слэшер / Экшен",
                        rating = 4.9f,
                        isFavorite = true,
                        lastPlayedTimestamp = now - 10000
                    ),
                    GameFile(
                        title = "Grand Theft Auto: Liberty City Stories",
                        gameId = "ULES00151",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES00151.png",
                        path = "/sdcard/PSP/GAME/GTA_Liberty_City_Stories.iso",
                        platform = "PSP",
                        fileSize = "1.2 GB",
                        genre = "Открытый мир / Экшен",
                        rating = 4.8f,
                        isFavorite = true,
                        lastPlayedTimestamp = now - 20000
                    ),
                    GameFile(
                        title = "Tekken 6",
                        gameId = "ULES01376",
                        format = "CSO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES01376.png",
                        path = "/sdcard/PSP/GAME/Tekken_6.cso",
                        platform = "PSP",
                        fileSize = "820 MB",
                        genre = "Файтинг",
                        rating = 4.7f,
                        isFavorite = false,
                        lastPlayedTimestamp = now - 30000
                    ),
                    GameFile(
                        title = "Monster Hunter Freedom Unite",
                        gameId = "ULES01213",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES01213.png",
                        path = "/sdcard/PSP/GAME/Monster_Hunter_Freedom_Unite.iso",
                        platform = "PSP",
                        fileSize = "1.1 GB",
                        genre = "RPG / Охота",
                        rating = 4.8f,
                        isFavorite = false,
                        lastPlayedTimestamp = now - 40000
                    ),
                    GameFile(
                        title = "Persona 3 Portable",
                        gameId = "ULES01523",
                        format = "ISO",
                        coverArt = "https://art.gametdb.com/psp/coverEN/ULES01523.png",
                        path = "/sdcard/PSP/GAME/Persona_3_Portable.iso",
                        platform = "PSP",
                        fileSize = "980 MB",
                        genre = "JRPG",
                        rating = 4.9f,
                        isFavorite = true,
                        lastPlayedTimestamp = now - 50000
                    ),
                    GameFile(
                        title = "Castlevania: Symphony of the Night",
                        path = "/sdcard/PSX/GAME/Castlevania_SOTN.bin",
                        platform = "PSX",
                        fileSize = "520 MB",
                        genre = "Метроидвания",
                        rating = 4.9f,
                        isFavorite = false,
                        lastPlayedTimestamp = now - 60000
                    ),
                    GameFile(
                        title = "Pokemon Emerald Version",
                        path = "/sdcard/GBA/GAME/Pokemon_Emerald.gba",
                        platform = "GBA",
                        fileSize = "16 MB",
                        genre = "Приключение / RPG",
                        rating = 4.8f,
                        isFavorite = false,
                        lastPlayedTimestamp = now - 70000
                    )
                )
                sampleGames.forEach { repository.insert(it) }
            }
        }
    }

    val games: StateFlow<List<GameFile>> = combine(
        repository.allGames,
        _sortOrder,
        _platformFilter,
        _searchQuery
    ) { gamesList, order, platform, query ->
        var filtered = gamesList.filter { game ->
            val matchesQuery = query.isBlank() || game.title.contains(query, ignoreCase = true) || game.genre.contains(query, ignoreCase = true)
            val matchesPlatform = when (platform) {
                PlatformFilter.ALL -> true
                PlatformFilter.PSP -> game.platform.equals("PSP", ignoreCase = true)
                PlatformFilter.PSX -> game.platform.equals("PSX", ignoreCase = true)
                PlatformFilter.GBA -> game.platform.equals("GBA", ignoreCase = true)
                PlatformFilter.FAVORITES -> game.isFavorite
            }
            matchesQuery && matchesPlatform
        }

        when (order) {
            SortOrder.TITLE -> filtered.sortedBy { it.title }
            SortOrder.DATE_PLAYED -> filtered.sortedByDescending { it.lastPlayedTimestamp }
            SortOrder.RATING -> filtered.sortedByDescending { it.rating }
            SortOrder.SIZE -> filtered.sortedByDescending { it.fileSize }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setSortOrder(order: SortOrder) {
        _sortOrder.value = order
    }

    fun setPlatformFilter(filter: PlatformFilter) {
        _platformFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(game: GameFile) {
        viewModelScope.launch {
            repository.toggleFavorite(game.id, game.isFavorite)
        }
    }

    fun markGamePlayed(game: GameFile) {
        viewModelScope.launch {
            repository.updateLastPlayed(game.id, System.currentTimeMillis())
        }
    }

    fun addCustomGame(uriString: String, name: String, formattedSize: String = "Custom ISO") {
        viewModelScope.launch {
            val ext = name.substringAfterLast('.', "iso").uppercase()
            val platform = when (ext) {
                "GBA" -> "GBA"
                "BIN", "CUE" -> "PSX"
                else -> "PSP"
            }
            repository.insert(
                GameFile(
                    title = name.substringBeforeLast('.'),
                    gameId = "UNKNOWN",
                    format = ext,
                    path = uriString,
                    platform = platform,
                    fileSize = formattedSize,
                    genre = "Импортированная игра",
                    rating = 5.0f,
                    isFavorite = true,
                    lastPlayedTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    fun scanAndAddDummyGame() {
        viewModelScope.launch {
            val gamesList = listOf(
                Triple("God of War: Ghost of Sparta", "PSP", "1.6 GB"),
                Triple("Grand Theft Auto: Vice City Stories", "PSP", "1.1 GB"),
                Triple("Crisis Core: Final Fantasy VII", "PSP", "1.4 GB"),
                Triple("Metal Gear Solid: Peace Walker", "PSP", "1.3 GB"),
                Triple("Tekken 3", "PSX", "450 MB"),
                Triple("The Legend of Zelda: The Minish Cap", "GBA", "12 MB")
            )
            val selected = gamesList.random()
            repository.insert(
                GameFile(
                    title = selected.first,
                    path = "/storage/emulated/0/Download/Games/${selected.first}.iso",
                    platform = selected.second,
                    fileSize = selected.third,
                    genre = "Отсканировано",
                    rating = 4.8f,
                    isFavorite = false,
                    lastPlayedTimestamp = System.currentTimeMillis()
                )
            )
        }
    }
}

class GamesViewModelFactory(private val repository: GameRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GamesViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GamesViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

