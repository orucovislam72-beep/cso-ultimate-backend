package com.nextemu.psp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050D1A))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp)
    ) {
        item {
            Text(
                text = "Настройки Эмулятора",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(bottom = 24.dp, top = 16.dp)
            )
        }

        item {
            SettingsCategory("Графический Движок")
            
            val renderers = listOf("Vulkan (Рекомендуется)", "OpenGL ES 3.2", "Software Renderer")
            var selectedRenderer by remember { mutableStateOf(renderers[0]) }
            SettingsDropdownItem(
                icon = Icons.Default.Memory,
                title = "Графический Backend",
                description = "Влияет на FPS и совместимость рендеринга",
                options = renderers,
                selectedOption = selectedRenderer,
                onOptionSelected = { selectedRenderer = it }
            )

            val resolutions = listOf("1x PSP (480x272)", "2x PSP (960x544)", "3x PSP (1440x816 HD)", "4x PSP (1920x1088 FHD)")
            var selectedRes by remember { mutableStateOf(resolutions[1]) }
            SettingsDropdownItem(
                icon = Icons.Default.DisplaySettings,
                title = "Разрешение рендеринга",
                description = "Множитель оригинального разрешения PSP",
                options = resolutions,
                selectedOption = selectedRes,
                onOptionSelected = { selectedRes = it }
            )

            var frameSkip by remember { mutableFloatStateOf(0f) }
            SettingsSliderItem(
                icon = Icons.Default.Speed,
                title = "Пропуск кадров (Frame Skip)",
                description = "Повышает плавность при недостаточно мощном CPU",
                value = frameSkip,
                onValueChange = { frameSkip = it },
                valueRange = 0f..5f,
                steps = 4,
                valueText = frameSkip.toInt().toString()
            )

            val shaderOptions = listOf("Отключено", "CRT Scanlines", "FXAA Anti-Aliasing", "xBRZ 4x Upscaler")
            var selectedShader by remember { mutableStateOf(shaderOptions[1]) }
            SettingsDropdownItem(
                icon = Icons.Default.Image,
                title = "Графический Шейдер",
                description = "Фильтр постобработки изображения",
                options = shaderOptions,
                selectedOption = selectedShader,
                onOptionSelected = { selectedShader = it }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            SettingsCategory("Аудио и Сохранения")
            
            var volume by remember { mutableFloatStateOf(100f) }
            SettingsSliderItem(
                icon = Icons.Default.VolumeUp,
                title = "Громкость звука",
                description = "Глобальный уровень громкости SPU2",
                value = volume,
                onValueChange = { volume = it },
                valueRange = 0f..100f,
                steps = 10,
                valueText = "${volume.toInt()}%"
            )

            SettingsToggleItem(
                icon = Icons.Default.Save,
                title = "Авто-сохранение при выходе",
                description = "Создавать Save State в Слот #1 при сворачивании",
                initialState = true
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            SettingsCategory("Управление и Геймпад")
            
            SettingsToggleItem(
                icon = Icons.Default.Gamepad,
                title = "Виртуальный контроллер",
                description = "Отображать D-Pad и кнопки на экране",
                initialState = true
            )
            
            SettingsToggleItem(
                icon = Icons.Default.Vibration,
                title = "Тактильный отклик (Vibration)",
                description = "Виброотклик при касании виртуальных клавиш",
                initialState = true
            )
            
            SettingsToggleItem(
                icon = Icons.Default.ControlPoint,
                title = "Аналоговый стик",
                description = "Использовать круговой джойстик вместо D-Pad",
                initialState = true
            )
        }
        
        item {
            Spacer(modifier = Modifier.height(24.dp))
            SettingsCategory("Дополнительно")
            
            SettingsToggleItem(
                icon = Icons.Default.Info,
                title = "Показывать FPS",
                description = "Отображать счетчик кадров в углу экрана",
                initialState = true
            )
        }
    }
}

@Composable
fun SettingsCategory(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = Color(0xFF00E676),
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(vertical = 12.dp)
    )
}

@Composable
fun SettingsToggleItem(
    icon: ImageVector,
    title: String,
    description: String,
    initialState: Boolean
) {
    var checked by remember { mutableStateOf(initialState) }
    
    Surface(
        color = Color(0xFF152238),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF2979FF), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(description, color = Color.Gray, fontSize = 12.sp)
            }
            Switch(
                checked = checked,
                onCheckedChange = { checked = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF00E676),
                    checkedTrackColor = Color(0xFF00E676).copy(alpha = 0.5f)
                )
            )
        }
    }
}

@Composable
fun SettingsSliderItem(
    icon: ImageVector,
    title: String,
    description: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    valueText: String = ""
) {
    Surface(
        color = Color(0xFF152238),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Color(0xFF2979FF), modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(description, color = Color.Gray, fontSize = 12.sp)
                }
                if (valueText.isNotBlank()) {
                    Text(valueText, color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
                }
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = valueRange,
                steps = steps,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF00E676),
                    activeTrackColor = Color(0xFF00E676)
                )
            )
        }
    }
}

@Composable
fun SettingsDropdownItem(
    icon: ImageVector,
    title: String,
    description: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    
    Surface(
        color = Color(0xFF152238),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth().clickable { expanded = true }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF2979FF), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(description, color = Color.Gray, fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(selectedOption, color = Color(0xFF00E676), fontSize = 14.sp)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.Gray)
            }
            
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color(0xFF152238))
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option, color = Color.White) },
                        onClick = {
                            onOptionSelected(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
