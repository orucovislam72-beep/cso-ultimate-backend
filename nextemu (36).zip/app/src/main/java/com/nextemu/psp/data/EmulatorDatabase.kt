package com.nextemu.psp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [GameFile::class], version = 3, exportSchema = false)
abstract class EmulatorDatabase : RoomDatabase() {
    abstract fun gameFileDao(): GameFileDao

    companion object {
        @Volatile
        private var INSTANCE: EmulatorDatabase? = null

        fun getDatabase(context: Context): EmulatorDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EmulatorDatabase::class.java,
                    "emulator_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

