package com.nextemu.psp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.nextemu.psp.engine.NativeEmuEngine

private fun parseLongOrHex(str: String): Long? {
    val clean = str.trim()
    return try {
        if (clean.startsWith("0x", ignoreCase = true)) {
            clean.substring(2).toLong(16)
        } else {
            clean.toLong()
        }
    } catch (e: Exception) {
        null
    }
}

fun neslExecute(command: String, env: MutableMap<String, String>): String {
    val input = command.trim()
    if (input.isEmpty()) return ""

    if (input.startsWith("core.") || input == "sys.native") {
        if (NativeEmuEngine.isNativeLoaded()) {
            return NativeEmuEngine.executeNativeScript(input)
        } else {
            return "Error: Native library not loaded"
        }
    }

    // emu.version() / emu.version
    if (input == "emu.version()" || input == "emu.version") {
        return if (NativeEmuEngine.isNativeLoaded()) {
            NativeEmuEngine.getEngineVersion()
        } else "Error: Native engine not loaded"
    }

    // emu.cpu() / emu.cpu
    if (input == "emu.cpu()" || input == "emu.cpu") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        val rawState = NativeEmuEngine.nativeGetCpuState()
        return try {
            val regNames = arrayOf(
                "zr", "at", "v0", "v1", "a0", "a1", "a2", "a3",
                "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
                "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
                "t8", "t9", "k0", "k1", "gp", "sp", "fp", "ra"
            )
            val pcMatch = Regex("\"pc\":\\s*(\\d+)").find(rawState)
            val pcVal = pcMatch?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val regsMatch = Regex("\"regs\":\\s*\\[(.*?)\\]").find(rawState)
            val regValues = regsMatch?.groupValues?.get(1)
                ?.split(",")
                ?.mapNotNull { it.trim().toLongOrNull() }
                ?: emptyList()

            val sb = StringBuilder()
            sb.append(String.format("PC: 0x%08X (%d)\n", pcVal, pcVal))
            sb.append("--------------------------------------------------\n")
            for (i in 0 until 32) {
                val val32 = if (i < regValues.size) regValues[i] else 0L
                val name = regNames[i]
                sb.append(String.format("r%02d (%s): 0x%08X", i, name, val32))
                if ((i + 1) % 2 == 0) sb.append("\n") else sb.append("  |  ")
            }
            sb.toString().trimEnd()
        } catch (e: Exception) {
            rawState
        }
    }

    // emu.ips() / emu.ips
    if (input == "emu.ips()" || input == "emu.ips") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        val ips = NativeEmuEngine.nativeGetIPS()
        return String.format("Инструкций/сек: %,d", ips)
    }

    // emu.cputest() / emu.cputest
    if (input == "emu.cputest()" || input == "emu.cputest") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        return NativeEmuEngine.nativeRunCpuTests()
    }

    // emu.hletest() / emu.hletest
    if (input == "emu.hletest()" || input == "emu.hletest") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        return NativeEmuEngine.nativeRunHleTests()
    }

    // emu.gputest() / emu.gputest / emu.getest() / emu.getest
    if (input == "emu.gputest()" || input == "emu.gputest" || input == "emu.getest()" || input == "emu.getest") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        return NativeEmuEngine.nativeRunGpuTests()
    }

    // emu.geinfo() / emu.geinfo
    if (input == "emu.geinfo()" || input == "emu.geinfo") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        return NativeEmuEngine.executeNativeScript("emu.geinfo")
    }

    // emu.gelog() / emu.gelog
    if (input == "emu.gelog()" || input == "emu.gelog") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        return NativeEmuEngine.executeNativeScript("emu.gelog")
    }

    // emu.gameinfo() / emu.gameinfo
    if (input == "emu.gameinfo()" || input == "emu.gameinfo") {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        val json = NativeEmuEngine.nativeGetGameInfo()
        val titleMatch = Regex("\"title\":\\s*\"([^\"]*)\"").find(json)
        val idMatch = Regex("\"gameId\":\\s*\"([^\"]*)\"").find(json)
        val title = titleMatch?.groupValues?.get(1) ?: "Unknown"
        val gameId = idMatch?.groupValues?.get(1) ?: "UNKNOWN"
        return "Title: $title | ID: $gameId"
    }

    // emu.memread <addr> / emu.memread(<addr>)
    if (input.startsWith("emu.memread")) {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        val clean = input.removePrefix("emu.memread").trim().removePrefix("(").removeSuffix(")").trim()
        val addr = parseLongOrHex(clean) ?: return "Error: Invalid address '$clean'"
        val val32 = NativeEmuEngine.readMemory32(addr)
        return String.format("0x%08X = 0x%08X", addr, val32)
    }

    // emu.memwrite <addr> <val> / emu.memwrite(<addr>, <val>)
    if (input.startsWith("emu.memwrite")) {
        if (!NativeEmuEngine.isNativeLoaded()) return "Error: Native engine not loaded"
        val clean = input.removePrefix("emu.memwrite").trim().removePrefix("(").removeSuffix(")").trim()
        val parts = clean.split(Regex("[,\\s]+")).filter { it.isNotBlank() }
        if (parts.size >= 2) {
            val addr = parseLongOrHex(parts[0]) ?: return "Error: Invalid address '${parts[0]}'"
            val valLong = parseLongOrHex(parts[1]) ?: return "Error: Invalid value '${parts[1]}'"
            val val32 = valLong.toInt()
            NativeEmuEngine.writeMemory32(addr, val32)
            return String.format("Written 0x%08X → 0x%08X", val32, addr)
        }
        return "Error: Usage emu.memwrite <addr> <val>"
    }

    // Help command
    if (input == "help") {
        return "NEX-Script (NESL) v1.0\n" +
               "Commands:\n" +
               "- let <var> = <value>   : Assign variable\n" +
               "- print <var/text>      : Print to console\n" +
               "- sys.info()            : Emulator status\n" +
               "- sys.clear()           : Clear variables\n" +
               "- emu.cpu()             : Get CPU state (PC & 32 regs table)\n" +
               "- emu.ips()             : Get instructions per second\n" +
               "- emu.cputest()         : Run MIPS CPU unit tests\n" +
               "- emu.hletest()         : Run PSP HLE system unit tests\n" +
               "- emu.getest()          : Run PSP GE & Display unit tests\n" +
               "- emu.geinfo()          : Get GE & Display pipeline state\n" +
               "- emu.gelog()           : Get GE command execution trace log\n" +
               "- emu.gameinfo()        : Get game title & ID\n" +
               "- emu.memread <addr>    : Read 32-bit memory word\n" +
               "- emu.memwrite <a > <v> : Write 32-bit memory word\n" +
               "- emu.version()         : Core version info\n" +
               "- emu.fps(value)        : Set target FPS\n" +
               "- emu.screenshot()      : Take screenshot\n" +
               "- emu.savestate(slot)   : Quick Save"
    }

    // Emulator specific
    
    if (input.startsWith("emu.memread ")) {
        val addrStr = input.removePrefix("emu.memread ").trim().removePrefix("0x")
        try {
            val addr = addrStr.toLong(16)
            val value = NativeEmuEngine.readMemory32(addr)
            return "0x%08X = 0x%08X".format(addr, value)
        } catch (e: Exception) {
            return "Error: Invalid address format"
        }
    }
if (input == "emu.screenshot()") return "Screenshot saved to /sdcard/NextEmu/screens/"
    if (input.startsWith("emu.savestate(")) return "Saved state to slot."

    // Variable assignment: let x = 10
    if (input.startsWith("let ")) {
        val parts = input.removePrefix("let ").split("=", limit = 2)
        if (parts.size == 2) {
            val varName = parts[0].trim()
            val varValue = parts[1].trim()
            env[varName] = varValue
            return "Set $varName to $varValue"
        }
        return "Error: Invalid syntax. Use 'let name = value'"
    }

    // Print command: print x
    if (input.startsWith("print ")) {
        val arg = input.removePrefix("print ").trim()
        if (arg.startsWith("\"") && arg.endsWith("\"")) {
            return arg.removeSurrounding("\"")
        }
        return env[arg] ?: "Error: Undefined variable '$arg'"
    }

    // System commands
    when (input) {
        "sys.info()" -> return "NextEmu Engine: Running\nMemory: 245MB/1024MB\nBackend: Vulkan"
        "sys.clear()" -> {
            env.clear()
            return "Environment cleared."
        }
    }

    // Emulator specific
    if (input.startsWith("emu.fps(")) {
        val fps = input.removePrefix("emu.fps(").removeSuffix(")")
        return "System FPS limit set to $fps"
    }

    return "Error: Unknown command '$input'"
}

fun executeCommand(command: String, env: MutableMap<String, String>): String = neslExecute(command, env)

@Composable
fun ScriptConsoleScreen() {
    var inputText by remember { mutableStateOf("") }
    var logs by remember { mutableStateOf(listOf("> NEX-Script Engine v1.0 initialized", "> Type 'help' for commands.")) }
    
    // Environment for variable storage
    val environment = remember { mutableMapOf<String, String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E))
            .padding(16.dp)
    ) {
        Text(
            text = "NEX-Script Console",
            color = Color(0xFF4CAF50),
            style = MaterialTheme.typography.titleMedium,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 16.dp, top = 32.dp)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            reverseLayout = true
        ) {
            items(logs.reversed()) { log ->
                val annotatedString = if (log.startsWith("Error")) {
                    buildAnnotatedString { withStyle(SpanStyle(color = Color(0xFFE57373))) { append(log) } }
                } else if (log.startsWith(">>> ")) {
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Color(0xFF4CAF50))) { append(">>> ") }
                        val cmd = log.removePrefix(">>> ")
                        val words = cmd.split(" ")
                        words.forEachIndexed { index, word ->
                            when {
                                word in listOf("let", "print", "help") -> withStyle(SpanStyle(color = Color(0xFF2979FF))) { append(word) }
                                word.startsWith("emu.") || word.startsWith("sys.") || word.startsWith("core.") -> withStyle(SpanStyle(color = Color(0xFFFF9800))) { append(word) }
                                word.startsWith("\"") -> withStyle(SpanStyle(color = Color(0xFF00E676))) { append(word) }
                                word.toIntOrNull() != null -> withStyle(SpanStyle(color = Color(0xFFE91E63))) { append(word) }
                                else -> append(word)
                            }
                            if (index < words.size - 1) append(" ")
                        }
                    }
                } else {
                    buildAnnotatedString { withStyle(SpanStyle(color = Color(0xFFB0BEC5))) { append(log) } }
                }

                Text(
                    text = annotatedString,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val quickCommands = listOf("emu.gputest()", "emu.cputest()", "emu.hletest()", "emu.geinfo()", "emu.gelog()", "emu.cpu()", "emu.ips()", "help")
            items(quickCommands) { cmd ->
                AssistChip(
                    onClick = {
                        val newLog = ">>> $cmd"
                        val response = executeCommand(cmd, environment)
                        logs = logs + newLog + response
                    },
                    label = {
                        Text(
                            text = cmd,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = if (cmd == "emu.gputest()") Color(0xFF00E676) else Color(0xFF2979FF)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = Color(0xFF2D2D2D)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (cmd == "emu.gputest()") Color(0xFF00E676).copy(alpha = 0.5f) else Color(0xFF2979FF).copy(alpha = 0.3f)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF2D2D2D), RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(">>> ", color = Color(0xFF4CAF50), fontFamily = FontFamily.Monospace)
            BasicTextField(
                value = inputText,
                onValueChange = { inputText = it },
                textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 16.sp),
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputText.isNotBlank()) {
                            val newLog = ">>> $inputText"
                            val response = executeCommand(inputText, environment)
                            logs = logs + newLog + response
                            inputText = ""
                        }
                    }
                )
            )
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        val newLog = ">>> $inputText"
                        val response = executeCommand(inputText, environment)
                        logs = logs + newLog + response
                        inputText = ""
                    }
                }
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF4CAF50))
            }
        }
    }
}
