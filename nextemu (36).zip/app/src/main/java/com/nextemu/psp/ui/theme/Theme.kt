package com.nextemu.psp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NextEmuDarkColorScheme = darkColorScheme(
    primary = PspBluePrimary,
    onPrimary = Color.White,
    primaryContainer = PspBlueVariant,
    onPrimaryContainer = Color.White,
    secondary = PlasmaGreen,
    onSecondary = Color.Black,
    secondaryContainer = PlasmaGreenDark,
    onSecondaryContainer = Color.White,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkCardSurface,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NextEmuDarkColorScheme,
        typography = Typography,
        content = content
    )
}

