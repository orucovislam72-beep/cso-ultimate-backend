package com.nextemu.psp

import com.nextemu.psp.data.GameFile

sealed class AppScreen {
    object Welcome : AppScreen()
    object Library : AppScreen()
    object AiAssistant : AppScreen()
    object ScriptConsole : AppScreen()
    object Settings : AppScreen()
    object About : AppScreen()
    data class GameDetails(val game: GameFile) : AppScreen()
    data class Gameplay(val game: GameFile) : AppScreen()
}

