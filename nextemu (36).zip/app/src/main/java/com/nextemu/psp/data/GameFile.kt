package com.nextemu.psp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class GameFile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val gameId: String = "",
    val path: String,
    val format: String = "ISO",
    val coverArt: String? = null,
    val platform: String = "PSP", // PSP, PSX, GBA
    val fileSize: String = "1.2 GB",
    val genre: String = "Экшен",
    val rating: Float = 4.8f,
    val isFavorite: Boolean = false,
    val lastPlayedTimestamp: Long = 0L
)

