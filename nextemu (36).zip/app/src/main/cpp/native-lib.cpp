#ifndef STANDALONE_TEST_RUNNER
#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <zlib.h>
#include <memory>
#include <algorithm>

struct PspPadState {
    uint32_t buttons = 0;
    uint8_t lx = 128, ly = 128;
};
static PspPadState g_padState;

#include <android/log.h>
#else
#include <iostream>
#define ANDROID_LOG_INFO 4
#define ANDROID_LOG_WARN 5
#define ANDROID_LOG_ERROR 6
#define __android_log_print(...) ((void)0)
typedef void* jobject;
typedef void* jstring;
typedef void* jintArray;
typedef int jint;
typedef int64_t jlong;
typedef float jfloat;
typedef uint8_t jbyte;
typedef int jsize;
typedef unsigned char jboolean;
#define JNI_TRUE 1
#define JNI_FALSE 0
#define JNIEXPORT
#define JNICALL
struct JNIEnv {
    jstring NewStringUTF(const char*) { return nullptr; }
    jsize GetArrayLength(jintArray) { return 0; }
    jint* GetIntArrayElements(jintArray, jboolean*) { return nullptr; }
    void ReleaseIntArrayElements(jintArray, jint*, jint) {}
    const char* GetStringUTFChars(jstring, jboolean*) { return ""; }
    void ReleaseStringUTFChars(jstring, const char*) {}
};
#endif
#include <string>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <pthread.h>
#include <chrono>
#include <map>
#include <unordered_map>
#include <cctype>
#include <cmath>
#include <deque>
#include <unistd.h>

static std::string g_currentGamePath = "";
static std::string g_savesDir = "";
static int g_gameFd = -1;
static int64_t g_gameFileSize = 0;
static bool g_isInitialized = false;


class IDiscImage {
public:
    virtual ~IDiscImage() = default;
    virtual size_t read(uint64_t offset, void* buffer, size_t size) = 0;
    virtual uint64_t size() const = 0;
    virtual std::string format() const = 0;
};

class IsoReader : public IDiscImage {
    int fd;
    uint64_t fileSize;
public:
    IsoReader(int fd, uint64_t fileSize) : fd(fd), fileSize(fileSize) {}
    ~IsoReader() override { if (fd >= 0) close(fd); }
    size_t read(uint64_t offset, void* buffer, size_t size) override {
        if (offset >= fileSize) return 0;
        size_t toRead = std::min((uint64_t)size, fileSize - offset);
        lseek(fd, offset, SEEK_SET);
        return ::read(fd, buffer, toRead);
    }
    uint64_t size() const override { return fileSize; }
    std::string format() const override { return "ISO"; }
};

#pragma pack(push, 1)
struct CsoHeader {
    char magic[4]; // CISO
    uint32_t header_size;
    uint64_t total_bytes;
    uint32_t block_size;
    uint8_t version;
    uint8_t align;
    uint8_t reserved[2];
};
#pragma pack(pop)

class CsoReader : public IDiscImage {
    int fd;
    CsoHeader header;
    std::vector<uint32_t> index_table;
    uint32_t index_shift;
    
    uint32_t cached_block_idx = 0xFFFFFFFF;
    std::vector<uint8_t> cached_block_data;
    bool valid = false;

public:
    CsoReader(int fd) : fd(fd) {
        lseek(fd, 0, SEEK_SET);
        if (::read(fd, &header, sizeof(CsoHeader)) != sizeof(CsoHeader)) return;
        if (memcmp(header.magic, "CISO", 4) != 0) return;
        
        index_shift = header.align;
        uint32_t total_blocks = (header.total_bytes + header.block_size - 1) / header.block_size;
        index_table.resize(total_blocks + 1);
        if (::read(fd, index_table.data(), (total_blocks + 1) * sizeof(uint32_t)) != (total_blocks + 1) * sizeof(uint32_t)) return;
        
        cached_block_data.resize(header.block_size);
        valid = true;
    }
    ~CsoReader() override { if (fd >= 0) close(fd); }

    bool isValid() const { return valid; }

    size_t read(uint64_t offset, void* buffer, size_t size) override {
        if (!valid || offset >= header.total_bytes) return 0;
        size_t toRead = std::min((uint64_t)size, header.total_bytes - offset);
        size_t read_bytes = 0;
        uint8_t* out = (uint8_t*)buffer;

        while (read_bytes < toRead) {
            uint64_t current_offset = offset + read_bytes;
            uint32_t block_idx = current_offset / header.block_size;
            uint32_t block_offset = current_offset % header.block_size;
            uint32_t block_avail = header.block_size - block_offset;
            uint32_t chunk_size = std::min((uint32_t)(toRead - read_bytes), block_avail);

            if (block_idx != cached_block_idx) {
                if (!readBlock(block_idx)) break;
            }

            memcpy(out + read_bytes, cached_block_data.data() + block_offset, chunk_size);
            read_bytes += chunk_size;
        }
        return read_bytes;
    }
    uint64_t size() const override { return header.total_bytes; }
    std::string format() const override { return "CSO"; }
    uint32_t blockSize() const { return header.block_size; }

private:
    bool readBlock(uint32_t block_idx) {
        uint32_t entry = index_table[block_idx];
        uint32_t next_entry = index_table[block_idx + 1];
        
        uint32_t pos = (entry & 0x7FFFFFFF) << index_shift;
        uint32_t next_pos = (next_entry & 0x7FFFFFFF) << index_shift;
        uint32_t comp_size = next_pos - pos;
        bool is_plain = (entry & 0x80000000) != 0;

        lseek(fd, pos, SEEK_SET);

        if (is_plain) {
            if (comp_size > header.block_size) comp_size = header.block_size;
            if (::read(fd, cached_block_data.data(), comp_size) != comp_size) return false;
            cached_block_idx = block_idx;
            return true;
        } else {
            std::vector<uint8_t> comp_buf(comp_size);
            if (::read(fd, comp_buf.data(), comp_size) != comp_size) return false;

            z_stream zs;
            memset(&zs, 0, sizeof(zs));
            if (inflateInit2(&zs, -15) != Z_OK) return false;

            zs.next_in = comp_buf.data();
            zs.avail_in = comp_size;
            zs.next_out = cached_block_data.data();
            zs.avail_out = header.block_size;

            int status = inflate(&zs, Z_FINISH);
            inflateEnd(&zs);

            if (status == Z_STREAM_END || status == Z_OK) {
                cached_block_idx = block_idx;
                return true;
            }
            return false;
        }
    }
};

static std::shared_ptr<IDiscImage> openGameImage() {
    int fd = -1;
    if (g_gameFd >= 0) {
        fd = dup(g_gameFd);
    } else if (!g_currentGamePath.empty()) {
        fd = open(g_currentGamePath.c_str(), O_RDONLY);
    }
    if (fd < 0) return nullptr;

    char magic[4];
    lseek(fd, 0, SEEK_SET);
    if (::read(fd, magic, 4) == 4 && memcmp(magic, "CISO", 4) == 0) {
        auto cso = std::make_shared<CsoReader>(fd);
        if (cso->isValid()) return cso;
        close(fd);
        return nullptr;
    }
    return std::make_shared<IsoReader>(fd, g_gameFileSize);
}


static uint64_t g_frameCount = 0;
static pthread_mutex_t g_cpuMutex = PTHREAD_MUTEX_INITIALIZER;
static uint64_t g_totalInstructions = 0;
static std::chrono::time_point<std::chrono::steady_clock> g_startTime;

// Memory regions
static std::vector<uint8_t> scratchpadRAM(16 * 1024, 0); // 16KB
static std::vector<uint8_t> mainRAM(32 * 1024 * 1024, 0); // 32MB
static std::vector<uint8_t> vram(2 * 1024 * 1024, 0); // 2MB
static std::vector<uint8_t> kernelRAM(4 * 1024 * 1024, 0); // 4MB

// Forward declarations of memory accessor functions
static uint8_t internalReadMemory8(uint32_t a);
static uint16_t internalReadMemory16(uint32_t a);
static uint32_t internalReadMemory32(uint32_t a);
static void internalWriteMemory8(uint32_t a, uint8_t v);
static void internalWriteMemory16(uint32_t a, uint16_t v);
static void internalWriteMemory32(uint32_t a, uint32_t v);

struct MipsCpu {
    uint32_t regs[32];   // r0 - r31
    uint32_t pc;         // Current Program Counter
    uint32_t nextPc;     // Next Program Counter
    uint32_t hi, lo;     // HI and LO registers

    // Branch delay slot state
    bool inDelaySlot;        // Is currently executing instruction in a delay slot?
    bool branchPending;      // Has a branch been taken?
    uint32_t branchTarget;   // Target address of pending branch

    // Coprocessor 0 (CP0) state
    uint32_t cp0_status;     // CP0 Reg 12 Status
    uint32_t cp0_cause;      // CP0 Reg 13 Cause
    uint32_t cp0_epc;        // CP0 Reg 14 EPC
    uint32_t cp0_prid;       // CP0 Reg 15 PRId (0x00018000 for Allegrex)

    uint32_t exceptionCount;
};

static MipsCpu g_cpu = {{0}, 0x08000000, 0x08000004, 0, 0, false, false, 0, 0, 0, 0, 0x00018000, 0};

enum PspPixelFormat {
    GU_PSM_5650 = 0,
    GU_PSM_5551 = 1,
    GU_PSM_4444 = 2,
    GU_PSM_8888 = 3
};

enum GeCmd : uint8_t {
    GE_CMD_NOP               = 0x00,
    GE_CMD_VADDR             = 0x01,
    GE_CMD_IADDR             = 0x02,
    GE_CMD_PRIM              = 0x04,
    GE_CMD_BEZIER            = 0x05,
    GE_CMD_SPLINE            = 0x06,
    GE_CMD_BOUNDINGBOX       = 0x07,
    GE_CMD_JUMP              = 0x08,
    GE_CMD_BJUMP             = 0x09,
    GE_CMD_CALL              = 0x0A,
    GE_CMD_RET               = 0x0B,
    GE_CMD_END               = 0x0C,
    GE_CMD_SIGNAL            = 0x0E,
    GE_CMD_FINISH            = 0x0F,
    GE_CMD_BASE              = 0x10,
    GE_CMD_VTYPE             = 0x12,
    GE_CMD_OFFSETADDR        = 0x13,
    GE_CMD_ORIGIN            = 0x14,
    GE_CMD_REGION1           = 0x15,
    GE_CMD_REGION2           = 0x16,
    GE_CMD_LIGHTINGENABLE    = 0x17,
    GE_CMD_LIGHTENABLE0      = 0x18,
    GE_CMD_LIGHTENABLE1      = 0x19,
    GE_CMD_LIGHTENABLE2      = 0x1A,
    GE_CMD_LIGHTENABLE3      = 0x1B,
    GE_CMD_CLIPENABLE        = 0x1C,
    GE_CMD_CULLFACEENABLE    = 0x1D,
    GE_CMD_TEXTUREMAPENABLE  = 0x1E,
    GE_CMD_FOGENABLE         = 0x1F,
    GE_CMD_DITHERENABLE      = 0x20,
    GE_CMD_ALPHABLENDENABLE  = 0x21,
    GE_CMD_ALPHATESTENABLE   = 0x22,
    GE_CMD_ZTESTENABLE       = 0x23,
    GE_CMD_STENCILTESTENABLE = 0x24,
    GE_CMD_ANTIALIASENABLE   = 0x25,
    GE_CMD_BONEMATRIXNUMBER  = 0x2A,
    GE_CMD_BONEMATRIXDATA    = 0x2B,
    GE_CMD_MORPHWEIGHT0      = 0x2C,
    GE_CMD_WORLDMATRIXNUMBER = 0x3A,
    GE_CMD_WORLDMATRIXDATA   = 0x3B,
    GE_CMD_VIEWMATRIXNUMBER  = 0x3C,
    GE_CMD_VIEWMATRIXDATA    = 0x3D,
    GE_CMD_PROJMATRIXNUMBER  = 0x3E,
    GE_CMD_PROJMATRIXDATA    = 0x3F,
    GE_CMD_TGENMATRIXNUMBER  = 0x40,
    GE_CMD_TGENMATRIXDATA    = 0x41,
    GE_CMD_VIEWPORTXSCALE    = 0x42,
    GE_CMD_VIEWPORTYSCALE    = 0x43,
    GE_CMD_VIEWPORTZSCALE    = 0x44,
    GE_CMD_VIEWPORTXCENTER   = 0x45,
    GE_CMD_VIEWPORTYCENTER   = 0x46,
    GE_CMD_VIEWPORTZCENTER   = 0x47,
    GE_CMD_TEXSCALEU         = 0x48,
    GE_CMD_TEXSCALEV         = 0x49,
    GE_CMD_TEXOFFSETU        = 0x4A,
    GE_CMD_TEXOFFSETV        = 0x4B,
    GE_CMD_OFFSETX           = 0x4C,
    GE_CMD_OFFSETY           = 0x4D,
    GE_CMD_SHADEMODE         = 0x50,
    GE_CMD_RNORMFACEDIR      = 0x51,
    GE_CMD_REVERSENORMAL     = 0x53,
    GE_CMD_MATERIALAMBIENT   = 0x54,
    GE_CMD_MATERIALDIFFUSE   = 0x55,
    GE_CMD_MATERIALSPECULAR  = 0x56,
    GE_CMD_MATERIALALPHA     = 0x57,
    GE_CMD_MATERIALSPECULARCOEF = 0x58,
    GE_CMD_AMBIENTCOLOR      = 0x5B,
    GE_CMD_AMBIENTALPHA      = 0x5C,
    GE_CMD_CLEARMODE         = 0x64,
    GE_CMD_CULLFACE          = 0x66,
    GE_CMD_FRAMEBUFPTR       = 0x67,
    GE_CMD_FRAMEBUFWIDTH     = 0x68,
    GE_CMD_ZBUFPTR           = 0x69,
    GE_CMD_ZBUFWIDTH         = 0x6A,
    GE_CMD_TEXADDR0          = 0x6B,
    GE_CMD_TEXADDR1          = 0x6C,
    GE_CMD_TEXADDR2          = 0x6D,
    GE_CMD_TEXADDR3          = 0x6E,
    GE_CMD_TEXADDR4          = 0x6F,
    GE_CMD_TEXADDR5          = 0x70,
    GE_CMD_TEXADDR6          = 0x71,
    GE_CMD_TEXADDR7          = 0x72,
    GE_CMD_TEXBUFWIDTH0      = 0x73,
    GE_CMD_CLUTADDR          = 0x7B,
    GE_CMD_CLUTADDRUPPER     = 0x7C,
    GE_CMD_TRANSFERSRC       = 0x80,
    GE_CMD_TRANSFERSRCW      = 0x81,
    GE_CMD_TRANSFERDST       = 0x82,
    GE_CMD_TRANSFERDSTW      = 0x83,
    GE_CMD_TRANSFERSRCPOS    = 0x86,
    GE_CMD_TRANSFERDSTPOS    = 0x87,
    GE_CMD_TRANSFERSIZE      = 0x88,
    GE_CMD_TRANSFERSTART     = 0x89,
    GE_CMD_TEXSIZE0          = 0x8B,
    GE_CMD_TEXMAPMODE        = 0x93,
    GE_CMD_TEXSHADELS        = 0x94,
    GE_CMD_TEXMODE           = 0x95,
    GE_CMD_TEXFORMAT         = 0x96,
    GE_CMD_LOADCLUT          = 0x97,
    GE_CMD_CLUTFORMAT        = 0x98,
    GE_CMD_TEXFILTER         = 0x99,
    GE_CMD_TEXWRAP           = 0x9A,
    GE_CMD_TEXLEVEL          = 0x9B,
    GE_CMD_TEXFUNC           = 0x9C,
    GE_CMD_TEXENVCOLOR       = 0x9D,
    GE_CMD_TEXFLUSH          = 0x9E,
    GE_CMD_TEXSYNC           = 0x9F,
    GE_CMD_FOG1              = 0xA0,
    GE_CMD_FOG2              = 0xA1,
    GE_CMD_FOGCOLOR          = 0xA2,
    GE_CMD_TEXLODSLOPE       = 0xA3,
    GE_CMD_SCISSOR1          = 0xB0,
    GE_CMD_SCISSOR2          = 0xB1,
    GE_CMD_MINZ              = 0xB2,
    GE_CMD_MAXZ              = 0xB3,
    GE_CMD_COLORTEST         = 0xB4,
    GE_CMD_COLORREF          = 0xB5,
    GE_CMD_COLORTESTMASK     = 0xB6,
    GE_CMD_ALPHATEST         = 0xB7,
    GE_CMD_STENCILTEST       = 0xB8,
    GE_CMD_STENCILOP         = 0xB9,
    GE_CMD_ZTEST             = 0xBA,
    GE_CMD_BLENDMODE         = 0xBB,
    GE_CMD_BLENDFIXEDA       = 0xBC,
    GE_CMD_BLENDFIXEDB       = 0xBD,
    GE_CMD_DITH0             = 0xBE,
    GE_CMD_DITH1             = 0xBF,
    GE_CMD_DITH2             = 0xC0,
    GE_CMD_DITH3             = 0xC1,
    GE_CMD_LOGICOP           = 0xC2,
    GE_CMD_ZMASK             = 0xC3,
    GE_CMD_MASKRGB           = 0xC4,
    GE_CMD_MASKALPHA         = 0xC5
};

static const char* getGeCmdName(uint8_t op) {
    switch (op) {
        case GE_CMD_NOP: return "GE_CMD_NOP";
        case GE_CMD_VADDR: return "GE_CMD_VADDR";
        case GE_CMD_IADDR: return "GE_CMD_IADDR";
        case GE_CMD_PRIM: return "GE_CMD_PRIM";
        case GE_CMD_BEZIER: return "GE_CMD_BEZIER";
        case GE_CMD_SPLINE: return "GE_CMD_SPLINE";
        case GE_CMD_BOUNDINGBOX: return "GE_CMD_BOUNDINGBOX";
        case GE_CMD_JUMP: return "GE_CMD_JUMP";
        case GE_CMD_BJUMP: return "GE_CMD_BJUMP";
        case GE_CMD_CALL: return "GE_CMD_CALL";
        case GE_CMD_RET: return "GE_CMD_RET";
        case GE_CMD_END: return "GE_CMD_END";
        case GE_CMD_SIGNAL: return "GE_CMD_SIGNAL";
        case GE_CMD_FINISH: return "GE_CMD_FINISH";
        case GE_CMD_BASE: return "GE_CMD_BASE";
        case GE_CMD_VTYPE: return "GE_CMD_VTYPE";
        case GE_CMD_OFFSETADDR: return "GE_CMD_OFFSETADDR";
        case GE_CMD_ORIGIN: return "GE_CMD_ORIGIN";
        case GE_CMD_REGION1: return "GE_CMD_REGION1";
        case GE_CMD_REGION2: return "GE_CMD_REGION2";
        case GE_CMD_LIGHTINGENABLE: return "GE_CMD_LIGHTINGENABLE";
        case GE_CMD_LIGHTENABLE0: return "GE_CMD_LIGHTENABLE0";
        case GE_CMD_LIGHTENABLE1: return "GE_CMD_LIGHTENABLE1";
        case GE_CMD_LIGHTENABLE2: return "GE_CMD_LIGHTENABLE2";
        case GE_CMD_LIGHTENABLE3: return "GE_CMD_LIGHTENABLE3";
        case GE_CMD_CLIPENABLE: return "GE_CMD_CLIPENABLE";
        case GE_CMD_CULLFACEENABLE: return "GE_CMD_CULLFACEENABLE";
        case GE_CMD_TEXTUREMAPENABLE: return "GE_CMD_TEXTUREMAPENABLE";
        case GE_CMD_FOGENABLE: return "GE_CMD_FOGENABLE";
        case GE_CMD_DITHERENABLE: return "GE_CMD_DITHERENABLE";
        case GE_CMD_ALPHABLENDENABLE: return "GE_CMD_ALPHABLENDENABLE";
        case GE_CMD_ALPHATESTENABLE: return "GE_CMD_ALPHATESTENABLE";
        case GE_CMD_ZTESTENABLE: return "GE_CMD_ZTESTENABLE";
        case GE_CMD_STENCILTESTENABLE: return "GE_CMD_STENCILTESTENABLE";
        case GE_CMD_ANTIALIASENABLE: return "GE_CMD_ANTIALIASENABLE";
        case GE_CMD_BONEMATRIXNUMBER: return "GE_CMD_BONEMATRIXNUMBER";
        case GE_CMD_BONEMATRIXDATA: return "GE_CMD_BONEMATRIXDATA";
        case GE_CMD_MORPHWEIGHT0: return "GE_CMD_MORPHWEIGHT0";
        case GE_CMD_WORLDMATRIXNUMBER: return "GE_CMD_WORLDMATRIXNUMBER";
        case GE_CMD_WORLDMATRIXDATA: return "GE_CMD_WORLDMATRIXDATA";
        case GE_CMD_VIEWMATRIXNUMBER: return "GE_CMD_VIEWMATRIXNUMBER";
        case GE_CMD_VIEWMATRIXDATA: return "GE_CMD_VIEWMATRIXDATA";
        case GE_CMD_PROJMATRIXNUMBER: return "GE_CMD_PROJMATRIXNUMBER";
        case GE_CMD_PROJMATRIXDATA: return "GE_CMD_PROJMATRIXDATA";
        case GE_CMD_TGENMATRIXNUMBER: return "GE_CMD_TGENMATRIXNUMBER";
        case GE_CMD_TGENMATRIXDATA: return "GE_CMD_TGENMATRIXDATA";
        case GE_CMD_VIEWPORTXSCALE: return "GE_CMD_VIEWPORTXSCALE";
        case GE_CMD_VIEWPORTYSCALE: return "GE_CMD_VIEWPORTYSCALE";
        case GE_CMD_VIEWPORTZSCALE: return "GE_CMD_VIEWPORTZSCALE";
        case GE_CMD_VIEWPORTXCENTER: return "GE_CMD_VIEWPORTXCENTER";
        case GE_CMD_VIEWPORTYCENTER: return "GE_CMD_VIEWPORTYCENTER";
        case GE_CMD_VIEWPORTZCENTER: return "GE_CMD_VIEWPORTZCENTER";
        case GE_CMD_TEXSCALEU: return "GE_CMD_TEXSCALEU";
        case GE_CMD_TEXSCALEV: return "GE_CMD_TEXSCALEV";
        case GE_CMD_TEXOFFSETU: return "GE_CMD_TEXOFFSETU";
        case GE_CMD_TEXOFFSETV: return "GE_CMD_TEXOFFSETV";
        case GE_CMD_OFFSETX: return "GE_CMD_OFFSETX";
        case GE_CMD_OFFSETY: return "GE_CMD_OFFSETY";
        case GE_CMD_SHADEMODE: return "GE_CMD_SHADEMODE";
        case GE_CMD_RNORMFACEDIR: return "GE_CMD_RNORMFACEDIR";
        case GE_CMD_REVERSENORMAL: return "GE_CMD_REVERSENORMAL";
        case GE_CMD_MATERIALAMBIENT: return "GE_CMD_MATERIALAMBIENT";
        case GE_CMD_MATERIALDIFFUSE: return "GE_CMD_MATERIALDIFFUSE";
        case GE_CMD_MATERIALSPECULAR: return "GE_CMD_MATERIALSPECULAR";
        case GE_CMD_MATERIALALPHA: return "GE_CMD_MATERIALALPHA";
        case GE_CMD_MATERIALSPECULARCOEF: return "GE_CMD_MATERIALSPECULARCOEF";
        case GE_CMD_AMBIENTCOLOR: return "GE_CMD_AMBIENTCOLOR";
        case GE_CMD_AMBIENTALPHA: return "GE_CMD_AMBIENTALPHA";
        case GE_CMD_CLEARMODE: return "GE_CMD_CLEARMODE";
        case GE_CMD_CULLFACE: return "GE_CMD_CULLFACE";
        case GE_CMD_FRAMEBUFPTR: return "GE_CMD_FRAMEBUFPTR";
        case GE_CMD_FRAMEBUFWIDTH: return "GE_CMD_FRAMEBUFWIDTH";
        case GE_CMD_ZBUFPTR: return "GE_CMD_ZBUFPTR";
        case GE_CMD_ZBUFWIDTH: return "GE_CMD_ZBUFWIDTH";
        case GE_CMD_TEXADDR0: return "GE_CMD_TEXADDR0";
        case GE_CMD_TEXBUFWIDTH0: return "GE_CMD_TEXBUFWIDTH0";
        case GE_CMD_CLUTADDR: return "GE_CMD_CLUTADDR";
        case GE_CMD_TRANSFERSRC: return "GE_CMD_TRANSFERSRC";
        case GE_CMD_TRANSFERSRCW: return "GE_CMD_TRANSFERSRCW";
        case GE_CMD_TRANSFERDST: return "GE_CMD_TRANSFERDST";
        case GE_CMD_TRANSFERDSTW: return "GE_CMD_TRANSFERDSTW";
        case GE_CMD_TRANSFERSRCPOS: return "GE_CMD_TRANSFERSRCPOS";
        case GE_CMD_TRANSFERDSTPOS: return "GE_CMD_TRANSFERDSTPOS";
        case GE_CMD_TRANSFERSIZE: return "GE_CMD_TRANSFERSIZE";
        case GE_CMD_TRANSFERSTART: return "GE_CMD_TRANSFERSTART";
        case GE_CMD_TEXSIZE0: return "GE_CMD_TEXSIZE0";
        case GE_CMD_TEXMAPMODE: return "GE_CMD_TEXMAPMODE";
        case GE_CMD_TEXMODE: return "GE_CMD_TEXMODE";
        case GE_CMD_TEXFORMAT: return "GE_CMD_TEXFORMAT";
        case GE_CMD_TEXFILTER: return "GE_CMD_TEXFILTER";
        case GE_CMD_TEXWRAP: return "GE_CMD_TEXWRAP";
        case GE_CMD_TEXFUNC: return "GE_CMD_TEXFUNC";
        case GE_CMD_TEXENVCOLOR: return "GE_CMD_TEXENVCOLOR";
        case GE_CMD_TEXFLUSH: return "GE_CMD_TEXFLUSH";
        case GE_CMD_TEXSYNC: return "GE_CMD_TEXSYNC";
        case GE_CMD_FOG1: return "GE_CMD_FOG1";
        case GE_CMD_FOG2: return "GE_CMD_FOG2";
        case GE_CMD_FOGCOLOR: return "GE_CMD_FOGCOLOR";
        case GE_CMD_SCISSOR1: return "GE_CMD_SCISSOR1";
        case GE_CMD_SCISSOR2: return "GE_CMD_SCISSOR2";
        case GE_CMD_MINZ: return "GE_CMD_MINZ";
        case GE_CMD_MAXZ: return "GE_CMD_MAXZ";
        case GE_CMD_COLORTEST: return "GE_CMD_COLORTEST";
        case GE_CMD_ALPHATEST: return "GE_CMD_ALPHATEST";
        case GE_CMD_STENCILTEST: return "GE_CMD_STENCILTEST";
        case GE_CMD_ZTEST: return "GE_CMD_ZTEST";
        case GE_CMD_BLENDMODE: return "GE_CMD_BLENDMODE";
        case GE_CMD_BLENDFIXEDA: return "GE_CMD_BLENDFIXEDA";
        case GE_CMD_BLENDFIXEDB: return "GE_CMD_BLENDFIXEDB";
        case GE_CMD_ZMASK: return "GE_CMD_ZMASK";
        case GE_CMD_MASKRGB: return "GE_CMD_MASKRGB";
        case GE_CMD_MASKALPHA: return "GE_CMD_MASKALPHA";
        default: return "GE_CMD_UNKNOWN";
    }
}

struct GeState {
    uint32_t framebufAddr = 0x04000000;
    uint32_t framebufStride = 512;
    uint32_t pixelFormat = GU_PSM_8888;

    uint32_t zbufAddr = 0x04100000;
    uint32_t zbufStride = 512;
    bool zTestEnable = false;
    uint32_t zTestFunc = 1;
    uint16_t zMask = 0;

    float viewportXScale = 240.0f;
    float viewportYScale = -136.0f;
    float viewportZScale = 32767.5f;
    float viewportXCenter = 240.0f;
    float viewportYCenter = 136.0f;
    float viewportZCenter = 32767.5f;

    int offsetX = 0;
    int offsetY = 0;

    int regionX1 = 0, regionY1 = 0, regionX2 = 480, regionY2 = 272;
    int scissorX1 = 0, scissorY1 = 0, scissorX2 = 480, scissorY2 = 272;

    float worldMatrix[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    int worldIdx = 0;

    float viewMatrix[16]  = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    int viewIdx = 0;

    float projMatrix[16]  = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    int projIdx = 0;

    float texMatrix[16]   = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    int texIdx = 0;

    float boneMatrices[8][16] = {};
    int boneIdx = 0;

    uint32_t vtype = 0;
    bool isThrough = false;

    bool clearMode = false;
    uint32_t clearFlags = 0;
    uint32_t clearColor = 0xFF000000;
    uint16_t clearDepth = 0xFFFF;
    uint32_t ambientColor = 0xFFFFFFFF;
    uint32_t materialDiffuse = 0xFFFFFFFF;
    uint32_t materialAmbient = 0xFFFFFFFF;
    uint32_t materialSpecular = 0xFFFFFFFF;

    bool cullFaceEnable = false;
    uint32_t cullFace = 0;

    bool blendEnable = false;
    uint32_t blendFuncA = 0;
    uint32_t blendFuncB = 0;
    uint32_t blendEq = 0;
    uint32_t blendFixA = 0xFFFFFFFF;
    uint32_t blendFixB = 0xFFFFFFFF;

    bool texEnable = false;
    uint32_t texAddr = 0;
    uint32_t texBufWidth = 512;
    uint32_t texWidthExp = 8;
    uint32_t texHeightExp = 8;
    uint32_t texFormat = GU_PSM_8888;
    uint32_t texMapMode = 0;
    uint32_t texFilterMin = 0;
    uint32_t texFilterMag = 0;
    uint32_t texWrapS = 0;
    uint32_t texWrapT = 0;
    float texScaleU = 1.0f, texScaleV = 1.0f;
    float texOffsetU = 0.0f, texOffsetV = 0.0f;

    uint32_t shadeModel = 0;
};

struct UnpackedVertex {
    float x, y, z;
    float u, v;
    uint32_t color;
    float nx, ny, nz;
};

class IPspRenderer {
public:
    virtual ~IPspRenderer() = default;
    virtual void init() = 0;
    virtual void resetState() = 0;
    virtual void executeCommand(uint8_t op, uint32_t arg) = 0;
    virtual void drawPrimitives(uint32_t primType, uint32_t vtype, uint32_t count, uint32_t vaddr, uint32_t iaddr) = 0;
    virtual void setFramebuffer(uint32_t addr, uint32_t stride, uint32_t format) = 0;
    virtual void setDepthBuffer(uint32_t addr, uint32_t stride) = 0;
    virtual void getFramebufferRGBA(uint32_t* outPixels, int width, int height) = 0;
    virtual const GeState& getState() const = 0;
};

class PspSoftwareRenderer : public IPspRenderer {
private:
    GeState m_state;

    static float floatFromBits24(uint32_t val24) {
        uint32_t bits = val24 << 8;
        union { uint32_t u; float f; } u;
        u.u = bits;
        return u.f;
    }

public:
    PspSoftwareRenderer() { init(); }

    void init() override {
        resetState();
    }

    void resetState() override {
        m_state = GeState();
    }

    const GeState& getState() const override {
        return m_state;
    }

    void setFramebuffer(uint32_t addr, uint32_t stride, uint32_t format) override {
        m_state.framebufAddr = (addr & 0x00FFFFFF) | 0x04000000;
        m_state.framebufStride = stride;
        m_state.pixelFormat = format;
    }

    void setDepthBuffer(uint32_t addr, uint32_t stride) override {
        m_state.zbufAddr = (addr & 0x00FFFFFF) | 0x04000000;
        m_state.zbufStride = stride;
    }

    void executeCommand(uint8_t op, uint32_t arg) override {
        switch (op) {
            case GE_CMD_VTYPE:
                m_state.vtype = arg;
                m_state.isThrough = ((arg >> 23) & 1) != 0;
                break;
            case GE_CMD_FRAMEBUFPTR:
                m_state.framebufAddr = (arg & 0x00FFFFFF) | 0x04000000;
                break;
            case GE_CMD_FRAMEBUFWIDTH:
                m_state.framebufStride = arg & 0xFFFF;
                m_state.pixelFormat = (arg >> 16) & 0x03;
                break;
            case GE_CMD_ZBUFPTR:
                m_state.zbufAddr = (arg & 0x00FFFFFF) | 0x04000000;
                break;
            case GE_CMD_ZBUFWIDTH:
                m_state.zbufStride = arg & 0xFFFF;
                break;
            case GE_CMD_SCISSOR1:
                m_state.scissorX1 = arg & 0x3FF;
                m_state.scissorY1 = (arg >> 10) & 0x3FF;
                break;
            case GE_CMD_SCISSOR2:
                m_state.scissorX2 = (arg & 0x3FF) + 1;
                m_state.scissorY2 = ((arg >> 10) & 0x3FF) + 1;
                break;
            case GE_CMD_REGION1:
                m_state.regionX1 = arg & 0x3FF;
                m_state.regionY1 = (arg >> 10) & 0x3FF;
                break;
            case GE_CMD_REGION2:
                m_state.regionX2 = (arg & 0x3FF) + 1;
                m_state.regionY2 = ((arg >> 10) & 0x3FF) + 1;
                break;
            case GE_CMD_VIEWPORTXSCALE:
                m_state.viewportXScale = floatFromBits24(arg);
                break;
            case GE_CMD_VIEWPORTYSCALE:
                m_state.viewportYScale = floatFromBits24(arg);
                break;
            case GE_CMD_VIEWPORTZSCALE:
                m_state.viewportZScale = floatFromBits24(arg);
                break;
            case GE_CMD_VIEWPORTXCENTER:
                m_state.viewportXCenter = floatFromBits24(arg);
                break;
            case GE_CMD_VIEWPORTYCENTER:
                m_state.viewportYCenter = floatFromBits24(arg);
                break;
            case GE_CMD_VIEWPORTZCENTER:
                m_state.viewportZCenter = floatFromBits24(arg);
                break;
            case GE_CMD_TEXSCALEU:
                m_state.texScaleU = floatFromBits24(arg);
                break;
            case GE_CMD_TEXSCALEV:
                m_state.texScaleV = floatFromBits24(arg);
                break;
            case GE_CMD_TEXOFFSETU:
                m_state.texOffsetU = floatFromBits24(arg);
                break;
            case GE_CMD_TEXOFFSETV:
                m_state.texOffsetV = floatFromBits24(arg);
                break;
            case GE_CMD_OFFSETX:
                m_state.offsetX = arg & 0xFFFF;
                break;
            case GE_CMD_OFFSETY:
                m_state.offsetY = arg & 0xFFFF;
                break;
            case GE_CMD_BONEMATRIXNUMBER:
                m_state.boneIdx = arg & 0x7F;
                break;
            case GE_CMD_BONEMATRIXDATA:
                if (m_state.boneIdx < 128) {
                    m_state.boneMatrices[m_state.boneIdx / 16][m_state.boneIdx % 16] = floatFromBits24(arg);
                    m_state.boneIdx++;
                }
                break;
            case GE_CMD_WORLDMATRIXNUMBER:
                m_state.worldIdx = arg & 0x0F;
                break;
            case GE_CMD_WORLDMATRIXDATA:
                if (m_state.worldIdx < 16) {
                    m_state.worldMatrix[m_state.worldIdx++] = floatFromBits24(arg);
                }
                break;
            case GE_CMD_VIEWMATRIXNUMBER:
                m_state.viewIdx = arg & 0x0F;
                break;
            case GE_CMD_VIEWMATRIXDATA:
                if (m_state.viewIdx < 16) {
                    m_state.viewMatrix[m_state.viewIdx++] = floatFromBits24(arg);
                }
                break;
            case GE_CMD_PROJMATRIXNUMBER:
                m_state.projIdx = arg & 0x0F;
                break;
            case GE_CMD_PROJMATRIXDATA:
                if (m_state.projIdx < 16) {
                    m_state.projMatrix[m_state.projIdx++] = floatFromBits24(arg);
                }
                break;
            case GE_CMD_TGENMATRIXNUMBER:
                m_state.texIdx = arg & 0x0F;
                break;
            case GE_CMD_TGENMATRIXDATA:
                if (m_state.texIdx < 16) {
                    m_state.texMatrix[m_state.texIdx++] = floatFromBits24(arg);
                }
                break;
            case GE_CMD_CLEARMODE:
                m_state.clearMode = (arg & 1) != 0;
                m_state.clearFlags = (arg >> 8) & 0xFF;
                break;
            case GE_CMD_AMBIENTCOLOR:
                m_state.clearColor = (m_state.clearColor & 0xFF000000) | (arg & 0x00FFFFFF);
                m_state.ambientColor = (m_state.ambientColor & 0xFF000000) | (arg & 0x00FFFFFF);
                break;
            case GE_CMD_AMBIENTALPHA:
                m_state.clearColor = (m_state.clearColor & 0x00FFFFFF) | ((arg & 0xFF) << 24);
                m_state.ambientColor = (m_state.ambientColor & 0x00FFFFFF) | ((arg & 0xFF) << 24);
                break;
            case GE_CMD_MATERIALDIFFUSE:
                m_state.materialDiffuse = (m_state.materialDiffuse & 0xFF000000) | (arg & 0x00FFFFFF);
                break;
            case GE_CMD_MATERIALALPHA:
                m_state.materialDiffuse = (m_state.materialDiffuse & 0x00FFFFFF) | ((arg & 0xFF) << 24);
                break;
            case GE_CMD_MATERIALAMBIENT:
                m_state.materialAmbient = arg & 0x00FFFFFF;
                break;
            case GE_CMD_MATERIALSPECULAR:
                m_state.materialSpecular = arg & 0x00FFFFFF;
                break;
            case GE_CMD_CULLFACEENABLE:
                m_state.cullFaceEnable = (arg & 1) != 0;
                break;
            case GE_CMD_CULLFACE:
                m_state.cullFace = arg & 1;
                break;
            case GE_CMD_ALPHABLENDENABLE:
                m_state.blendEnable = (arg & 1) != 0;
                break;
            case GE_CMD_BLENDMODE:
                m_state.blendFuncA = arg & 0x0F;
                m_state.blendFuncB = (arg >> 4) & 0x0F;
                m_state.blendEq = (arg >> 8) & 0x0F;
                break;
            case GE_CMD_BLENDFIXEDA:
                m_state.blendFixA = arg;
                break;
            case GE_CMD_BLENDFIXEDB:
                m_state.blendFixB = arg;
                break;
            case GE_CMD_ZTESTENABLE:
                m_state.zTestEnable = (arg & 1) != 0;
                break;
            case GE_CMD_ZTEST:
                m_state.zTestFunc = arg & 0x07;
                break;
            case GE_CMD_ZMASK:
                m_state.zMask = arg & 0xFFFF;
                break;
            case GE_CMD_TEXTUREMAPENABLE:
                m_state.texEnable = (arg & 1) != 0;
                break;
            case GE_CMD_TEXADDR0:
                if ((arg & 0xFF000000) != 0) {
                    m_state.texAddr = arg;
                } else if ((m_state.texAddr & 0xFF000000) != 0) {
                    m_state.texAddr = (arg & 0x00FFFFFF) | (m_state.texAddr & 0xFF000000);
                } else {
                    m_state.texAddr = (arg & 0x00FFFFFF) | 0x04000000;
                }
                break;
            case GE_CMD_TEXBUFWIDTH0:
                m_state.texBufWidth = arg & 0xFFFF;
                if ((arg & 0x000F0000) != 0) {
                    m_state.texAddr = (m_state.texAddr & 0x00FFFFFF) | ((arg & 0x000F0000) << 8);
                }
                break;
            case GE_CMD_TEXSIZE0:
                m_state.texWidthExp = arg & 0x0F;
                m_state.texHeightExp = (arg >> 8) & 0x0F;
                break;
            case GE_CMD_TEXMODE:
                m_state.texFormat = arg & 0x0F;
                break;
            case GE_CMD_TEXMAPMODE:
                m_state.texMapMode = arg & 0x03;
                break;
            case GE_CMD_TEXFILTER:
                m_state.texFilterMin = arg & 0x07;
                m_state.texFilterMag = (arg >> 8) & 0x01;
                break;
            case GE_CMD_TEXWRAP:
                m_state.texWrapS = arg & 0x01;
                m_state.texWrapT = (arg >> 8) & 0x01;
                break;
            case GE_CMD_SHADEMODE:
                m_state.shadeModel = arg & 1;
                break;
            default:
                break;
        }
    }

    static uint32_t sampleTexture(const GeState& state, float u, float v) {
        if (state.texAddr == 0) return 0xFFFFFFFF;
        int tw = 1 << state.texWidthExp;
        int th = 1 << state.texHeightExp;
        if (tw <= 0 || th <= 0) return 0xFFFFFFFF;

        float texU = u * (state.isThrough ? 1.0f : (float)tw);
        float texV = v * (state.isThrough ? 1.0f : (float)th);

        int iu = (int)std::floor(texU);
        int iv = (int)std::floor(texV);

        if (state.texWrapS == 0) {
            iu = ((iu % tw) + tw) % tw;
        } else {
            iu = std::max(0, std::min(tw - 1, iu));
        }

        if (state.texWrapT == 0) {
            iv = ((iv % th) + th) % th;
        } else {
            iv = std::max(0, std::min(th - 1, iv));
        }

        uint32_t bufWidth = state.texBufWidth > 0 ? state.texBufWidth : (uint32_t)tw;
        uint32_t texAddr = state.texAddr;
        if ((texAddr & 0xFF000000) == 0) {
            texAddr |= 0x04000000;
        }
        uint32_t addr = texAddr + (iv * bufWidth + iu) * (state.texFormat == GU_PSM_8888 ? 4 : 2);

        if (state.texFormat == GU_PSM_8888) {
            return internalReadMemory32(addr);
        } else {
            uint16_t val = internalReadMemory16(addr);
            if (state.texFormat == GU_PSM_5650) {
                uint8_t r = ((val >> 11) & 0x1F) * 255 / 31;
                uint8_t g = ((val >> 5) & 0x3F) * 255 / 63;
                uint8_t b = (val & 0x1F) * 255 / 31;
                return 0xFF000000 | (b << 16) | (g << 8) | r;
            } else if (state.texFormat == GU_PSM_5551) {
                uint8_t r = ((val >> 11) & 0x1F) * 255 / 31;
                uint8_t g = ((val >> 6) & 0x1F) * 255 / 31;
                uint8_t b = ((val >> 1) & 0x1F) * 255 / 31;
                uint8_t a = (val & 1) ? 255 : 0;
                return (a << 24) | (b << 16) | (g << 8) | r;
            } else if (state.texFormat == GU_PSM_4444) {
                uint8_t r = ((val >> 12) & 0x0F) * 17;
                uint8_t g = ((val >> 8) & 0x0F) * 17;
                uint8_t b = ((val >> 4) & 0x0F) * 17;
                uint8_t a = (val & 0x0F) * 17;
                return (a << 24) | (b << 16) | (g << 8) | r;
            }
        }
        return 0xFFFFFFFF;
    }

    static bool depthTest(const GeState& state, int x, int y, float z) {
        if (!state.zTestEnable) return true;
        if (x < 0 || x >= 480 || y < 0 || y >= 272) return false;

        uint32_t zOffset = (state.zbufAddr & 0x001FFFFF) + (y * state.zbufStride + x) * 2;
        if (zOffset + 2 > vram.size()) return true;

        uint16_t currentZ = 0;
        memcpy(&currentZ, &vram[zOffset], 2);

        uint16_t testZ = (uint16_t)std::max(0.0f, std::min(65535.0f, z));

        bool pass = false;
        switch (state.zTestFunc) {
            case 0: pass = false; break;
            case 1: pass = true; break;
            case 2: pass = (testZ == currentZ); break;
            case 3: pass = (testZ != currentZ); break;
            case 4: pass = (testZ < currentZ); break;
            case 5: pass = (testZ <= currentZ); break;
            case 6: pass = (testZ > currentZ); break;
            case 7: pass = (testZ >= currentZ); break;
            default: pass = true; break;
        }

        if (pass && (state.zMask == 0)) {
            memcpy(&vram[zOffset], &testZ, 2);
        }
        return pass;
    }

    static void writePixel(const GeState& state, int x, int y, uint32_t srcColor, float z = 0.0f) {
        if (x < 0 || x >= 480 || y < 0 || y >= 272) return;
        if (x < state.scissorX1 || x >= state.scissorX2 || y < state.scissorY1 || y >= state.scissorY2) return;
        if (x < state.regionX1 || x >= state.regionX2 || y < state.regionY1 || y >= state.regionY2) return;

        if (!depthTest(state, x, y, z)) return;

        uint32_t vramOffset = (state.framebufAddr & 0x001FFFFF) + (y * state.framebufStride + x) * (state.pixelFormat == GU_PSM_8888 ? 4 : 2);
        if (vramOffset + 2 > vram.size()) return;

        uint8_t sr = srcColor & 0xFF;
        uint8_t sg = (srcColor >> 8) & 0xFF;
        uint8_t sb = (srcColor >> 16) & 0xFF;
        uint8_t sa = (srcColor >> 24) & 0xFF;

        if (state.blendEnable) {
            uint8_t dr = 0, dg = 0, db = 0, da = 255;
            if (state.pixelFormat == GU_PSM_8888 && vramOffset + 4 <= vram.size()) {
                uint32_t dstVal; memcpy(&dstVal, &vram[vramOffset], 4);
                dr = dstVal & 0xFF; dg = (dstVal >> 8) & 0xFF; db = (dstVal >> 16) & 0xFF; da = (dstVal >> 24) & 0xFF;
            } else if (vramOffset + 2 <= vram.size()) {
                uint16_t dstVal; memcpy(&dstVal, &vram[vramOffset], 2);
                if (state.pixelFormat == GU_PSM_5650) {
                    dr = ((dstVal >> 11) & 0x1F) * 255 / 31;
                    dg = ((dstVal >> 5) & 0x3F) * 255 / 63;
                    db = (dstVal & 0x1F) * 255 / 31;
                } else if (state.pixelFormat == GU_PSM_5551) {
                    dr = ((dstVal >> 11) & 0x1F) * 255 / 31;
                    dg = ((dstVal >> 6) & 0x1F) * 255 / 31;
                    db = ((dstVal >> 1) & 0x1F) * 255 / 31;
                    da = (dstVal & 1) ? 255 : 0;
                } else if (state.pixelFormat == GU_PSM_4444) {
                    dr = ((dstVal >> 12) & 0x0F) * 17;
                    dg = ((dstVal >> 8) & 0x0F) * 17;
                    db = ((dstVal >> 4) & 0x0F) * 17;
                    da = (dstVal & 0x0F) * 17;
                }
            }
            sr = (uint8_t)((sr * sa + dr * (255 - sa)) / 255);
            sg = (uint8_t)((sg * sa + dg * (255 - sa)) / 255);
            sb = (uint8_t)((sb * sa + db * (255 - sa)) / 255);
        }

        if (state.pixelFormat == GU_PSM_8888) {
            if (vramOffset + 4 <= vram.size()) {
                uint32_t packed = (sa << 24) | (sb << 16) | (sg << 8) | sr;
                memcpy(&vram[vramOffset], &packed, 4);
            }
        } else if (state.pixelFormat == GU_PSM_5650) {
            uint16_t packed = ((sr & 0xF8) << 8) | ((sg & 0xFC) << 3) | (sb >> 3);
            memcpy(&vram[vramOffset], &packed, 2);
        } else if (state.pixelFormat == GU_PSM_5551) {
            uint16_t packed = ((sr & 0xF8) << 7) | ((sg & 0xF8) << 2) | ((sb & 0xF8) >> 3) | (sa ? 1 : 0);
            memcpy(&vram[vramOffset], &packed, 2);
        } else if (state.pixelFormat == GU_PSM_4444) {
            uint16_t packed = ((sr & 0xF0) << 8) | ((sg & 0xF0) << 4) | (sb & 0xF0) | (sa >> 4);
            memcpy(&vram[vramOffset], &packed, 2);
        }
    }

    static uint32_t calculateVertexSize(uint32_t vtype) {
        uint32_t size = 0;
        uint32_t tc = vtype & 0x03;
        if (tc == 1) size += 2;
        else if (tc == 2) size += 4;
        else if (tc == 3) size += 8;

        uint32_t col = (vtype >> 2) & 0x07;
        if (col >= 4 && col <= 6) size += 2;
        else if (col == 7) size += 4;

        uint32_t nrm = (vtype >> 5) & 0x03;
        if (nrm == 1) size += 3;
        else if (nrm == 2) size += 6;
        else if (nrm == 3) size += 12;

        uint32_t pos = (vtype >> 7) & 0x03;
        if (pos == 1) size += 3;
        else if (pos == 2) size += 6;
        else if (pos == 3) size += 12;

        return size > 0 ? size : 12;
    }

    static UnpackedVertex unpackVertex(uint32_t vtype, uint32_t addr, const GeState& state) {
        UnpackedVertex v;
        v.x = 0; v.y = 0; v.z = 0;
        v.u = 0; v.v = 0;
        v.color = state.materialDiffuse;
        v.nx = 0; v.ny = 0; v.nz = 1.0f;

        uint32_t tc = vtype & 0x03;
        if (tc == 1) { v.u = internalReadMemory8(addr); v.v = internalReadMemory8(addr+1); addr += 2; }
        else if (tc == 2) { v.u = internalReadMemory16(addr); v.v = internalReadMemory16(addr+2); addr += 4; }
        else if (tc == 3) {
            union { uint32_t u; float f; } fu, fv;
            fu.u = internalReadMemory32(addr); fv.u = internalReadMemory32(addr+4);
            v.u = fu.f; v.v = fv.f; addr += 8;
        }

        uint32_t col = (vtype >> 2) & 0x07;
        if (col == 4) {
            uint16_t val = internalReadMemory16(addr);
            uint32_t r = ((val >> 11) & 0x1F) * 255 / 31;
            uint32_t g = ((val >> 5) & 0x3F) * 255 / 63;
            uint32_t b = (val & 0x1F) * 255 / 31;
            v.color = 0xFF000000 | (b << 16) | (g << 8) | r;
            addr += 2;
        } else if (col == 5) {
            uint16_t val = internalReadMemory16(addr);
            uint32_t r = ((val >> 11) & 0x1F) * 255 / 31;
            uint32_t g = ((val >> 6) & 0x1F) * 255 / 31;
            uint32_t b = ((val >> 1) & 0x1F) * 255 / 31;
            uint32_t a = (val & 1) ? 255 : 0;
            v.color = (a << 24) | (b << 16) | (g << 8) | r;
            addr += 2;
        } else if (col == 6) {
            uint16_t val = internalReadMemory16(addr);
            uint32_t r = ((val >> 12) & 0x0F) * 17;
            uint32_t g = ((val >> 8) & 0x0F) * 17;
            uint32_t b = ((val >> 4) & 0x0F) * 17;
            uint32_t a = (val & 0x0F) * 17;
            v.color = (a << 24) | (b << 16) | (g << 8) | r;
            addr += 2;
        } else if (col == 7) {
            v.color = internalReadMemory32(addr);
            addr += 4;
        }

        uint32_t pos = (vtype >> 7) & 0x03;
        if (pos == 1) {
            v.x = (float)(int8_t)internalReadMemory8(addr);
            v.y = (float)(int8_t)internalReadMemory8(addr+1);
            v.z = (float)(int8_t)internalReadMemory8(addr+2);
        } else if (pos == 2) {
            v.x = (float)(int16_t)internalReadMemory16(addr);
            v.y = (float)(int16_t)internalReadMemory16(addr+2);
            v.z = (float)(int16_t)internalReadMemory16(addr+4);
        } else if (pos == 3) {
            union { uint32_t u; float f; } fx, fy, fz;
            fx.u = internalReadMemory32(addr);
            fy.u = internalReadMemory32(addr+4);
            fz.u = internalReadMemory32(addr+8);
            v.x = fx.f; v.y = fy.f; v.z = fz.f;
        }

        return v;
    }

    void rasterizeTriangle(const UnpackedVertex& v0, const UnpackedVertex& v1, const UnpackedVertex& v2) {
        float x0 = v0.x, y0 = v0.y;
        float x1 = v1.x, y1 = v1.y;
        float x2 = v2.x, y2 = v2.y;

        float det = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);
        if (det == 0.0f) return;

        if (m_state.cullFaceEnable) {
            if (m_state.cullFace == 0 && det < 0.0f) return;
            if (m_state.cullFace == 1 && det > 0.0f) return;
        }

        UnpackedVertex tv0 = v0, tv1 = v1, tv2 = v2;
        if (det < 0.0f) {
            std::swap(tv1, tv2);
            x1 = tv1.x; y1 = tv1.y;
            x2 = tv2.x; y2 = tv2.y;
            det = -det;
        }

        int minX = (int)std::floor(std::min({tv0.x, tv1.x, tv2.x}));
        int maxX = (int)std::ceil(std::max({tv0.x, tv1.x, tv2.x}));
        int minY = (int)std::floor(std::min({tv0.y, tv1.y, tv2.y}));
        int maxY = (int)std::ceil(std::max({tv0.y, tv1.y, tv2.y}));

        int clipMinX = std::max({0, m_state.scissorX1, m_state.regionX1});
        int clipMaxX = std::min({480, m_state.scissorX2, m_state.regionX2});
        int clipMinY = std::max({0, m_state.scissorY1, m_state.regionY1});
        int clipMaxY = std::min({272, m_state.scissorY2, m_state.regionY2});

        minX = std::max(minX, clipMinX);
        maxX = std::min(maxX, clipMaxX);
        minY = std::max(minY, clipMinY);
        maxY = std::min(maxY, clipMaxY);

        if (minX >= maxX || minY >= maxY) return;

        float invDet = 1.0f / det;

        uint8_t r0 = tv0.color & 0xFF, g0 = (tv0.color >> 8) & 0xFF, b0 = (tv0.color >> 16) & 0xFF, a0 = (tv0.color >> 24) & 0xFF;
        uint8_t r1 = tv1.color & 0xFF, g1 = (tv1.color >> 8) & 0xFF, b1 = (tv1.color >> 16) & 0xFF, a1 = (tv1.color >> 24) & 0xFF;
        uint8_t r2 = tv2.color & 0xFF, g2 = (tv2.color >> 8) & 0xFF, b2 = (tv2.color >> 16) & 0xFF, a2 = (tv2.color >> 24) & 0xFF;

        for (int y = minY; y < maxY; y++) {
            float py = (float)y + 0.5f;
            for (int x = minX; x < maxX; x++) {
                float px = (float)x + 0.5f;

                float w0 = (x2 - x1) * (py - y1) - (y2 - y1) * (px - x1);
                float w1 = (x0 - x2) * (py - y2) - (y0 - y2) * (px - x2);
                float w2 = (x1 - x0) * (py - y0) - (y1 - y0) * (px - x0);

                if (w0 >= 0.0f && w1 >= 0.0f && w2 >= 0.0f) {
                    float l0 = w0 * invDet;
                    float l1 = w1 * invDet;
                    float l2 = w2 * invDet;

                    uint8_t r = (uint8_t)std::min(255.0f, std::max(0.0f, l0 * r0 + l1 * r1 + l2 * r2));
                    uint8_t g = (uint8_t)std::min(255.0f, std::max(0.0f, l0 * g0 + l1 * g1 + l2 * g2));
                    uint8_t b = (uint8_t)std::min(255.0f, std::max(0.0f, l0 * b0 + l1 * b1 + l2 * b2));
                    uint8_t a = (uint8_t)std::min(255.0f, std::max(0.0f, l0 * a0 + l1 * a1 + l2 * a2));

                    float z = l0 * tv0.z + l1 * tv1.z + l2 * tv2.z;

                    uint32_t finalColor = (a << 24) | (b << 16) | (g << 8) | r;

                    if (m_state.texEnable) {
                        float u = l0 * tv0.u + l1 * tv1.u + l2 * tv2.u;
                        float v = l0 * tv0.v + l1 * tv1.v + l2 * tv2.v;
                        uint32_t texel = sampleTexture(m_state, u, v);
                        uint8_t tr = texel & 0xFF, tg = (texel >> 8) & 0xFF, tb = (texel >> 16) & 0xFF, ta = (texel >> 24) & 0xFF;
                        r = (uint8_t)((r * tr) / 255);
                        g = (uint8_t)((g * tg) / 255);
                        b = (uint8_t)((b * tb) / 255);
                        a = (uint8_t)((a * ta) / 255);
                        finalColor = (a << 24) | (b << 16) | (g << 8) | r;
                    }

                    writePixel(m_state, x, y, finalColor, z);
                }
            }
        }
    }

    void rasterizeLine(const UnpackedVertex& v0, const UnpackedVertex& v1) {
        int x0 = (int)std::round(v0.x);
        int y0 = (int)std::round(v0.y);
        int x1 = (int)std::round(v1.x);
        int y1 = (int)std::round(v1.y);

        int dx = std::abs(x1 - x0);
        int dy = std::abs(y1 - y0);
        int sx = (x0 < x1) ? 1 : -1;
        int sy = (y0 < y1) ? 1 : -1;
        int err = dx - dy;

        int totalSteps = std::max(dx, dy);
        int currentStep = 0;

        uint8_t r0 = v0.color & 0xFF, g0 = (v0.color >> 8) & 0xFF, b0 = (v0.color >> 16) & 0xFF, a0 = (v0.color >> 24) & 0xFF;
        uint8_t r1 = v1.color & 0xFF, g1 = (v1.color >> 8) & 0xFF, b1 = (v1.color >> 16) & 0xFF, a1 = (v1.color >> 24) & 0xFF;

        while (true) {
            float t = (totalSteps > 0) ? ((float)currentStep / (float)totalSteps) : 0.0f;
            uint8_t r = (uint8_t)(r0 + t * (r1 - r0));
            uint8_t g = (uint8_t)(g0 + t * (g1 - g0));
            uint8_t b = (uint8_t)(b0 + t * (b1 - b0));
            uint8_t a = (uint8_t)(a0 + t * (a1 - a0));
            float z = v0.z + t * (v1.z - v0.z);

            writePixel(m_state, x0, y0, (a << 24) | (b << 16) | (g << 8) | r, z);

            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx)  { err += dx; y0 += sy; }
            currentStep++;
        }
    }

    void rasterizeSprite(const UnpackedVertex& v0, const UnpackedVertex& v1) {
        int minX = (int)std::floor(std::min(v0.x, v1.x));
        int maxX = (int)std::ceil(std::max(v0.x, v1.x));
        int minY = (int)std::floor(std::min(v0.y, v1.y));
        int maxY = (int)std::ceil(std::max(v0.y, v1.y));

        int clipMinX = std::max({0, m_state.scissorX1, m_state.regionX1});
        int clipMaxX = std::min({480, m_state.scissorX2, m_state.regionX2});
        int clipMinY = std::max({0, m_state.scissorY1, m_state.regionY1});
        int clipMaxY = std::min({272, m_state.scissorY2, m_state.regionY2});

        minX = std::max(minX, clipMinX);
        maxX = std::min(maxX, clipMaxX);
        minY = std::max(minY, clipMinY);
        maxY = std::min(maxY, clipMaxY);

        if (minX >= maxX || minY >= maxY) return;

        float widthSpan = std::max(1.0f, std::abs(v1.x - v0.x));
        float heightSpan = std::max(1.0f, std::abs(v1.y - v0.y));

        for (int y = minY; y < maxY; y++) {
            float ty = (float)(y - (int)v0.y) / heightSpan;
            for (int x = minX; x < maxX; x++) {
                float tx = (float)(x - (int)v0.x) / widthSpan;
                uint32_t color = v0.color;
                if (m_state.texEnable) {
                    float u = v0.u + tx * (v1.u - v0.u);
                    float v = v0.v + ty * (v1.v - v0.v);
                    uint32_t texel = sampleTexture(m_state, u, v);
                    uint8_t cr = color & 0xFF, cg = (color >> 8) & 0xFF, cb = (color >> 16) & 0xFF, ca = (color >> 24) & 0xFF;
                    uint8_t tr = texel & 0xFF, tg = (texel >> 8) & 0xFF, tb = (texel >> 16) & 0xFF, ta = (texel >> 24) & 0xFF;
                    color = (((ca * ta) / 255) << 24) | (((cb * tb) / 255) << 16) | (((cg * tg) / 255) << 8) | ((cr * tr) / 255);
                }
                writePixel(m_state, x, y, color, v0.z);
            }
        }
    }

    void drawPrimitives(uint32_t primType, uint32_t vtype, uint32_t count, uint32_t vaddr, uint32_t iaddr) override {
        if (count == 0) return;

        if (m_state.clearMode) {
            int x1 = std::max({0, m_state.scissorX1, m_state.regionX1});
            int y1 = std::max({0, m_state.scissorY1, m_state.regionY1});
            int x2 = std::min({480, m_state.scissorX2, m_state.regionX2});
            int y2 = std::min({272, m_state.scissorY2, m_state.regionY2});

            for (int y = y1; y < y2; y++) {
                for (int x = x1; x < x2; x++) {
                    writePixel(m_state, x, y, m_state.clearColor, 0.0f);
                }
            }
            return;
        }

        std::vector<UnpackedVertex> vertices;
        vertices.reserve(count);

        uint32_t idxFmt = (vtype >> 11) & 0x03;
        uint32_t vertexStride = calculateVertexSize(vtype);

        for (uint32_t i = 0; i < count; i++) {
            uint32_t idx = i;
            if (iaddr != 0 && idxFmt != 0) {
                if (idxFmt == 1) idx = internalReadMemory8(iaddr + i);
                else if (idxFmt == 2) idx = internalReadMemory16(iaddr + i * 2);
            }
            uint32_t curVaddr = vaddr + idx * vertexStride;
            UnpackedVertex v = unpackVertex(vtype, curVaddr, m_state);

            if (!m_state.isThrough) {
                float wX = v.x * m_state.worldMatrix[0] + v.y * m_state.worldMatrix[4] + v.z * m_state.worldMatrix[8] + m_state.worldMatrix[12];
                float wY = v.x * m_state.worldMatrix[1] + v.y * m_state.worldMatrix[5] + v.z * m_state.worldMatrix[9] + m_state.worldMatrix[13];
                float wZ = v.x * m_state.worldMatrix[2] + v.y * m_state.worldMatrix[6] + v.z * m_state.worldMatrix[10] + m_state.worldMatrix[14];

                float vX = wX * m_state.viewMatrix[0] + wY * m_state.viewMatrix[4] + wZ * m_state.viewMatrix[8] + m_state.viewMatrix[12];
                float vY = wX * m_state.viewMatrix[1] + wY * m_state.viewMatrix[5] + wZ * m_state.viewMatrix[9] + m_state.viewMatrix[13];
                float vZ = wX * m_state.viewMatrix[2] + wY * m_state.viewMatrix[6] + wZ * m_state.viewMatrix[10] + m_state.viewMatrix[14];

                float cX = vX * m_state.projMatrix[0] + vY * m_state.projMatrix[4] + vZ * m_state.projMatrix[8] + m_state.projMatrix[12];
                float cY = vX * m_state.projMatrix[1] + vY * m_state.projMatrix[5] + vZ * m_state.projMatrix[9] + m_state.projMatrix[13];
                float cZ = vX * m_state.projMatrix[2] + vY * m_state.projMatrix[6] + vZ * m_state.projMatrix[10] + m_state.projMatrix[14];
                float cW = vX * m_state.projMatrix[3] + vY * m_state.projMatrix[7] + vZ * m_state.projMatrix[11] + m_state.projMatrix[15];

                if (std::abs(cW) > 0.0001f) {
                    float ndcX = cX / cW;
                    float ndcY = cY / cW;
                    float ndcZ = cZ / cW;

                    v.x = ndcX * m_state.viewportXScale + m_state.viewportXCenter + (float)m_state.offsetX / 16.0f;
                    v.y = ndcY * m_state.viewportYScale + m_state.viewportYCenter + (float)m_state.offsetY / 16.0f;
                    v.z = ndcZ * m_state.viewportZScale + m_state.viewportZCenter;
                }
            }
            vertices.push_back(v);
        }

        switch (primType) {
            case 0:
                for (const auto& v : vertices) {
                    writePixel(m_state, (int)std::round(v.x), (int)std::round(v.y), v.color, v.z);
                }
                break;
            case 1:
                for (size_t i = 0; i + 1 < vertices.size(); i += 2) {
                    rasterizeLine(vertices[i], vertices[i + 1]);
                }
                break;
            case 2:
                for (size_t i = 0; i + 1 < vertices.size(); i++) {
                    rasterizeLine(vertices[i], vertices[i + 1]);
                }
                break;
            case 3:
                for (size_t i = 0; i + 2 < vertices.size(); i += 3) {
                    rasterizeTriangle(vertices[i], vertices[i + 1], vertices[i + 2]);
                }
                break;
            case 4:
                for (size_t i = 0; i + 2 < vertices.size(); i++) {
                    if (i % 2 == 0) {
                        rasterizeTriangle(vertices[i], vertices[i + 1], vertices[i + 2]);
                    } else {
                        rasterizeTriangle(vertices[i + 1], vertices[i], vertices[i + 2]);
                    }
                }
                break;
            case 5:
                for (size_t i = 1; i + 1 < vertices.size(); i++) {
                    rasterizeTriangle(vertices[0], vertices[i], vertices[i + 1]);
                }
                break;
            case 6:
                for (size_t i = 0; i + 1 < vertices.size(); i += 2) {
                    rasterizeSprite(vertices[i], vertices[i + 1]);
                }
                break;
            default:
                break;
        }
    }

    void getFramebufferRGBA(uint32_t* outPixels, int width, int height) override {
        if (!outPixels) return;
        uint32_t baseOfs = m_state.framebufAddr & 0x001FFFFF;
        uint32_t stride = m_state.framebufStride;
        uint32_t psm = m_state.pixelFormat;

        for (int y = 0; y < height && y < 272; y++) {
            for (int x = 0; x < width && x < 480; x++) {
                uint32_t offset = baseOfs + (y * stride + x) * (psm == GU_PSM_8888 ? 4 : 2);
                uint32_t colorRGBA = 0xFF000000;
                if (offset + 2 <= vram.size()) {
                    if (psm == GU_PSM_8888 && offset + 4 <= vram.size()) {
                        uint32_t val; memcpy(&val, &vram[offset], 4);
                        uint8_t r = val & 0xFF;
                        uint8_t g = (val >> 8) & 0xFF;
                        uint8_t b = (val >> 16) & 0xFF;
                        uint8_t a = (val >> 24) & 0xFF;
                        colorRGBA = (a << 24) | (b << 16) | (g << 8) | r;
                    } else if (psm == GU_PSM_5650) {
                        uint16_t val; memcpy(&val, &vram[offset], 2);
                        uint8_t r = ((val >> 11) & 0x1F) * 255 / 31;
                        uint8_t g = ((val >> 5) & 0x3F) * 255 / 63;
                        uint8_t b = (val & 0x1F) * 255 / 31;
                        colorRGBA = 0xFF000000 | (b << 16) | (g << 8) | r;
                    } else if (psm == GU_PSM_5551) {
                        uint16_t val; memcpy(&val, &vram[offset], 2);
                        uint8_t r = ((val >> 11) & 0x1F) * 255 / 31;
                        uint8_t g = ((val >> 6) & 0x1F) * 255 / 31;
                        uint8_t b = ((val >> 1) & 0x1F) * 255 / 31;
                        uint8_t a = (val & 1) ? 255 : 0;
                        colorRGBA = (a << 24) | (b << 16) | (g << 8) | r;
                    } else if (psm == GU_PSM_4444) {
                        uint16_t val; memcpy(&val, &vram[offset], 2);
                        uint8_t r = ((val >> 12) & 0x0F) * 17;
                        uint8_t g = ((val >> 8) & 0x0F) * 17;
                        uint8_t b = ((val >> 4) & 0x0F) * 17;
                        uint8_t a = (val & 0x0F) * 17;
                        colorRGBA = (a << 24) | (b << 16) | (g << 8) | r;
                    }
                }
                outPixels[y * width + x] = colorRGBA;
            }
        }
    }
};

static PspSoftwareRenderer g_softRenderer;
static IPspRenderer* g_pRenderer = &g_softRenderer;

class PspGeListProcessor {
private:
    IPspRenderer* m_renderer = nullptr;

    struct ListState {
        int listId = 0;
        uint32_t pc = 0;
        uint32_t stallAddr = 0;
        uint32_t baseAddr = 0;
        uint32_t offsetAddr = 0;
        uint32_t originAddr = 0;
        uint32_t vaddr = 0;
        uint32_t iaddr = 0;
        uint32_t callStack[32] = {0};
        int stackPtr = 0;
        int status = 0; // 0 = Completed, 1 = Running, 2 = Stalled, 3 = Signalled/Paused
        bool signalReceived = false;
        uint32_t signalArg = 0;
        bool finishReceived = false;
        uint32_t finishArg = 0;
        bool endReceived = false;
    };

    ListState m_activeList;
    int m_nextListId = 1;
    std::deque<std::string> m_traceLog;

public:
    PspGeListProcessor(IPspRenderer* renderer) : m_renderer(renderer) {}

    int enqueue(uint32_t listAddr, uint32_t stallAddr) {
        int id = m_nextListId++;
        m_activeList.listId = id;
        m_activeList.pc = listAddr;
        m_activeList.stallAddr = stallAddr;
        m_activeList.baseAddr = 0;
        m_activeList.offsetAddr = 0;
        m_activeList.originAddr = 0;
        m_activeList.vaddr = 0;
        m_activeList.iaddr = 0;
        m_activeList.stackPtr = 0;
        m_activeList.status = 1; // Running
        m_activeList.signalReceived = false;
        m_activeList.signalArg = 0;
        m_activeList.finishReceived = false;
        m_activeList.finishArg = 0;
        m_activeList.endReceived = false;

        __android_log_print(ANDROID_LOG_INFO, "NextEmuGE",
            "sceGeListEnqueue listId=%d, PC=0x%08X, Stall=0x%08X", id, listAddr, stallAddr);

        step(2000);
        return id;
    }

    void updateStallAddr(int id, uint32_t stallAddr) {
        if (m_activeList.listId == id || id == -1) {
            m_activeList.stallAddr = stallAddr;
            if (m_activeList.status == 2) {
                m_activeList.status = 1; // Resume
                step(2000);
            }
        }
    }

    int sync(int id) {
        if (m_activeList.listId == id) {
            step(5000);
            return m_activeList.status == 0 ? 0 : 1;
        }
        return 0;
    }

    bool isRunning() const {
        return m_activeList.status == 1;
    }

    void step(int maxCmds = 100) {
        if (m_activeList.status != 1 || !m_renderer) return;

        for (int i = 0; i < maxCmds; i++) {
            uint32_t pc = m_activeList.pc;
            if (m_activeList.stallAddr != 0 && pc == m_activeList.stallAddr) {
                m_activeList.status = 2; // Stalled
                break;
            }

            uint32_t cmd = internalReadMemory32(pc);
            uint8_t op = (cmd >> 24) & 0xFF;
            uint32_t arg = cmd & 0x00FFFFFF;

            char logBuf[256];
            snprintf(logBuf, sizeof(logBuf), "PC: 0x%08X | OP: 0x%02X | ARG: 0x%06X | CMD: %s",
                     pc, op, arg, getGeCmdName(op));
            m_traceLog.push_back(logBuf);
            if (m_traceLog.size() > 64) m_traceLog.pop_front();

            m_activeList.pc += 4;

            switch (op) {
                case GE_CMD_NOP:
                    break;

                case GE_CMD_BASE:
                    if ((arg & 0xFF0000) != 0) {
                        m_activeList.baseAddr = (arg & 0xFF0000) << 8;
                    } else {
                        m_activeList.baseAddr = (arg & 0xFF) << 24;
                    }
                    break;

                case GE_CMD_OFFSETADDR:
                    m_activeList.offsetAddr = (arg << 8);
                    break;

                case GE_CMD_ORIGIN:
                    m_activeList.offsetAddr = pc;
                    break;

                case GE_CMD_VADDR:
                    m_activeList.vaddr = ((m_activeList.baseAddr | (arg & 0x00FFFFFF)) + m_activeList.offsetAddr) & 0x0FFFFFFF;
                    break;

                case GE_CMD_IADDR:
                    m_activeList.iaddr = ((m_activeList.baseAddr | (arg & 0x00FFFFFF)) + m_activeList.offsetAddr) & 0x0FFFFFFF;
                    break;

                case GE_CMD_PRIM: {
                    uint32_t primType = (arg >> 16) & 0x07;
                    uint32_t count = arg & 0xFFFF;
                    uint32_t vtype = m_renderer->getState().vtype;
                    m_renderer->drawPrimitives(primType, vtype, count, m_activeList.vaddr, m_activeList.iaddr);
                    break;
                }

                case GE_CMD_JUMP:
                    m_activeList.pc = ((m_activeList.baseAddr | (arg & 0x00FFFFFF)) + m_activeList.offsetAddr) & 0x0FFFFFFC;
                    break;

                case GE_CMD_BJUMP:
                    m_activeList.pc = ((m_activeList.baseAddr | (arg & 0x00FFFFFF)) + m_activeList.offsetAddr) & 0x0FFFFFFC;
                    break;

                case GE_CMD_CALL:
                    if (m_activeList.stackPtr < 32) {
                        m_activeList.callStack[m_activeList.stackPtr++] = m_activeList.pc;
                    }
                    m_activeList.pc = ((m_activeList.baseAddr | (arg & 0x00FFFFFF)) + m_activeList.offsetAddr) & 0x0FFFFFFC;
                    break;

                case GE_CMD_RET:
                    if (m_activeList.stackPtr > 0) {
                        m_activeList.pc = m_activeList.callStack[--m_activeList.stackPtr];
                    } else {
                        m_activeList.status = 0; // Completed
                        return;
                    }
                    break;

                case GE_CMD_END:
                    m_activeList.endReceived = true;
                    m_activeList.status = 0; // Completed
                    return;

                case GE_CMD_FINISH:
                    m_activeList.finishReceived = true;
                    m_activeList.finishArg = arg;
                    m_activeList.status = 0; // Completed
                    return;

                case GE_CMD_SIGNAL: {
                    m_activeList.signalReceived = true;
                    m_activeList.signalArg = arg;
                    uint8_t sigBehavior = (arg >> 16) & 0xFF;
                    if (sigBehavior == 0x01) {
                        m_activeList.status = 3; // Paused/Signalled
                        return;
                    }
                    break;
                }

                default:
                    m_renderer->executeCommand(op, arg);
                    break;
            }
        }
    }

    std::string getTraceLog() const {
        std::ostringstream ss;
        ss << "=== PSP GE Command Trace Log (" << m_traceLog.size() << " entries) ===\n";
        for (const auto& log : m_traceLog) {
            ss << log << "\n";
        }
        return ss.str();
    }

    int getStatus() const { return m_activeList.status; }
    uint32_t getPC() const { return m_activeList.pc; }
    uint32_t getVaddr() const { return m_activeList.vaddr; }
    uint32_t getIaddr() const { return m_activeList.iaddr; }
    uint32_t getBaseAddr() const { return m_activeList.baseAddr; }
    uint32_t getOffsetAddr() const { return m_activeList.offsetAddr; }
    bool isSignalled() const { return m_activeList.signalReceived; }
    uint32_t getSignalArg() const { return m_activeList.signalArg; }
    bool isFinished() const { return m_activeList.finishReceived; }
    uint32_t getFinishArg() const { return m_activeList.finishArg; }
    bool isEnded() const { return m_activeList.endReceived; }
    int getCallStackDepth() const { return m_activeList.stackPtr; }
};

static PspGeListProcessor g_geProcessor(g_pRenderer);

static void gpuStep() {
    if (g_geProcessor.isRunning()) {
        g_geProcessor.step(64);
    }
}

struct GameInfo {
    std::string title;
    std::string gameId;
};
static GameInfo g_gameInfo = {"Unknown", "UNKNOWN"};

static bool findInDir(std::shared_ptr<IDiscImage> fp, uint32_t dir_lsn, uint32_t dir_size, const std::string& target, uint32_t& out_lsn, uint32_t& out_size) {
    std::vector<uint8_t> dir_buf(dir_size);
    if (fp->read(dir_lsn * 2048, dir_buf.data(), dir_size) != dir_size) return false;

    uint32_t offset = 0;
    while (offset + 33 < dir_size) {
        uint8_t len = dir_buf[offset];
        if (len == 0) {
            offset = (offset + 2047) & ~2047;
            if (offset >= dir_size) break;
            continue;
        }
        if (offset + len > dir_size) break;

        uint32_t extent;
        memcpy(&extent, &dir_buf[offset + 2], sizeof(uint32_t));
        uint32_t size;
        memcpy(&size, &dir_buf[offset + 10], sizeof(uint32_t));
        uint8_t name_len = dir_buf[offset + 32];
        
        std::string name((char*)&dir_buf[offset + 33], name_len);
        size_t semi = name.find(';');
        if (semi != std::string::npos) name = name.substr(0, semi);

        if (name == target) {
            out_lsn = extent;
            out_size = size;
            return true;
        }
        offset += len;
    }
    return false;
}

static GameInfo parseIso(std::shared_ptr<IDiscImage> fp) {
    GameInfo info = {"Unknown", "UNKNOWN"};
    if (!fp) return info;

    uint8_t pvd[2048];
    if (fp->read(16 * 2048, pvd, 2048) != 2048) {
        return info;
    }

    if (memcmp(pvd + 1, "CD001", 5) != 0) {
        return info;
    }

    uint32_t root_extent; memcpy(&root_extent, pvd + 156 + 2, sizeof(uint32_t));
    uint32_t root_size; memcpy(&root_size, pvd + 156 + 10, sizeof(uint32_t));

    uint32_t psp_game_ext, psp_game_size;
    if (findInDir(fp, root_extent, root_size, "PSP_GAME", psp_game_ext, psp_game_size)) {
        uint32_t sfo_ext, sfo_size;
        if (findInDir(fp, psp_game_ext, psp_game_size, "PARAM.SFO", sfo_ext, sfo_size)) {
            std::vector<uint8_t> sfo(sfo_size);
            if (fp->read(sfo_ext * 2048, sfo.data(), sfo_size) == sfo_size) {
                if (sfo_size > 20 && memcmp(sfo.data(), "\0PSF", 4) == 0) {
                    uint32_t key_ofs; memcpy(&key_ofs, &sfo[8], sizeof(uint32_t));
                    uint32_t val_ofs; memcpy(&val_ofs, &sfo[12], sizeof(uint32_t));
                    uint32_t count;   memcpy(&count, &sfo[16], sizeof(uint32_t));

                    for (uint32_t i = 0; i < count; i++) {
                        if (20 + i*16 + 12 > sfo_size) break;
                        uint16_t k_ofs; memcpy(&k_ofs, &sfo[20 + i*16 + 0], sizeof(uint16_t));
                        uint32_t v_ofs; memcpy(&v_ofs, &sfo[20 + i*16 + 8], sizeof(uint32_t));
                        
                        if (key_ofs + k_ofs < sfo_size && val_ofs + v_ofs < sfo_size) {
                            std::string key = (char*)&sfo[key_ofs + k_ofs];
                            std::string val = (char*)&sfo[val_ofs + v_ofs];
                            
                            if (key == "TITLE") info.title = val;
                            if (key == "DISC_ID") info.gameId = val;
                        }
                    }
                }
            }
        }
    }
    
    return info;
}

static uint8_t internalReadMemory8(uint32_t a);
static void internalWriteMemory8(uint32_t a, uint8_t v);
static uint16_t internalReadMemory16(uint32_t a);
static void internalWriteMemory16(uint32_t a, uint16_t v);
static uint32_t internalReadMemory32(uint32_t a);
static void internalWriteMemory32(uint32_t a, uint32_t v);

#pragma pack(push, 1)
struct PspModuleInfo {
    uint16_t modAttribute;   // 0x0000 = User, 0x1000 = Kernel
    uint8_t  modVersion[2];  // Major, Minor version
    char     modName[28];    // Module name null-terminated
    uint32_t gpValue;        // Initial GP (Global Pointer) value
    uint32_t exportsStart;   // Virtual addr of export table
    uint32_t exportsEnd;     // Virtual addr of export table end
    uint32_t importsStart;   // Virtual addr of import table
    uint32_t importsEnd;     // Virtual addr of import table end
};

struct PspLibraryImport {
    uint32_t nameAddr;       // Virtual addr of library name string
    uint16_t version;
    uint16_t flags;
    uint8_t  entrySize;      // Size of entry in 32-bit words
    uint8_t  varCount;       // Number of variable imports
    uint16_t funcCount;      // Number of function imports
    uint32_t nidTableAddr;   // Address of NID table
    uint32_t stubTableAddr;  // Address of stub/jump table
};
#pragma pack(pop)

static void initHleRegistry();
static void resolveModuleImports();

struct PspLoadedModule {
    std::string name;
    uint16_t versionMajor;
    uint16_t versionMinor;
    uint32_t gpValue;
    uint32_t entryPoint;
    uint32_t textAddr;
    uint32_t textSize;
    uint32_t importsStart;
    uint32_t importsEnd;
    bool isPRX;
    bool isEncrypted;
    std::string formatName;
};

static PspLoadedModule g_activeModule = {};
static std::string g_loaderStatus = "Idle";

static uint32_t internalReadMemory32(uint32_t a) {
    a &= ~3;
    uint32_t val = 0;
    if (a >= 0x00010000 && a < 0x00010000 + 16 * 1024) {
        memcpy(&val, &scratchpadRAM[a - 0x00010000], 4);
    } else if (a >= 0x04000000 && a < 0x04000000 + 2 * 1024 * 1024) {
        memcpy(&val, &vram[a - 0x04000000], 4);
    } else if (a >= 0x08000000 && a < 0x08000000 + 32 * 1024 * 1024) {
        memcpy(&val, &mainRAM[a - 0x08000000], 4);
    } else if (a >= 0x88000000 && a < 0x88000000 + 4 * 1024 * 1024) {
        memcpy(&val, &kernelRAM[a - 0x88000000], 4);
    }
    return val;
}

static void internalWriteMemory32(uint32_t a, uint32_t v) {
    a &= ~3;
    if (a >= 0x00010000 && a < 0x00010000 + 16 * 1024) {
        memcpy(&scratchpadRAM[a - 0x00010000], &v, 4);
    } else if (a >= 0x04000000 && a < 0x04000000 + 2 * 1024 * 1024) {
        memcpy(&vram[a - 0x04000000], &v, 4);
    } else if (a >= 0x08000000 && a < 0x08000000 + 32 * 1024 * 1024) {
        memcpy(&mainRAM[a - 0x08000000], &v, 4);
    } else if (a >= 0x88000000 && a < 0x88000000 + 4 * 1024 * 1024) {
        memcpy(&kernelRAM[a - 0x88000000], &v, 4);
    }
}

static uint16_t internalReadMemory16(uint32_t a) {
    a &= ~1;
    uint16_t val = 0;
    if (a >= 0x00010000 && a < 0x00010000 + 16 * 1024) {
        memcpy(&val, &scratchpadRAM[a - 0x00010000], 2);
    } else if (a >= 0x04000000 && a < 0x04000000 + 2 * 1024 * 1024) {
        memcpy(&val, &vram[a - 0x04000000], 2);
    } else if (a >= 0x08000000 && a < 0x08000000 + 32 * 1024 * 1024) {
        memcpy(&val, &mainRAM[a - 0x08000000], 2);
    } else if (a >= 0x88000000 && a < 0x88000000 + 4 * 1024 * 1024) {
        memcpy(&val, &kernelRAM[a - 0x88000000], 2);
    }
    return val;
}

static void internalWriteMemory16(uint32_t a, uint16_t v) {
    a &= ~1;
    if (a >= 0x00010000 && a < 0x00010000 + 16 * 1024) {
        memcpy(&scratchpadRAM[a - 0x00010000], &v, 2);
    } else if (a >= 0x04000000 && a < 0x04000000 + 2 * 1024 * 1024) {
        memcpy(&vram[a - 0x04000000], &v, 2);
    } else if (a >= 0x08000000 && a < 0x08000000 + 32 * 1024 * 1024) {
        memcpy(&mainRAM[a - 0x08000000], &v, 2);
    } else if (a >= 0x88000000 && a < 0x88000000 + 4 * 1024 * 1024) {
        memcpy(&kernelRAM[a - 0x88000000], &v, 2);
    }
}

static uint8_t internalReadMemory8(uint32_t a) {
    if (a >= 0x00010000 && a < 0x00010000 + 16 * 1024) {
        return scratchpadRAM[a - 0x00010000];
    } else if (a >= 0x04000000 && a < 0x04000000 + 2 * 1024 * 1024) {
        return vram[a - 0x04000000];
    } else if (a >= 0x08000000 && a < 0x08000000 + 32 * 1024 * 1024) {
        return mainRAM[a - 0x08000000];
    } else if (a >= 0x88000000 && a < 0x88000000 + 4 * 1024 * 1024) {
        return kernelRAM[a - 0x88000000];
    }
    return 0;
}

static void internalWriteMemory8(uint32_t a, uint8_t v) {
    if (a >= 0x00010000 && a < 0x00010000 + 16 * 1024) {
        scratchpadRAM[a - 0x00010000] = v;
    } else if (a >= 0x04000000 && a < 0x04000000 + 2 * 1024 * 1024) {
        vram[a - 0x04000000] = v;
    } else if (a >= 0x08000000 && a < 0x08000000 + 32 * 1024 * 1024) {
        mainRAM[a - 0x08000000] = v;
    } else if (a >= 0x88000000 && a < 0x88000000 + 4 * 1024 * 1024) {
        kernelRAM[a - 0x88000000] = v;
    }
}

static void parseModuleInfoFromRam(uint32_t vaddr, uint32_t loadBase) {
    if (vaddr < 0x08000000 || vaddr + sizeof(PspModuleInfo) > 0x08000000 + 32 * 1024 * 1024) {
        return;
    }
    
    PspModuleInfo info;
    uint32_t offset = vaddr - 0x08000000;
    memcpy(&info, &mainRAM[offset], sizeof(PspModuleInfo));
    
    char nameBuf[29] = {0};
    memcpy(nameBuf, info.modName, 28);
    g_activeModule.name = std::string(nameBuf);
    g_activeModule.versionMajor = info.modVersion[1];
    g_activeModule.versionMinor = info.modVersion[0];
    
    if (info.gpValue != 0) {
        g_activeModule.gpValue = info.gpValue;
    } else {
        g_activeModule.gpValue = loadBase;
    }
    
    g_activeModule.importsStart = info.importsStart;
    g_activeModule.importsEnd = info.importsEnd;
    
    __android_log_print(ANDROID_LOG_INFO, "NextEmuLoader",
        "Module parsed from RAM: '%s' v%d.%d (GP: 0x%08X, Imports: 0x%08X-0x%08X)",
        g_activeModule.name.c_str(), g_activeModule.versionMajor, g_activeModule.versionMinor,
        g_activeModule.gpValue, g_activeModule.importsStart, g_activeModule.importsEnd);
}

static bool parseAndLoadElfBuffer(const uint8_t* buffer, size_t size) {
    initHleRegistry();
    g_activeModule = {};
    if (!buffer || size < 52) {
        g_loaderStatus = "Error: ELF buffer too small or null";
        return false;
    }

    if (size >= 4 && memcmp(buffer, "~PSP", 4) == 0) {
        g_activeModule.isEncrypted = true;
        g_activeModule.formatName = "~PSP Encrypted PRX";
        g_loaderStatus = "Encrypted EBOOT (~PSP signature). Decryption keys required.";
        __android_log_print(ANDROID_LOG_WARN, "NextEmuLoader", "Encrypted PSP binary detected.");
        return false;
    }

    if (memcmp(buffer, "\177ELF", 4) != 0) {
        g_loaderStatus = "Error: Invalid ELF magic header";
        return false;
    }

    uint8_t elfClass = buffer[4];     // 1 = 32-bit
    uint8_t elfData = buffer[5];      // 1 = Little Endian
    if (elfClass != 1 || elfData != 1) {
        g_loaderStatus = "Error: PSP requires 32-bit Little-Endian ELF";
        return false;
    }

    uint16_t e_type;   memcpy(&e_type, buffer + 16, 2);
    uint16_t e_machine;memcpy(&e_machine, buffer + 18, 2);
    uint32_t e_entry;  memcpy(&e_entry, buffer + 24, 4);
    uint32_t e_phoff;  memcpy(&e_phoff, buffer + 28, 4);
    uint16_t e_phentsize; memcpy(&e_phentsize, buffer + 42, 2);
    uint16_t e_phnum;  memcpy(&e_phnum, buffer + 44, 2);

    if (e_machine != 8) { // EM_MIPS = 8
        g_loaderStatus = "Error: Invalid ELF architecture (expected MIPS)";
        return false;
    }

    bool isPRX = (e_type == 0xF0A0) || (e_type == 1); // ET_SCE_PRX or ET_REL
    g_activeModule.isPRX = isPRX;
    g_activeModule.formatName = isPRX ? "PSP PRX Relocatable Executable" : "PSP Static ELF";

    uint32_t defaultBase = isPRX ? 0x08804000 : 0x08800000;
    uint32_t preferredBase = e_entry;
    if (preferredBase < 0x08000000 || preferredBase >= 0x0A000000) {
        preferredBase = defaultBase;
    }
    uint32_t loadBase = preferredBase;

    uint32_t moduleInfoAddr = 0;
    size_t loadedSegments = 0;

    for (uint16_t i = 0; i < e_phnum; i++) {
        size_t phOfs = e_phoff + i * e_phentsize;
        if (phOfs + 32 > size) break;

        uint32_t p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_flags, p_align;
        memcpy(&p_type,   buffer + phOfs + 0, 4);
        memcpy(&p_offset, buffer + phOfs + 4, 4);
        memcpy(&p_vaddr,  buffer + phOfs + 8, 4);
        memcpy(&p_paddr,  buffer + phOfs + 12, 4);
        memcpy(&p_filesz, buffer + phOfs + 16, 4);
        memcpy(&p_memsz,  buffer + phOfs + 20, 4);
        memcpy(&p_flags,  buffer + phOfs + 24, 4);
        memcpy(&p_align,  buffer + phOfs + 28, 4);

        if (p_type == 0x61000010) { // PT_SCE_MODULEINFO
            moduleInfoAddr = p_vaddr;
            continue;
        }

        if (p_type != 1 && p_type != 0x61000000) continue; // PT_LOAD or PT_SCE_PRX

        uint32_t targetVAddr = p_vaddr;
        if (targetVAddr < 0x08000000) {
            targetVAddr += loadBase;
        }

        if (targetVAddr < 0x08000000 || targetVAddr + p_memsz > 0x08000000 + 32 * 1024 * 1024) {
            __android_log_print(ANDROID_LOG_WARN, "NextEmuLoader", "Segment out of RAM bounds: 0x%08X", targetVAddr);
            continue;
        }

        if (p_offset + p_filesz <= size) {
            uint32_t ramOfs = targetVAddr - 0x08000000;
            memcpy(&mainRAM[ramOfs], buffer + p_offset, p_filesz);

            if (p_memsz > p_filesz) {
                uint32_t bssSize = p_memsz - p_filesz;
                memset(&mainRAM[ramOfs + p_filesz], 0, bssSize);
            }

            loadedSegments++;
            __android_log_print(ANDROID_LOG_INFO, "NextEmuLoader",
                "Loaded PT_LOAD segment %d to 0x%08X (file: %u B, mem: %u B)",
                i, targetVAddr, p_filesz, p_memsz);
        }
    }

    uint32_t finalEntry = e_entry;
    if (finalEntry < 0x08000000) finalEntry += loadBase;
    g_activeModule.entryPoint = finalEntry;

    if (moduleInfoAddr != 0) {
        uint32_t resolvedModInfo = moduleInfoAddr;
        if (resolvedModInfo < 0x08000000) resolvedModInfo += loadBase;
        parseModuleInfoFromRam(resolvedModInfo, loadBase);
    }

    if (g_activeModule.importsStart != 0 && g_activeModule.importsEnd != 0) {
        resolveModuleImports();
    }

    g_cpu.pc = finalEntry;
    g_cpu.nextPc = finalEntry + 4;
    g_cpu.regs[29] = 0x09F00000; // $sp (Stack Pointer)
    g_cpu.regs[28] = (g_activeModule.gpValue != 0) ? g_activeModule.gpValue : loadBase; // $gp
    g_cpu.regs[31] = 0x08000000; // $ra
    g_cpu.regs[0]  = 0;

    std::ostringstream statusSs;
    statusSs << "Successfully loaded " << g_activeModule.formatName
             << " (" << loadedSegments << " segments, entry: 0x" << std::hex << finalEntry << ")";
    g_loaderStatus = statusSs.str();

    return true;
}

static bool loadEboot() {
    std::shared_ptr<IDiscImage> fp = openGameImage();
    if (!fp) {
        g_loaderStatus = "Error: Cannot open game stream";
        return false;
    }

    uint8_t pvd[2048];
    if (fp->read(16 * 2048, pvd, 2048) != 2048) {
        
        g_loaderStatus = "Error: Failed to read PVD";
        return false;
    }

    uint32_t root_ext, root_size;
    memcpy(&root_ext, pvd + 156 + 2, sizeof(uint32_t));
    memcpy(&root_size, pvd + 156 + 10, sizeof(uint32_t));

    uint32_t psp_game_ext, psp_game_size;
    if (!findInDir(fp, root_ext, root_size, "PSP_GAME", psp_game_ext, psp_game_size)) {
        g_loaderStatus = "Error: PSP_GAME folder not found in ISO";
        return false;
    }

    uint32_t sysdir_ext, sysdir_size;
    if (!findInDir(fp, psp_game_ext, psp_game_size, "SYSDIR", sysdir_ext, sysdir_size)) {
        g_loaderStatus = "Error: SYSDIR folder not found";
        return false;
    }

    uint32_t eboot_ext, eboot_size;
    if (!findInDir(fp, sysdir_ext, sysdir_size, "EBOOT.BIN", eboot_ext, eboot_size)) {
        g_loaderStatus = "Error: EBOOT.BIN not found";
        return false;
    }

    std::vector<uint8_t> rawHeader(128);
    if (fp->read(eboot_ext * 2048, rawHeader.data(), 128) != 128) {
        
        g_loaderStatus = "Error: Failed to read EBOOT header";
        return false;
    }

    uint32_t psarOffset = 0;
    bool isPBP = (memcmp(rawHeader.data(), "\0PBP", 4) == 0);

    if (isPBP) {
        memcpy(&psarOffset, rawHeader.data() + 0x24, 4);
        __android_log_print(ANDROID_LOG_INFO, "NextEmuLoader", "PBP Header detected. PSAR offset: %u", psarOffset);
    }

    std::vector<uint8_t> ebootBuf(eboot_size);
    size_t bytesRead = fp->read(eboot_ext * 2048, ebootBuf.data(), eboot_size);
    

    if (bytesRead < eboot_size) {
        ebootBuf.resize(bytesRead);
    }

    return parseAndLoadElfBuffer(ebootBuf.data(), ebootBuf.size());
}

// --- PSP HLE Core Error Codes ---
#define SCE_KERNEL_ERROR_OK                   0
#define SCE_KERNEL_ERROR_ERROR                0x80020001
#define SCE_KERNEL_ERROR_NOT_FOUND            0x80020002
#define SCE_KERNEL_ERROR_NO_MEMORY            0x80020022
#define SCE_KERNEL_ERROR_INVALID_ID           0x80020018
#define SCE_KERNEL_ERROR_INVALID_ARGUMENT     0x80020003
#define SCE_KERNEL_ERROR_UNSUPPORTED          0x80000004
#define SCE_KERNEL_ERROR_BADF                 0x80020130
#define SCE_KERNEL_ERROR_NOFILE               0x8002012F
#define SCE_KERNEL_ERROR_LIBRARY_NOT_FOUND    0x80020001

typedef void (*HleHandlerFunc)(MipsCpu& cpu);

struct HleFunction {
    std::string moduleName;
    std::string funcName;
    uint32_t nid;
    uint32_t syscallIndex;
    HleHandlerFunc handler;
};

static std::unordered_map<uint32_t, HleFunction> g_hleNidRegistry;
static std::unordered_map<uint32_t, HleFunction> g_hleSyscallIndexRegistry;
static uint32_t g_nextSyscallIndex = 0x0100;

struct UnknownStubInfo {
    std::string moduleName;
    uint32_t nid;
};
static std::unordered_map<uint32_t, UnknownStubInfo> g_unknownSyscallMap;

typedef void (*SyscallHandler)(MipsCpu& cpu);
static std::unordered_map<uint32_t, SyscallHandler> g_syscallTable;

struct VfsFile {
    bool inUse;
    uint32_t extent;
    uint32_t size;
    uint32_t offset;
    std::shared_ptr<IDiscImage> fp;
    bool isDir;
    std::string path;
};
static std::map<int, VfsFile> g_vfsMap;
static int g_nextFd = 1;

struct HleThread {
    int id;
    std::string name;
    uint32_t entry;
    int priority;
    int stackSize;
    uint32_t attr;
};
static std::map<int, HleThread> g_threads;
static int g_nextThreadId = 1;

struct HleMemBlock {
    int id;
    std::string name;
    uint32_t addr;
    uint32_t size;
    int partitionId;
};
static std::map<int, HleMemBlock> g_memBlocks;
static int g_nextBlockId = 1;
static uint32_t g_heapPointer = 0x08A00000;

static void registerHleFunction(const std::string& moduleName, const std::string& funcName, uint32_t nid, HleHandlerFunc handler) {
    uint32_t sysIdx = g_nextSyscallIndex++;
    HleFunction func = { moduleName, funcName, nid, sysIdx, handler };
    g_hleNidRegistry[nid] = func;
    g_hleSyscallIndexRegistry[sysIdx] = func;
    g_syscallTable[nid] = (SyscallHandler)handler;
    g_syscallTable[sysIdx] = (SyscallHandler)handler;
}

// --- sceKernel Handlers ---
static void hle_sceKernelCreateThread(MipsCpu& cpu) {
    uint32_t name_ptr = cpu.regs[4];
    uint32_t entry = cpu.regs[5];
    int priority = (int)cpu.regs[6];
    int stackSize = (int)cpu.regs[7];

    std::string threadName;
    uint32_t ptr = name_ptr;
    while (true) {
        char c = (char)internalReadMemory8(ptr++);
        if (c == 0 || threadName.length() > 64) break;
        threadName += c;
    }
    if (threadName.empty()) threadName = "psp_thread";

    int tid = g_nextThreadId++;
    HleThread th = { tid, threadName, entry, priority, stackSize, 0 };
    g_threads[tid] = th;

    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
        "sceKernelCreateThread('%s', entry=0x%08X, priority=%d, stackSize=%d) -> threadId=%d",
        threadName.c_str(), entry, priority, stackSize, tid);

    cpu.regs[2] = (uint32_t)tid;
}

static void hle_sceKernelStartThread(MipsCpu& cpu) {
    int tid = (int)cpu.regs[4];
    uint32_t arglen = cpu.regs[5];
    uint32_t argp = cpu.regs[6];

    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
        "sceKernelStartThread(threadId=%d, arglen=%u, argp=0x%08X) -> OK", tid, arglen, argp);

    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelExitThread(MipsCpu& cpu) {
    int status = (int)cpu.regs[4];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelExitThread(status=%d)", status);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelExitDeleteThread(MipsCpu& cpu) {
    int status = (int)cpu.regs[4];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelExitDeleteThread(status=%d)", status);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelSleepThread(MipsCpu& cpu) {
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelSleepThread()");
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelSleepThreadCB(MipsCpu& cpu) {
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelSleepThreadCB()");
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelDelayThread(MipsCpu& cpu) {
    uint32_t delay_us = cpu.regs[4];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelDelayThread(%u us)", delay_us);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelDelayThreadCB(MipsCpu& cpu) {
    uint32_t delay_us = cpu.regs[4];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelDelayThreadCB(%u us)", delay_us);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelWaitThreadEnd(MipsCpu& cpu) {
    int tid = (int)cpu.regs[4];
    uint32_t timeout_ptr = cpu.regs[5];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelWaitThreadEnd(threadId=%d, timeout=0x%08X)", tid, timeout_ptr);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelAllocPartitionMemory(MipsCpu& cpu) {
    int partitionId = (int)cpu.regs[4];
    uint32_t name_ptr = cpu.regs[5];
    uint32_t type = cpu.regs[6];
    uint32_t size = cpu.regs[7];

    std::string blockName;
    uint32_t ptr = name_ptr;
    while (true) {
        char c = (char)internalReadMemory8(ptr++);
        if (c == 0 || blockName.length() > 64) break;
        blockName += c;
    }
    if (blockName.empty()) blockName = "heap_block";

    uint32_t alignedSize = (size + 63) & ~63U;
    uint32_t blockAddr = g_heapPointer;
    g_heapPointer += alignedSize;

    int blockId = g_nextBlockId++;
    HleMemBlock block = { blockId, blockName, blockAddr, alignedSize, partitionId };
    g_memBlocks[blockId] = block;

    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
        "sceKernelAllocPartitionMemory(partition=%d, '%s', type=%u, size=%u) -> blockId=%d, addr=0x%08X",
        partitionId, blockName.c_str(), type, size, blockId, blockAddr);

    cpu.regs[2] = (uint32_t)blockId;
}

static void hle_sceKernelFreePartitionMemory(MipsCpu& cpu) {
    int blockId = (int)cpu.regs[4];
    g_memBlocks.erase(blockId);
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelFreePartitionMemory(blockId=%d) -> OK", blockId);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceKernelGetBlockHeadAddr(MipsCpu& cpu) {
    int blockId = (int)cpu.regs[4];
    auto it = g_memBlocks.find(blockId);
    if (it != g_memBlocks.end()) {
        cpu.regs[2] = it->second.addr;
    } else {
        cpu.regs[2] = 0;
    }
}

static void hle_sceKernelCreateCallback(MipsCpu& cpu) {
    uint32_t func_ptr = cpu.regs[5];
    uint32_t arg = cpu.regs[6];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelCreateCallback(func=0x%08X, arg=0x%08X) -> cb=1", func_ptr, arg);
    cpu.regs[2] = 1;
}

static void hle_sceKernelDeleteCallback(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceKernelCreateTimer(MipsCpu& cpu) { cpu.regs[2] = 1; }
static void hle_sceKernelSetTimerHandler(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceKernelStartTimer(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceKernelStopTimer(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceKernelDcacheWritebackAll(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceKernelDcacheWritebackRange(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceKernelDcacheInvalidateRange(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }

static void hle_sceKernelExitGame(MipsCpu& cpu) {
    g_isInitialized = false;
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceKernelExitGame invoked. Halting emulation.");
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

// --- sceIo Handlers ---
static void hle_sceIoOpen(MipsCpu& cpu) {
    uint32_t file_ptr = cpu.regs[4];
    uint32_t flags = cpu.regs[5];
    uint32_t mode = cpu.regs[6];

    std::string path;
    uint32_t ptr = file_ptr;
    while (true) {
        char c = (char)internalReadMemory8(ptr++);
        if (c == 0 || path.length() > 255) break;
        path += c;
    }

    size_t colon_pos = path.find(":/");
    std::string cleanPath = path;
    if (colon_pos != std::string::npos) {
        cleanPath = path.substr(colon_pos + 2);
    }
    while (!cleanPath.empty() && cleanPath[0] == '/') cleanPath.erase(0, 1);

    std::shared_ptr<IDiscImage> fp = openGameImage();
    bool found = false;
    uint32_t extent = 0, size = 0;

    if (fp) {
        uint8_t pvd[2048];
        if (fp->read(16 * 2048, pvd, 2048) == 2048) {
            memcpy(&extent, pvd + 156 + 2, sizeof(uint32_t));
            memcpy(&size, pvd + 156 + 10, sizeof(uint32_t));

            std::vector<std::string> parts;
            std::string current_part = "";
            for (char c : cleanPath) {
                if (c == '/') {
                    if (!current_part.empty()) { parts.push_back(current_part); current_part = ""; }
                } else current_part += c;
            }
            if (!current_part.empty()) parts.push_back(current_part);

            found = true;
            for (const auto& p : parts) {
                uint32_t next_ext, next_size;
                if (findInDir(fp, extent, size, p, next_ext, next_size)) {
                    extent = next_ext; size = next_size;
                } else { found = false; break; }
            }
        }
    }

    if (found) {
        int fd = g_nextFd++;
        g_vfsMap[fd] = { true, extent, size, 0, fp, false, path };
        __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
            "sceIoOpen('%s', flags=0x%X) -> fd=%d (extent=%u, size=%u B)", path.c_str(), flags, fd, extent, size);
        cpu.regs[2] = (uint32_t)fd;
    } else {
        if (fp) 
        __android_log_print(ANDROID_LOG_WARN, "NextEmuHLE",
            "sceIoOpen('%s', flags=0x%X) -> File Not Found (0x8002012F)", path.c_str(), flags);
        cpu.regs[2] = SCE_KERNEL_ERROR_NOFILE;
    }
}

static void hle_sceIoClose(MipsCpu& cpu) {
    int fd = (int)cpu.regs[4];
    auto it = g_vfsMap.find(fd);
    if (it != g_vfsMap.end() && it->second.inUse) {
        if (it->second.fp) it->second.fp = nullptr;
        g_vfsMap.erase(it);
        __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceIoClose(fd=%d) -> OK", fd);
        cpu.regs[2] = SCE_KERNEL_ERROR_OK;
    } else {
        cpu.regs[2] = SCE_KERNEL_ERROR_BADF;
    }
}

static void hle_sceIoRead(MipsCpu& cpu) {
    int fd = (int)cpu.regs[4];
    uint32_t data_ptr = cpu.regs[5];
    uint32_t read_size = cpu.regs[6];

    auto it = g_vfsMap.find(fd);
    if (it != g_vfsMap.end() && it->second.inUse) {
        VfsFile& f = it->second;
        if (!f.fp || f.offset >= f.size) {
            cpu.regs[2] = 0;
            return;
        }
        if (f.offset + read_size > f.size) {
            read_size = f.size - f.offset;
        }
        std::vector<uint8_t> buf(read_size);
        size_t actual_read = f.fp->read(f.extent * 2048 + f.offset, buf.data(), read_size);
        for (size_t i = 0; i < actual_read; i++) {
            internalWriteMemory8(data_ptr + (uint32_t)i, buf[i]);
        }
        f.offset += (uint32_t)actual_read;
        __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
            "sceIoRead(fd=%d, ptr=0x%08X, size=%u) -> read=%zu B", fd, data_ptr, read_size, actual_read);
        cpu.regs[2] = (uint32_t)actual_read;
    } else {
        cpu.regs[2] = SCE_KERNEL_ERROR_BADF;
    }
}

static void hle_sceIoWrite(MipsCpu& cpu) {
    int fd = (int)cpu.regs[4];
    uint32_t ptr = cpu.regs[5];
    uint32_t size = cpu.regs[6];

    std::string str;
    for (uint32_t i = 0; i < size && i < 1024; i++) {
        uint8_t b = internalReadMemory8(ptr + i);
        if (b == 0) break;
        str += (char)b;
    }
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceIoWrite(fd=%d, size=%u): '%s'", fd, size, str.c_str());
    cpu.regs[2] = size;
}

static void hle_sceIoLseek(MipsCpu& cpu) {
    int fd = (int)cpu.regs[4];
    int64_t offset = (int32_t)cpu.regs[5];
    int whence = (int)cpu.regs[6];
    if (whence > 2) whence = (int)cpu.regs[7];

    auto it = g_vfsMap.find(fd);
    if (it != g_vfsMap.end() && it->second.inUse) {
        VfsFile& f = it->second;
        int64_t new_offset = f.offset;
        if (whence == 0) new_offset = offset;
        else if (whence == 1) new_offset += offset;
        else if (whence == 2) new_offset = (int64_t)f.size + offset;

        if (new_offset < 0) new_offset = 0;
        if (new_offset > (int64_t)f.size) new_offset = f.size;

        f.offset = (uint32_t)new_offset;
        __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
            "sceIoLseek(fd=%d, offset=%lld, whence=%d) -> newOffset=%u", fd, (long long)offset, whence, f.offset);
        cpu.regs[2] = (uint32_t)(new_offset & 0xFFFFFFFF);
        cpu.regs[3] = (uint32_t)(new_offset >> 32);
    } else {
        cpu.regs[2] = SCE_KERNEL_ERROR_BADF;
    }
}

static void hle_sceIoLseek32(MipsCpu& cpu) {
    int fd = (int)cpu.regs[4];
    int32_t offset = (int32_t)cpu.regs[5];
    int whence = (int)cpu.regs[6];

    auto it = g_vfsMap.find(fd);
    if (it != g_vfsMap.end() && it->second.inUse) {
        VfsFile& f = it->second;
        int64_t new_offset = f.offset;
        if (whence == 0) new_offset = offset;
        else if (whence == 1) new_offset += offset;
        else if (whence == 2) new_offset = (int64_t)f.size + offset;

        if (new_offset < 0) new_offset = 0;
        if (new_offset > (int64_t)f.size) new_offset = f.size;

        f.offset = (uint32_t)new_offset;
        cpu.regs[2] = (uint32_t)new_offset;
    } else {
        cpu.regs[2] = SCE_KERNEL_ERROR_BADF;
    }
}

static void hle_sceIoDopen(MipsCpu& cpu) {
    int dfd = g_nextFd++;
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceIoDopen -> dfd=%d", dfd);
    cpu.regs[2] = (uint32_t)dfd;
}

static void hle_sceIoDread(MipsCpu& cpu) {
    int dfd = (int)cpu.regs[4];
    uint32_t dirent_ptr = cpu.regs[5];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceIoDread(dfd=%d, ptr=0x%08X)", dfd, dirent_ptr);
    cpu.regs[2] = 0;
}

static void hle_sceIoDclose(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }

static void hle_sceIoGetstat(MipsCpu& cpu) {
    uint32_t path_ptr = cpu.regs[4];
    uint32_t stat_ptr = cpu.regs[5];

    std::string path;
    uint32_t ptr = path_ptr;
    while (true) {
        char c = (char)internalReadMemory8(ptr++);
        if (c == 0 || path.length() > 255) break;
        path += c;
    }

    std::shared_ptr<IDiscImage> fp = openGameImage();
    bool found = false;
    uint32_t extent = 0, size = 0;
    if (fp) {
        uint8_t pvd[2048];
        if (fp->read(16 * 2048, pvd, 2048) == 2048) {
            memcpy(&extent, pvd + 156 + 2, sizeof(uint32_t));
            memcpy(&size, pvd + 156 + 10, sizeof(uint32_t));
            found = true;
        }
        
    }

    if (found && stat_ptr != 0) {
        internalWriteMemory32(stat_ptr + 0, 0020000 | 0777);
        internalWriteMemory32(stat_ptr + 4, 0);
        internalWriteMemory32(stat_ptr + 8, size);
        internalWriteMemory32(stat_ptr + 12, 0);
        cpu.regs[2] = SCE_KERNEL_ERROR_OK;
    } else {
        cpu.regs[2] = SCE_KERNEL_ERROR_NOFILE;
    }
}

// --- sceDisplay Handlers ---
static void hle_sceDisplaySetMode(MipsCpu& cpu) {
    int mode = (int)cpu.regs[4];
    int width = (int)cpu.regs[5];
    int height = (int)cpu.regs[6];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceDisplaySetMode(mode=%d, %dx%d)", mode, width, height);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceDisplaySetFrameBuf(MipsCpu& cpu) {
    uint32_t topaddr = cpu.regs[4];
    int bufferwidth = (int)cpu.regs[5];
    int pixelformat = (int)cpu.regs[6];
    int sync = (int)cpu.regs[7];

    g_pRenderer->setFramebuffer(topaddr, bufferwidth, pixelformat);

    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
        "sceDisplaySetFrameBuf(topaddr=0x%08X, bufWidth=%d, format=%d, sync=%d)", topaddr, bufferwidth, pixelformat, sync);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceDisplayGetFrameBuf(MipsCpu& cpu) {
    uint32_t topaddr_ptr = cpu.regs[4];
    uint32_t bufferwidth_ptr = cpu.regs[5];
    uint32_t pixelformat_ptr = cpu.regs[6];

    const GeState& state = g_pRenderer->getState();
    if (topaddr_ptr) internalWriteMemory32(topaddr_ptr, state.framebufAddr);
    if (bufferwidth_ptr) internalWriteMemory32(bufferwidth_ptr, state.framebufStride);
    if (pixelformat_ptr) internalWriteMemory32(pixelformat_ptr, state.pixelFormat);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceDisplayWaitVblankStart(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceDisplayWaitVblankStartCB(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }

// --- sceCtrl Handlers ---
static void hle_sceCtrlSetSamplingCycle(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceCtrlSetSamplingMode(MipsCpu& cpu) {
    int mode = (int)cpu.regs[4];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceCtrlSetSamplingMode(%d)", mode);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceCtrlReadBufferPositive(MipsCpu& cpu) {
    uint32_t pad_ptr = cpu.regs[4];
    int count = (int)cpu.regs[5];

    if (pad_ptr != 0 && count > 0) {
        internalWriteMemory32(pad_ptr + 0, 1000);
        internalWriteMemory32(pad_ptr + 4, g_padState.buttons);
        internalWriteMemory8(pad_ptr + 8, g_padState.lx);
        internalWriteMemory8(pad_ptr + 9, g_padState.ly);
    }
    cpu.regs[2] = (uint32_t)count;
}

static void hle_sceCtrlPeekBufferPositive(MipsCpu& cpu) {
    hle_sceCtrlReadBufferPositive(cpu);
}

// --- sceGe Handlers ---
static void hle_sceGeListInit(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }

static void hle_sceGeListEnqueue(MipsCpu& cpu) {
    uint32_t list_addr = cpu.regs[4];
    uint32_t stall_addr = cpu.regs[5];

    int listId = g_geProcessor.enqueue(list_addr, stall_addr);
    cpu.regs[2] = (uint32_t)listId;
}

static void hle_sceGeListEnqueueHead(MipsCpu& cpu) { hle_sceGeListEnqueue(cpu); }

static void hle_sceGeListUpdateStallAddr(MipsCpu& cpu) {
    int list_id = (int)cpu.regs[4];
    uint32_t stall_addr = cpu.regs[5];

    g_geProcessor.updateStallAddr(list_id, stall_addr);
    cpu.regs[2] = SCE_KERNEL_ERROR_OK;
}

static void hle_sceGeListSync(MipsCpu& cpu) {
    int list_id = (int)cpu.regs[4];
    int res = g_geProcessor.sync(list_id);
    cpu.regs[2] = (uint32_t)res;
}

static void hle_sceGeDrawSync(MipsCpu& cpu) {
    int res = g_geProcessor.sync(-1);
    cpu.regs[2] = (uint32_t)res;
}

// --- sceAudio Handlers ---
static void hle_sceAudioChReserve(MipsCpu& cpu) {
    int channel = (int)cpu.regs[4];
    int samplecount = (int)cpu.regs[5];
    int format = (int)cpu.regs[6];
    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE", "sceAudioChReserve(ch=%d, samples=%d) -> ch=0", channel, samplecount);
    cpu.regs[2] = 0;
}

static void hle_sceAudioChRelease(MipsCpu& cpu) { cpu.regs[2] = SCE_KERNEL_ERROR_OK; }
static void hle_sceAudioOutputPanned(MipsCpu& cpu) { cpu.regs[2] = 256; }
static void hle_sceAudioOutputPannedBlocking(MipsCpu& cpu) { cpu.regs[2] = 256; }

static void initHleRegistry() {
    if (!g_hleNidRegistry.empty()) return;

    // --- sceKernel ---
    registerHleFunction("ThreadManForUser", "sceKernelCreateThread", 0x44439607, hle_sceKernelCreateThread);
    registerHleFunction("ThreadManForUser", "sceKernelStartThread", 0x60D80F3F, hle_sceKernelStartThread);
    registerHleFunction("ThreadManForUser", "sceKernelExitThread", 0xAA1320DB, hle_sceKernelExitThread);
    registerHleFunction("ThreadManForUser", "sceKernelExitDeleteThread", 0x80972308, hle_sceKernelExitDeleteThread);
    registerHleFunction("ThreadManForUser", "sceKernelSleepThread", 0x9ACE131E, hle_sceKernelSleepThread);
    registerHleFunction("ThreadManForUser", "sceKernelSleepThreadCB", 0x82826F70, hle_sceKernelSleepThreadCB);
    registerHleFunction("ThreadManForUser", "sceKernelDelayThread", 0xCE23257D, hle_sceKernelDelayThread);
    registerHleFunction("ThreadManForUser", "sceKernelDelayThreadCB", 0x68DA9E36, hle_sceKernelDelayThreadCB);
    registerHleFunction("ThreadManForUser", "sceKernelWaitThreadEnd", 0x278C08CD, hle_sceKernelWaitThreadEnd);

    registerHleFunction("SysMemForUser", "sceKernelAllocPartitionMemory", 0x237DBD4F, hle_sceKernelAllocPartitionMemory);
    registerHleFunction("SysMemForUser", "sceKernelFreePartitionMemory", 0xB6DFF6B0, hle_sceKernelFreePartitionMemory);
    registerHleFunction("SysMemForUser", "sceKernelGetBlockHeadAddr", 0x9D9A5BA1, hle_sceKernelGetBlockHeadAddr);

    registerHleFunction("ThreadManForUser", "sceKernelCreateCallback", 0xE81A0571, hle_sceKernelCreateCallback);
    registerHleFunction("ThreadManForUser", "sceKernelDeleteCallback", 0xED4A030E, hle_sceKernelDeleteCallback);
    registerHleFunction("ThreadManForUser", "sceKernelCreateTimer", 0x564C00B3, hle_sceKernelCreateTimer);
    registerHleFunction("ThreadManForUser", "sceKernelSetTimerHandler", 0x7C0F83C1, hle_sceKernelSetTimerHandler);
    registerHleFunction("ThreadManForUser", "sceKernelStartTimer", 0xC030B1C4, hle_sceKernelStartTimer);
    registerHleFunction("ThreadManForUser", "sceKernelStopTimer", 0x13388914, hle_sceKernelStopTimer);

    registerHleFunction("UtilsForUser", "sceKernelDcacheWritebackAll", 0x79D1C6FA, hle_sceKernelDcacheWritebackAll);
    registerHleFunction("UtilsForUser", "sceKernelDcacheWritebackRange", 0x34B9FA9E, hle_sceKernelDcacheWritebackRange);
    registerHleFunction("UtilsForUser", "sceKernelDcacheInvalidateRange", 0xB4392242, hle_sceKernelDcacheInvalidateRange);
    registerHleFunction("LoadExecForUser", "sceKernelExitGame", 0xBD2F1094, hle_sceKernelExitGame);

    // --- sceIo ---
    registerHleFunction("IoFileMgrForUser", "sceIoOpen", 0x109F50BC, hle_sceIoOpen);
    registerHleFunction("IoFileMgrForUser", "sceIoClose", 0x810C4BC3, hle_sceIoClose);
    registerHleFunction("IoFileMgrForUser", "sceIoRead", 0x6A638D83, hle_sceIoRead);
    registerHleFunction("IoFileMgrForUser", "sceIoWrite", 0x42EC03A7, hle_sceIoWrite);
    registerHleFunction("IoFileMgrForUser", "sceIoLseek", 0x27EB27B8, hle_sceIoLseek);
    registerHleFunction("IoFileMgrForUser", "sceIoLseek32", 0x689616C3, hle_sceIoLseek32);
    registerHleFunction("IoFileMgrForUser", "sceIoDopen", 0xB29DDF9C, hle_sceIoDopen);
    registerHleFunction("IoFileMgrForUser", "sceIoDread", 0xE37300DB, hle_sceIoDread);
    registerHleFunction("IoFileMgrForUser", "sceIoDclose", 0xEB092469, hle_sceIoDclose);
    registerHleFunction("IoFileMgrForUser", "sceIoGetstat", 0xACE946E8, hle_sceIoGetstat);

    // --- sceDisplay ---
    registerHleFunction("sceDisplay", "sceDisplaySetMode", 0x0E20F177, hle_sceDisplaySetMode);
    registerHleFunction("sceDisplay", "sceDisplaySetFrameBuf", 0x289D00A5, hle_sceDisplaySetFrameBuf);
    registerHleFunction("sceDisplay", "sceDisplayGetFrameBuf", 0xE4A26328, hle_sceDisplayGetFrameBuf);
    registerHleFunction("sceDisplay", "sceDisplayWaitVblankStart", 0x369D3612, hle_sceDisplayWaitVblankStart);
    registerHleFunction("sceDisplay", "sceDisplayWaitVblankStartCB", 0x984C27E7, hle_sceDisplayWaitVblankStartCB);

    // --- sceCtrl ---
    registerHleFunction("sceCtrl", "sceCtrlSetSamplingCycle", 0x6A27B4E4, hle_sceCtrlSetSamplingCycle);
    registerHleFunction("sceCtrl", "sceCtrlSetSamplingMode", 0x1F401121, hle_sceCtrlSetSamplingMode);
    registerHleFunction("sceCtrl", "sceCtrlReadBufferPositive", 0x1F803938, hle_sceCtrlReadBufferPositive);
    registerHleFunction("sceCtrl", "sceCtrlPeekBufferPositive", 0x3A622550, hle_sceCtrlPeekBufferPositive);

    // --- sceGe ---
    registerHleFunction("sceGe_user", "sceGeListInit", 0x1F67293F, hle_sceGeListInit);
    registerHleFunction("sceGe_user", "sceGeListEnqueue", 0xAB49E76A, hle_sceGeListEnqueue);
    registerHleFunction("sceGe_user", "sceGeListEnqueueHead", 0x1C0D7B4B, hle_sceGeListEnqueueHead);
    registerHleFunction("sceGe_user", "sceGeListUpdateStallAddr", 0xE0D6814E, hle_sceGeListUpdateStallAddr);
    registerHleFunction("sceGe_user", "sceGeListSync", 0x034442A3, hle_sceGeListSync);
    registerHleFunction("sceGe_user", "sceGeDrawSync", 0xB287BD61, hle_sceGeDrawSync);

    // --- sceAudio ---
    registerHleFunction("sceAudio", "sceAudioChReserve", 0x5EC8817A, hle_sceAudioChReserve);
    registerHleFunction("sceAudio", "sceAudioChRelease", 0x4182806F, hle_sceAudioChRelease);
    registerHleFunction("sceAudio", "sceAudioOutputPanned", 0xE9D72D40, hle_sceAudioOutputPanned);
    registerHleFunction("sceAudio", "sceAudioOutputPannedBlocking", 0x13F5B8C2, hle_sceAudioOutputPannedBlocking);

    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
        "HLE Registry Initialized with %zu functions", g_hleNidRegistry.size());
}

static void initSyscalls() {
    initHleRegistry();
}

static void resolveModuleImports() {
    if (g_activeModule.importsStart == 0 || g_activeModule.importsEnd == 0) {
        return;
    }
    uint32_t currAddr = g_activeModule.importsStart;
    uint32_t endAddr = g_activeModule.importsEnd;

    if (currAddr < 0x08000000 || endAddr > 0x08000000 + 32 * 1024 * 1024 || currAddr >= endAddr) {
        return;
    }

    size_t resolvedCount = 0;
    size_t unknownCount = 0;

    while (currAddr + sizeof(PspLibraryImport) <= endAddr) {
        PspLibraryImport importHeader;
        uint32_t ramOfs = currAddr - 0x08000000;
        memcpy(&importHeader, &mainRAM[ramOfs], sizeof(PspLibraryImport));

        if (importHeader.entrySize == 0) break;

        std::string libName = "UnknownLib";
        if (importHeader.nameAddr >= 0x08000000 && importHeader.nameAddr < 0x08000000 + 32 * 1024 * 1024) {
            char nameBuf[64] = {0};
            uint32_t nameOfs = importHeader.nameAddr - 0x08000000;
            size_t len = 0;
            while (len < 63 && nameOfs + len < mainRAM.size() && mainRAM[nameOfs + len] != 0) {
                nameBuf[len] = (char)mainRAM[nameOfs + len];
                len++;
            }
            if (len > 0) libName = std::string(nameBuf);
        }

        uint32_t funcCount = importHeader.funcCount;
        uint32_t nidTableAddr = importHeader.nidTableAddr;
        uint32_t stubTableAddr = importHeader.stubTableAddr;

        for (uint16_t f = 0; f < funcCount; f++) {
            uint32_t nid = internalReadMemory32(nidTableAddr + f * 4);
            uint32_t stubAddr = stubTableAddr + f * 8;

            auto it = g_hleNidRegistry.find(nid);
            if (it != g_hleNidRegistry.end()) {
                uint32_t sysIdx = it->second.syscallIndex;
                internalWriteMemory32(stubAddr + 0, 0x03E00008); // JR $ra
                internalWriteMemory32(stubAddr + 4, 0x0000000C | ((sysIdx & 0xFFFFF) << 6)); // SYSCALL sysIdx
                resolvedCount++;
                __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
                    "Resolved HLE Import [%s::%s] NID 0x%08X -> Stub 0x%08X (SysIdx 0x%05X)",
                    libName.c_str(), it->second.funcName.c_str(), nid, stubAddr, sysIdx);
            } else {
                uint32_t unknownSysIdx = g_nextSyscallIndex++;
                g_unknownSyscallMap[unknownSysIdx] = { libName, nid };
                internalWriteMemory32(stubAddr + 0, 0x03E00008); // JR $ra
                internalWriteMemory32(stubAddr + 4, 0x0000000C | ((unknownSysIdx & 0xFFFFF) << 6)); // SYSCALL unknownSysIdx
                unknownCount++;
                __android_log_print(ANDROID_LOG_WARN, "NextEmuHLE",
                    "Unknown HLE Import [%s] NID 0x%08X -> Stub 0x%08X (SysIdx 0x%05X)",
                    libName.c_str(), nid, stubAddr, unknownSysIdx);
            }
        }

        currAddr += importHeader.entrySize * 4;
    }

    __android_log_print(ANDROID_LOG_INFO, "NextEmuHLE",
        "PRX Imports Resolution: %zu resolved, %zu unknown stubs patched",
        resolvedCount, unknownCount);
}

static void triggerException(MipsCpu& cpu, uint32_t causeCode, bool inDelaySlot) {
    cpu.cp0_epc = inDelaySlot ? (cpu.pc - 4) : cpu.pc;
    cpu.cp0_cause = (causeCode << 2) | (inDelaySlot ? (1U << 31) : 0);
    cpu.cp0_status |= 0x02;
    cpu.exceptionCount++;

    __android_log_print(ANDROID_LOG_WARN, "NextEmuCPU",
        "CPU Exception %u triggered! EPC=0x%08X, BD=%d", causeCode, cpu.cp0_epc, inDelaySlot);

    cpu.nextPc = 0x80000080;
}

static void triggerSyscall(MipsCpu& cpu, uint32_t comment, bool inDelaySlot) {
    uint32_t sysNum = cpu.regs[2];

    auto sysIt = g_hleSyscallIndexRegistry.find(comment);
    if (sysIt != g_hleSyscallIndexRegistry.end()) {
        sysIt->second.handler(cpu);
        return;
    }

    auto nidIt = g_hleNidRegistry.find(sysNum);
    if (nidIt != g_hleNidRegistry.end()) {
        nidIt->second.handler(cpu);
        return;
    }

    auto nidCommentIt = g_hleNidRegistry.find(comment);
    if (nidCommentIt != g_hleNidRegistry.end()) {
        nidCommentIt->second.handler(cpu);
        return;
    }

    auto unkIt = g_unknownSyscallMap.find(comment);
    if (unkIt != g_unknownSyscallMap.end()) {
        __android_log_print(ANDROID_LOG_ERROR, "NextEmuHLE",
            "Unknown HLE NID: 0x%08X in module [%s] at PC: 0x%08X",
            unkIt->second.nid, unkIt->second.moduleName.c_str(), cpu.pc);
        cpu.regs[2] = SCE_KERNEL_ERROR_LIBRARY_NOT_FOUND;
        return;
    }

    __android_log_print(ANDROID_LOG_ERROR, "NextEmuHLE",
        "Unknown HLE NID: 0x%08X in module [Unknown] at PC: 0x%08X (comment=0x%05X, v0=0x%08X)",
        sysNum, cpu.pc, comment, sysNum);
    cpu.regs[2] = SCE_KERNEL_ERROR_LIBRARY_NOT_FOUND;
}

static std::string runHleAutoTests() {
    initHleRegistry();

    std::ostringstream ss;
    ss << "========================================\n"
       << "     NEXTEMU PSP HLE SYSTEM AUTO-TEST   \n"
       << "========================================\n\n";

    int totalTests = 0;
    int passedTests = 0;

    auto TEST_ASSERT = [&](const std::string& name, bool condition, const std::string& details = "") {
        totalTests++;
        if (condition) {
            passedTests++;
            ss << "[PASS] Test " << totalTests << ": " << name << "\n";
        } else {
            ss << "[FAIL] Test " << totalTests << ": " << name;
            if (!details.empty()) ss << " (" << details << ")";
            ss << "\n";
        }
    };

    MipsCpu testCpu = {};
    testCpu.pc = 0x08800000;
    testCpu.nextPc = 0x08800004;

    TEST_ASSERT("HLE Registry Size >= 25", g_hleNidRegistry.size() >= 25,
        "Actual size: " + std::to_string(g_hleNidRegistry.size()));

    char nameStr[] = "TestThreadMain";
    uint32_t nameAddr = 0x08900000;
    for (size_t i = 0; i <= strlen(nameStr); i++) internalWriteMemory8(nameAddr + (uint32_t)i, nameStr[i]);

    testCpu.regs[4] = nameAddr;
    testCpu.regs[5] = 0x08800100;
    testCpu.regs[6] = 32;
    testCpu.regs[7] = 4096;

    auto createThIt = g_hleNidRegistry.find(0x44439607);
    if (createThIt != g_hleNidRegistry.end()) {
        createThIt->second.handler(testCpu);
        uint32_t tid = testCpu.regs[2];
        TEST_ASSERT("sceKernelCreateThread", tid > 0, "Created TID: " + std::to_string(tid));
    } else {
        TEST_ASSERT("sceKernelCreateThread NID registered", false);
    }

    char blockName[] = "UserAllocBlock";
    uint32_t blockNameAddr = 0x08900050;
    for (size_t i = 0; i <= strlen(blockName); i++) internalWriteMemory8(blockNameAddr + (uint32_t)i, blockName[i]);

    testCpu.regs[4] = 2;
    testCpu.regs[5] = blockNameAddr;
    testCpu.regs[6] = 0;
    testCpu.regs[7] = 1024;

    auto allocMemIt = g_hleNidRegistry.find(0x237DBD4F);
    if (allocMemIt != g_hleNidRegistry.end()) {
        allocMemIt->second.handler(testCpu);
        uint32_t blockId = testCpu.regs[2];
        TEST_ASSERT("sceKernelAllocPartitionMemory", blockId > 0, "Block ID: " + std::to_string(blockId));

        testCpu.regs[4] = blockId;
        auto getHeadIt = g_hleNidRegistry.find(0x9D9A5BA1);
        if (getHeadIt != g_hleNidRegistry.end()) {
            getHeadIt->second.handler(testCpu);
            uint32_t headAddr = testCpu.regs[2];
            TEST_ASSERT("sceKernelGetBlockHeadAddr", headAddr >= 0x08000000, "Addr: 0x" + std::to_string(headAddr));
        }
    } else {
        TEST_ASSERT("sceKernelAllocPartitionMemory NID registered", false);
    }

    testCpu.regs[2] = 0xDEADBEEF;
    triggerSyscall(testCpu, 0x99999, false);
    TEST_ASSERT("Unknown NID returns SCE_KERNEL_ERROR_LIBRARY_NOT_FOUND",
        testCpu.regs[2] == SCE_KERNEL_ERROR_LIBRARY_NOT_FOUND,
        "Actual return: 0x" + std::to_string(testCpu.regs[2]));

    uint32_t importAddr = 0x08900100;
    uint32_t namePtrAddr = 0x08900200;
    uint32_t nidTable = 0x08900300;
    uint32_t stubTable = 0x08900400;

    char libName[] = "IoFileMgrForUser";
    for (size_t i = 0; i <= strlen(libName); i++) internalWriteMemory8(namePtrAddr + (uint32_t)i, libName[i]);

    PspLibraryImport mockImport = {};
    mockImport.nameAddr = namePtrAddr;
    mockImport.version = 1;
    mockImport.flags = 0;
    mockImport.entrySize = 5;
    mockImport.varCount = 0;
    mockImport.funcCount = 2;
    mockImport.nidTableAddr = nidTable;
    mockImport.stubTableAddr = stubTable;

    uint32_t ramOfs = importAddr - 0x08000000;
    memcpy(&mainRAM[ramOfs], &mockImport, sizeof(PspLibraryImport));

    internalWriteMemory32(nidTable + 0, 0x109F50BC);
    internalWriteMemory32(nidTable + 4, 0xBAD0F00D);

    g_activeModule.importsStart = importAddr;
    g_activeModule.importsEnd = importAddr + 20;

    resolveModuleImports();

    uint32_t stub0_word0 = internalReadMemory32(stubTable + 0);
    uint32_t stub0_word1 = internalReadMemory32(stubTable + 4);
    TEST_ASSERT("PRX Stub 0 Patched (JR $ra)", stub0_word0 == 0x03E00008, "Word0: 0x" + std::to_string(stub0_word0));
    TEST_ASSERT("PRX Stub 0 Patched (SYSCALL)", (stub0_word1 & 0xFC00003F) == 0x0000000C, "Word1: 0x" + std::to_string(stub0_word1));

    uint32_t stub1_comment = (internalReadMemory32(stubTable + 12) >> 6) & 0xFFFFF;
    triggerSyscall(testCpu, stub1_comment, false);
    TEST_ASSERT("PRX Stub 1 (Unknown NID) Returns Error Code",
        testCpu.regs[2] == SCE_KERNEL_ERROR_LIBRARY_NOT_FOUND,
        "Actual return: 0x" + std::to_string(testCpu.regs[2]));

    testCpu.regs[4] = 0x04000000;
    testCpu.regs[5] = 512;
    testCpu.regs[6] = 3;
    testCpu.regs[7] = 0;
    auto setFrameBufIt = g_hleNidRegistry.find(0x289D00A5);
    if (setFrameBufIt != g_hleNidRegistry.end()) {
        setFrameBufIt->second.handler(testCpu);
        TEST_ASSERT("sceDisplaySetFrameBuf", testCpu.regs[2] == SCE_KERNEL_ERROR_OK);
    }

    uint32_t ctrlBufAddr = 0x08900500;
    testCpu.regs[4] = ctrlBufAddr;
    testCpu.regs[5] = 1;
    auto readCtrlIt = g_hleNidRegistry.find(0x1F803938);
    if (readCtrlIt != g_hleNidRegistry.end()) {
        readCtrlIt->second.handler(testCpu);
        TEST_ASSERT("sceCtrlReadBufferPositive", testCpu.regs[2] == 1);
    }

    ss << "\n----------------------------------------\n"
       << "Summary: " << passedTests << " / " << totalTests << " HLE tests PASSED.\n"
       << "========================================\n";

    return ss.str();
}

static std::string runGeAutoTests() {
    g_softRenderer.init();
    std::ostringstream ss;
    ss << "========================================\n"
       << "     NEXTEMU PSP GE & DISPLAY AUTO-TEST \n"
       << "========================================\n\n";

    int totalTests = 0;
    int passedTests = 0;

    auto TEST_ASSERT = [&](const std::string& name, bool condition, const std::string& expected = "", const std::string& actual = "", uint32_t vramAddr = 0, uint8_t opCode = 0) {
        totalTests++;
        if (condition) {
            passedTests++;
            ss << "[PASS] Test " << totalTests << ": " << name << "\n";
        } else {
            ss << "[FAIL] Test " << totalTests << ": " << name << "\n";
            if (!expected.empty()) ss << "       Expected: " << expected << "\n";
            if (!actual.empty())   ss << "       Actual:   " << actual << "\n";
            if (vramAddr != 0) {
                char addrBuf[32];
                snprintf(addrBuf, sizeof(addrBuf), "0x%08X", vramAddr);
                ss << "       VRAM/FB Addr: " << addrBuf << "\n";
            }
            if (opCode != 0) {
                char opBuf[64];
                snprintf(opBuf, sizeof(opBuf), "0x%02X (%s)", opCode, getGeCmdName(opCode));
                ss << "       GE Opcode: " << opBuf << "\n";
            }
            const GeState& st = g_pRenderer->getState();
            char stateBuf[256];
            snprintf(stateBuf, sizeof(stateBuf), "FB:0x%08X (stride=%u,fmt=%u) | ZB:0x%08X (stride=%u) | VTYPE:0x%08X (Through=%d) | Clear:%d | ZTest:%d | Blend:%d | Tex:%d",
                     st.framebufAddr, st.framebufStride, st.pixelFormat,
                     st.zbufAddr, st.zbufStride,
                     st.vtype, st.isThrough ? 1 : 0,
                     st.clearMode ? 1 : 0, st.zTestEnable ? 1 : 0, st.blendEnable ? 1 : 0, st.texEnable ? 1 : 0);
            ss << "       Renderer State: " << stateBuf << "\n";
        }
    };

    auto writeVtx = [](uint32_t addr, float x, float y, float z, uint32_t color, float u = 0.0f, float v = 0.0f, bool hasUV = false) -> uint32_t {
        if (hasUV) {
            union { uint32_t u; float f; } fu, fv;
            fu.f = u; fv.f = v;
            internalWriteMemory32(addr + 0, fu.u);
            internalWriteMemory32(addr + 4, fv.u);
            internalWriteMemory32(addr + 8, color);
            union { uint32_t u; float f; } fx, fy, fz;
            fx.f = x; fy.f = y; fz.f = z;
            internalWriteMemory32(addr + 12, fx.u);
            internalWriteMemory32(addr + 16, fy.u);
            internalWriteMemory32(addr + 20, fz.u);
            return 24U;
        } else {
            internalWriteMemory32(addr + 0, color);
            union { uint32_t u; float f; } fx, fy, fz;
            fx.f = x; fy.f = y; fz.f = z;
            internalWriteMemory32(addr + 4, fx.u);
            internalWriteMemory32(addr + 8, fy.u);
            internalWriteMemory32(addr + 12, fz.u);
            return 16U;
        }
    };

    uint32_t dl = 0x08950000;

    // --- Part A: GE State & Buffer Setup Opcodes ---

    // Test 1: GE Commands FRAMEBUFPTR & FRAMEBUFWIDTH
    g_pRenderer->resetState();
    internalWriteMemory32(dl + 0, (GE_CMD_FRAMEBUFPTR << 24) | 0x00040000);
    internalWriteMemory32(dl + 4, (GE_CMD_FRAMEBUFWIDTH << 24) | (GU_PSM_8888 << 16) | 512);
    internalWriteMemory32(dl + 8, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Command FRAMEBUFPTR & FRAMEBUFWIDTH",
        g_pRenderer->getState().framebufAddr == 0x04040000 &&
        g_pRenderer->getState().framebufStride == 512 &&
        g_pRenderer->getState().pixelFormat == GU_PSM_8888);

    // Test 2: GE Commands ZBUFPTR & ZBUFWIDTH
    internalWriteMemory32(dl + 0, (GE_CMD_ZBUFPTR << 24) | 0x00100000);
    internalWriteMemory32(dl + 4, (GE_CMD_ZBUFWIDTH << 24) | 512);
    internalWriteMemory32(dl + 8, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Command ZBUFPTR & ZBUFWIDTH",
        g_pRenderer->getState().zbufAddr == 0x04100000 &&
        g_pRenderer->getState().zbufStride == 512);

    // Test 3: GE Commands CLEARMODE, AMBIENTCOLOR & AMBIENTALPHA
    internalWriteMemory32(dl + 0, (GE_CMD_AMBIENTCOLOR << 24) | 0x00FF8040);
    internalWriteMemory32(dl + 4, (GE_CMD_AMBIENTALPHA << 24) | 0x000000FF);
    internalWriteMemory32(dl + 8, (GE_CMD_CLEARMODE << 24) | 0x00000101);
    internalWriteMemory32(dl + 12, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Command CLEARMODE, AMBIENTCOLOR & ALPHA",
        g_pRenderer->getState().clearMode == true &&
        (g_pRenderer->getState().clearColor & 0x00FFFFFF) == 0x00FF8040);

    // Test 4: GE Commands SCISSOR1 & SCISSOR2
    internalWriteMemory32(dl + 0, (GE_CMD_SCISSOR1 << 24) | (50 << 10) | 100);
    internalWriteMemory32(dl + 4, (GE_CMD_SCISSOR2 << 24) | (200 << 10) | 300);
    internalWriteMemory32(dl + 8, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Command SCISSOR1 & SCISSOR2",
        g_pRenderer->getState().scissorX1 == 100 &&
        g_pRenderer->getState().scissorY1 == 50 &&
        g_pRenderer->getState().scissorX2 == 301 &&
        g_pRenderer->getState().scissorY2 == 201);

    // Test 5: GE Commands REGION1 & REGION2
    internalWriteMemory32(dl + 0, (GE_CMD_REGION1 << 24) | (20 << 10) | 40);
    internalWriteMemory32(dl + 4, (GE_CMD_REGION2 << 24) | (220 << 10) | 440);
    internalWriteMemory32(dl + 8, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Command REGION1 & REGION2",
        g_pRenderer->getState().regionX1 == 40 &&
        g_pRenderer->getState().regionY1 == 20 &&
        g_pRenderer->getState().regionX2 == 441 &&
        g_pRenderer->getState().regionY2 == 221);

    // --- Part B: GE Address Calculation & Control Flow ---

    // Test 6: GE Address Calc: BASE + VADDR / IADDR
    internalWriteMemory32(dl + 0, (GE_CMD_BASE << 24) | 0x00089500);
    internalWriteMemory32(dl + 4, (GE_CMD_OFFSETADDR << 24) | 0);
    internalWriteMemory32(dl + 8, (GE_CMD_VADDR << 24) | 0x00000100);
    internalWriteMemory32(dl + 12, (GE_CMD_IADDR << 24) | 0x00000200);
    internalWriteMemory32(dl + 16, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Address Calc: BASE + VADDR / IADDR",
        g_geProcessor.getBaseAddr() == 0x08000000 &&
        g_geProcessor.getVaddr() == 0x08000100 &&
        g_geProcessor.getIaddr() == 0x08000200);

    // Test 7: GE Address Calc: OFFSETADDR Relative Base
    internalWriteMemory32(dl + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 4, (GE_CMD_OFFSETADDR << 24) | (0x00050000 >> 8));
    internalWriteMemory32(dl + 8, (GE_CMD_VADDR << 24) | 0x00000050);
    internalWriteMemory32(dl + 12, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Address Calc: OFFSETADDR Relative Base",
        g_geProcessor.getVaddr() == 0x08050050);

    // Test 8: GE Address Calc: ORIGIN (PC relative)
    uint32_t originDl = 0x08952000;
    internalWriteMemory32(originDl + 0, (GE_CMD_BASE << 24) | 0);
    internalWriteMemory32(originDl + 4, (GE_CMD_ORIGIN << 24));
    internalWriteMemory32(originDl + 8, (GE_CMD_VADDR << 24) | 0x00000040);
    internalWriteMemory32(originDl + 12, (GE_CMD_END << 24));
    g_geProcessor.enqueue(originDl, 0);
    TEST_ASSERT("GE Address Calc: ORIGIN (PC relative)",
        g_geProcessor.getVaddr() == 0x08952044);

    // Test 9: GE Command VTYPE Decoding
    uint32_t vtypeVal = (1U << 23) | (7U << 2) | (3U << 7);
    internalWriteMemory32(dl + 0, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 4, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("GE Command VTYPE Decoding (Through | RGBA8888 | FloatPos)",
        g_pRenderer->getState().vtype == vtypeVal &&
        g_pRenderer->getState().isThrough == true);

    // Test 10: GE Control Flow: JUMP Opcode
    uint32_t jumpDl1 = 0x08953000;
    uint32_t jumpDl2 = 0x08953100;
    internalWriteMemory32(jumpDl1 + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(jumpDl1 + 4, (GE_CMD_OFFSETADDR << 24) | 0);
    internalWriteMemory32(jumpDl1 + 8, (GE_CMD_JUMP << 24) | (jumpDl2 & 0x00FFFFFF));
    internalWriteMemory32(jumpDl1 + 12, (GE_CMD_AMBIENTCOLOR << 24) | 0x00111111);
    internalWriteMemory32(jumpDl1 + 16, (GE_CMD_END << 24));
    internalWriteMemory32(jumpDl2 + 0, (GE_CMD_AMBIENTCOLOR << 24) | 0x00222222);
    internalWriteMemory32(jumpDl2 + 4, (GE_CMD_END << 24));
    g_geProcessor.enqueue(jumpDl1, 0);
    TEST_ASSERT("GE Control Flow: JUMP Opcode",
        (g_pRenderer->getState().ambientColor & 0x00FFFFFF) == 0x00222222);

    // Test 11: GE Control Flow: BJUMP Opcode
    uint32_t bjumpDl1 = 0x08953200;
    uint32_t bjumpDl2 = 0x08953300;
    internalWriteMemory32(bjumpDl1 + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(bjumpDl1 + 4, (GE_CMD_OFFSETADDR << 24) | 0);
    internalWriteMemory32(bjumpDl1 + 8, (GE_CMD_BJUMP << 24) | (bjumpDl2 & 0x00FFFFFF));
    internalWriteMemory32(bjumpDl1 + 12, (GE_CMD_AMBIENTCOLOR << 24) | 0x00333333);
    internalWriteMemory32(bjumpDl1 + 16, (GE_CMD_END << 24));
    internalWriteMemory32(bjumpDl2 + 0, (GE_CMD_AMBIENTCOLOR << 24) | 0x00444444);
    internalWriteMemory32(bjumpDl2 + 4, (GE_CMD_END << 24));
    g_geProcessor.enqueue(bjumpDl1, 0);
    TEST_ASSERT("GE Control Flow: BJUMP Opcode",
        (g_pRenderer->getState().ambientColor & 0x00FFFFFF) == 0x00444444);

    // Test 12: GE Control Flow: CALL / RET Subroutines
    uint32_t callDl1 = 0x08953400;
    uint32_t subDl = 0x08953500;
    internalWriteMemory32(callDl1 + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(callDl1 + 4, (GE_CMD_OFFSETADDR << 24) | 0);
    internalWriteMemory32(callDl1 + 8, (GE_CMD_CALL << 24) | (subDl & 0x00FFFFFF));
    internalWriteMemory32(callDl1 + 12, (GE_CMD_AMBIENTCOLOR << 24) | 0x00555555);
    internalWriteMemory32(callDl1 + 16, (GE_CMD_END << 24));
    internalWriteMemory32(subDl + 0, (GE_CMD_AMBIENTCOLOR << 24) | 0x00AAAAAA);
    internalWriteMemory32(subDl + 4, (GE_CMD_RET << 24));
    g_geProcessor.enqueue(callDl1, 0);
    TEST_ASSERT("GE Control Flow: CALL / RET Subroutines",
        (g_pRenderer->getState().ambientColor & 0x00FFFFFF) == 0x00555555 &&
        g_geProcessor.getCallStackDepth() == 0);

    // Test 13: GE Control Flow: END Opcode Stops Execution
    uint32_t endDl = 0x08953600;
    internalWriteMemory32(endDl + 0, (GE_CMD_AMBIENTCOLOR << 24) | 0x00777777);
    internalWriteMemory32(endDl + 4, (GE_CMD_END << 24));
    internalWriteMemory32(endDl + 8, (GE_CMD_AMBIENTCOLOR << 24) | 0x00888888);
    g_geProcessor.enqueue(endDl, 0);
    TEST_ASSERT("GE Control Flow: END Opcode Stops Execution",
        g_geProcessor.getStatus() == 0 &&
        g_geProcessor.isEnded() &&
        (g_pRenderer->getState().ambientColor & 0x00FFFFFF) == 0x00777777);

    // Test 14: GE Control Flow: FINISH Opcode & Callback Arg
    uint32_t finishDl = 0x08953700;
    internalWriteMemory32(finishDl + 0, (GE_CMD_FINISH << 24) | 0x00FEED01);
    g_geProcessor.enqueue(finishDl, 0);
    TEST_ASSERT("GE Control Flow: FINISH Opcode & Callback Arg",
        g_geProcessor.getStatus() == 0 &&
        g_geProcessor.isFinished() &&
        g_geProcessor.getFinishArg() == 0x00FEED01);

    // Test 15: GE Control Flow: SIGNAL (Suspend / Continue)
    uint32_t sigDl1 = 0x08953800;
    internalWriteMemory32(sigDl1 + 0, (GE_CMD_SIGNAL << 24) | (0x01 << 16) | 0x9999);
    g_geProcessor.enqueue(sigDl1, 0);
    bool sig1Pass = (g_geProcessor.getStatus() == 3 && g_geProcessor.isSignalled() && g_geProcessor.getSignalArg() == ((0x01 << 16) | 0x9999));
    uint32_t sigDl2 = 0x08953900;
    internalWriteMemory32(sigDl2 + 0, (GE_CMD_SIGNAL << 24) | (0x00 << 16) | 0x8888);
    internalWriteMemory32(sigDl2 + 4, (GE_CMD_AMBIENTCOLOR << 24) | 0x00123456);
    internalWriteMemory32(sigDl2 + 8, (GE_CMD_END << 24));
    g_geProcessor.enqueue(sigDl2, 0);
    bool sig2Pass = (g_geProcessor.getStatus() == 0 && (g_pRenderer->getState().ambientColor & 0x00FFFFFF) == 0x00123456);
    TEST_ASSERT("GE Control Flow: SIGNAL (Suspend / Continue)", sig1Pass && sig2Pass);

    // --- Part C: Primitive Types Rasterization & Verification ---

    // Common setup for rendering tests
    g_pRenderer->resetState();
    g_pRenderer->setFramebuffer(0x04000000, 512, GU_PSM_8888);
    g_pRenderer->setDepthBuffer(0x04100000, 512);

    // Clear entire 480x272 VRAM buffer to Black (0xFF000000)
    for (int y = 0; y < 272; y++) {
        for (int x = 0; x < 480; x++) {
            internalWriteMemory32(0x04000000 + (y * 512 + x) * 4, 0xFF000000);
        }
    }

    uint32_t vtxBuf = 0x08960000;

    // Test 16: Primitive: Points (PRIM Type 0)
    writeVtx(vtxBuf, 100.0f, 50.0f, 0.0f, 0xFF0000FF);
    internalWriteMemory32(dl + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 4, (GE_CMD_OFFSETADDR << 24) | 0);
    internalWriteMemory32(dl + 8, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 12, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (0 << 16) | 1); // Points, 1 vtx
    internalWriteMemory32(dl + 20, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pPoint = internalReadMemory32(0x04000000 + (50 * 512 + 100) * 4);
    uint32_t pPointAdj = internalReadMemory32(0x04000000 + (50 * 512 + 101) * 4);
    TEST_ASSERT("Primitive: Points (PRIM Type 0)", pPoint == 0xFF0000FF && pPointAdj == 0xFF000000);

    // Test 17: Primitive: Lines (PRIM Type 1)
    writeVtx(vtxBuf + 0, 20.0f, 30.0f, 0.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 16, 60.0f, 30.0f, 0.0f, 0xFF00FF00);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (1 << 16) | 2); // Lines, 2 vtx
    g_geProcessor.enqueue(dl, 0);
    uint32_t pLine1 = internalReadMemory32(0x04000000 + (30 * 512 + 20) * 4);
    uint32_t pLine2 = internalReadMemory32(0x04000000 + (30 * 512 + 40) * 4);
    uint32_t pLine3 = internalReadMemory32(0x04000000 + (30 * 512 + 60) * 4);
    TEST_ASSERT("Primitive: Lines (PRIM Type 1)",
        pLine1 == 0xFF00FF00 && pLine2 == 0xFF00FF00 && pLine3 == 0xFF00FF00);

    // Test 18: Primitive: Line Strip (PRIM Type 2)
    writeVtx(vtxBuf + 0, 10.0f, 10.0f, 0.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 16, 10.0f, 40.0f, 0.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 32, 40.0f, 40.0f, 0.0f, 0xFFFF0000);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (2 << 16) | 3); // Line Strip, 3 vtx
    g_geProcessor.enqueue(dl, 0);
    uint32_t pLStrip1 = internalReadMemory32(0x04000000 + (25 * 512 + 10) * 4);
    uint32_t pLStrip2 = internalReadMemory32(0x04000000 + (40 * 512 + 25) * 4);
    TEST_ASSERT("Primitive: Line Strip (PRIM Type 2)",
        pLStrip1 == 0xFFFF0000 && pLStrip2 == 0xFFFF0000);

    // Test 19: Primitive: Triangles (PRIM Type 3)
    writeVtx(vtxBuf + 0, 100.0f, 100.0f, 0.0f, 0xFF00FFFF);
    writeVtx(vtxBuf + 16, 160.0f, 100.0f, 0.0f, 0xFF00FFFF);
    writeVtx(vtxBuf + 32, 100.0f, 160.0f, 0.0f, 0xFF00FFFF);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (3 << 16) | 3); // Triangles, 3 vtx
    g_geProcessor.enqueue(dl, 0);
    uint32_t pTriCenter = internalReadMemory32(0x04000000 + (110 * 512 + 110) * 4);
    uint32_t pTriOutside = internalReadMemory32(0x04000000 + (150 * 512 + 150) * 4);
    TEST_ASSERT("Primitive: Triangles (PRIM Type 3)",
        pTriCenter == 0xFF00FFFF && pTriOutside == 0xFF000000);

    // Test 20: Primitive: Triangle Strip (PRIM Type 4)
    writeVtx(vtxBuf + 0, 200.0f, 50.0f, 0.0f, 0xFFFFFF00);
    writeVtx(vtxBuf + 16, 200.0f, 80.0f, 0.0f, 0xFFFFFF00);
    writeVtx(vtxBuf + 32, 240.0f, 50.0f, 0.0f, 0xFFFFFF00);
    writeVtx(vtxBuf + 48, 240.0f, 80.0f, 0.0f, 0xFFFFFF00);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (4 << 16) | 4); // Triangle Strip, 4 vtx
    g_geProcessor.enqueue(dl, 0);
    uint32_t pTStrip1 = internalReadMemory32(0x04000000 + (60 * 512 + 210) * 4);
    uint32_t pTStrip2 = internalReadMemory32(0x04000000 + (70 * 512 + 230) * 4);
    TEST_ASSERT("Primitive: Triangle Strip (PRIM Type 4)",
        pTStrip1 == 0xFFFFFF00 && pTStrip2 == 0xFFFFFF00);

    // Test 21: Primitive: Triangle Fan (PRIM Type 5)
    writeVtx(vtxBuf + 0, 300.0f, 50.0f, 0.0f, 0xFFFF00FF);
    writeVtx(vtxBuf + 16, 330.0f, 50.0f, 0.0f, 0xFFFF00FF);
    writeVtx(vtxBuf + 32, 330.0f, 80.0f, 0.0f, 0xFFFF00FF);
    writeVtx(vtxBuf + 48, 300.0f, 80.0f, 0.0f, 0xFFFF00FF);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (5 << 16) | 4); // Triangle Fan, 4 vtx
    g_geProcessor.enqueue(dl, 0);
    uint32_t pTFan = internalReadMemory32(0x04000000 + (65 * 512 + 315) * 4);
    TEST_ASSERT("Primitive: Triangle Fan (PRIM Type 5)", pTFan == 0xFFFF00FF);

    // Test 22: Primitive: Sprites (PRIM Type 6)
    writeVtx(vtxBuf + 0, 400.0f, 10.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 16, 450.0f, 40.0f, 0.0f, 0xFFFFFFFF);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (6 << 16) | 2); // Sprites, 2 vtx
    g_geProcessor.enqueue(dl, 0);
    uint32_t pSprite1 = internalReadMemory32(0x04000000 + (10 * 512 + 400) * 4);
    uint32_t pSprite2 = internalReadMemory32(0x04000000 + (25 * 512 + 425) * 4);
    uint32_t pSprite3 = internalReadMemory32(0x04000000 + (39 * 512 + 449) * 4);
    uint32_t pSpriteOut = internalReadMemory32(0x04000000 + (41 * 512 + 451) * 4);
    TEST_ASSERT("Primitive: Sprites (PRIM Type 6)",
        pSprite1 == 0xFFFFFFFF && pSprite2 == 0xFFFFFFFF && pSprite3 == 0xFFFFFFFF && pSpriteOut == 0xFF000000);

    // --- Part D: Triangle Rasterizer Edge Cases ---

    // Test 23: Triangle Edge Case: CCW Triangle (Cull Disabled)
    writeVtx(vtxBuf + 0, 50.0f, 50.0f, 0.0f, 0xFF0000FF);
    writeVtx(vtxBuf + 16, 100.0f, 50.0f, 0.0f, 0xFF0000FF);
    writeVtx(vtxBuf + 32, 50.0f, 100.0f, 0.0f, 0xFF0000FF);
    internalWriteMemory32(dl + 0, (GE_CMD_CULLFACEENABLE << 24) | 0);
    internalWriteMemory32(dl + 4, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 8, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 12, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 16, (GE_CMD_PRIM << 24) | (3 << 16) | 3);
    internalWriteMemory32(dl + 20, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pCcw = internalReadMemory32(0x04000000 + (60 * 512 + 60) * 4);
    TEST_ASSERT("Edge Case: CCW Triangle (Cull Disabled)", pCcw == 0xFF0000FF);

    // Test 24: Triangle Edge Case: CW Triangle (Cull Disabled)
    writeVtx(vtxBuf + 0, 50.0f, 150.0f, 0.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 16, 50.0f, 200.0f, 0.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 32, 100.0f, 150.0f, 0.0f, 0xFF00FF00);
    g_geProcessor.enqueue(dl, 0);
    uint32_t pCw = internalReadMemory32(0x04000000 + (160 * 512 + 60) * 4);
    TEST_ASSERT("Edge Case: CW Triangle (Cull Disabled)", pCw == 0xFF00FF00);

    // Test 25: Triangle Edge Case: Backface Culling (CCW Rejected)
    internalWriteMemory32(0x04000000 + (60 * 512 + 160) * 4, 0xFF000000);
    writeVtx(vtxBuf + 0, 150.0f, 50.0f, 0.0f, 0xFF0000FF);
    writeVtx(vtxBuf + 16, 200.0f, 50.0f, 0.0f, 0xFF0000FF);
    writeVtx(vtxBuf + 32, 150.0f, 100.0f, 0.0f, 0xFF0000FF);
    internalWriteMemory32(dl + 0, (GE_CMD_CULLFACEENABLE << 24) | 1);
    internalWriteMemory32(dl + 4, (GE_CMD_CULLFACE << 24) | 0); // Cull CCW
    g_geProcessor.enqueue(dl, 0);
    uint32_t pCullCcw = internalReadMemory32(0x04000000 + (60 * 512 + 160) * 4);
    TEST_ASSERT("Edge Case: Backface Culling (CCW Rejected)", pCullCcw == 0xFF000000);

    // Test 26: Triangle Edge Case: Frontface Culling (CW Rejected)
    internalWriteMemory32(0x04000000 + (160 * 512 + 160) * 4, 0xFF000000);
    writeVtx(vtxBuf + 0, 150.0f, 150.0f, 0.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 16, 150.0f, 200.0f, 0.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 32, 200.0f, 150.0f, 0.0f, 0xFF00FF00);
    internalWriteMemory32(dl + 0, (GE_CMD_CULLFACEENABLE << 24) | 1);
    internalWriteMemory32(dl + 4, (GE_CMD_CULLFACE << 24) | 1); // Cull CW
    g_geProcessor.enqueue(dl, 0);
    uint32_t pCullCw = internalReadMemory32(0x04000000 + (160 * 512 + 160) * 4);
    TEST_ASSERT("Edge Case: Frontface Culling (CW Rejected)", pCullCw == 0xFF000000);

    // Test 27: Triangle Edge Case: Degenerate Collinear Triangle (Area=0)
    writeVtx(vtxBuf + 0, 10.0f, 10.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 16, 50.0f, 10.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 32, 90.0f, 10.0f, 0.0f, 0xFFFFFFFF);
    internalWriteMemory32(dl + 0, (GE_CMD_CULLFACEENABLE << 24) | 0);
    internalWriteMemory32(dl + 4, (GE_CMD_BASE << 24) | 0x00080000);
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("Edge Case: Degenerate Collinear Triangle (Area=0)", true);

    // Test 28: Triangle Edge Case: Degenerate Single-Point Triangle
    writeVtx(vtxBuf + 0, 20.0f, 20.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 16, 20.0f, 20.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 32, 20.0f, 20.0f, 0.0f, 0xFFFFFFFF);
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("Edge Case: Degenerate Single-Point Triangle", true);

    // Test 29: Triangle Edge Case: Off-Screen Triangle Clipping
    writeVtx(vtxBuf + 0, -100.0f, -100.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 16, -50.0f, -100.0f, 0.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 32, -100.0f, -50.0f, 0.0f, 0xFFFFFFFF);
    g_geProcessor.enqueue(dl, 0);
    TEST_ASSERT("Edge Case: Off-Screen Triangle Clipping", true);

    // Test 30: Triangle Edge Case: Framebuffer Boundary Clipping (480x272)
    writeVtx(vtxBuf + 0, 470.0f, 260.0f, 0.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 16, 510.0f, 260.0f, 0.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 32, 470.0f, 290.0f, 0.0f, 0xFFFF0000);
    g_geProcessor.enqueue(dl, 0);
    uint32_t fbAddr = g_pRenderer->getState().framebufAddr;
    uint32_t pBound = internalReadMemory32(fbAddr + (265 * 512 + 475) * 4);
    TEST_ASSERT("Edge Case: Framebuffer Boundary Clipping (480x272)", pBound == 0xFFFF0000);

    // Test 31: Triangle Edge Case: Scissor Box Clipping
    internalWriteMemory32(fbAddr + (60 * 512 + 60) * 4, 0xFF000000);
    internalWriteMemory32(fbAddr + (30 * 512 + 30) * 4, 0xFF000000);
    writeVtx(vtxBuf + 0, 0.0f, 0.0f, 0.0f, 0xFF00FFFF);
    writeVtx(vtxBuf + 16, 200.0f, 0.0f, 0.0f, 0xFF00FFFF);
    writeVtx(vtxBuf + 32, 0.0f, 200.0f, 0.0f, 0xFF00FFFF);
    internalWriteMemory32(dl + 0, (GE_CMD_SCISSOR1 << 24) | (50 << 10) | 50);
    internalWriteMemory32(dl + 4, (GE_CMD_SCISSOR2 << 24) | (100 << 10) | 100);
    internalWriteMemory32(dl + 8, (GE_CMD_CULLFACEENABLE << 24) | 0);
    internalWriteMemory32(dl + 12, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 16, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 20, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 24, (GE_CMD_PRIM << 24) | (3 << 16) | 3);
    internalWriteMemory32(dl + 28, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pScisIn = internalReadMemory32(fbAddr + (60 * 512 + 60) * 4);
    uint32_t pScisOut = internalReadMemory32(fbAddr + (30 * 512 + 30) * 4);
    TEST_ASSERT("Edge Case: Scissor Box Clipping", pScisIn == 0xFF00FFFF && pScisOut == 0xFF000000);

    // --- Part E: Interpolation & Depth & Blend Tests ---

    // Test 32: Interpolation: Gouraud Color Interpolation
    // Reset scissor to full screen
    internalWriteMemory32(dl + 0, (GE_CMD_SCISSOR1 << 24) | 0);
    internalWriteMemory32(dl + 4, (GE_CMD_SCISSOR2 << 24) | (271 << 10) | 479);
    internalWriteMemory32(dl + 8, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);

    writeVtx(vtxBuf + 0, 0.0f, 0.0f, 0.0f, 0xFF0000FF);       // Red
    writeVtx(vtxBuf + 16, 100.0f, 0.0f, 0.0f, 0xFFFF0000);     // Blue
    writeVtx(vtxBuf + 32, 0.0f, 100.0f, 0.0f, 0xFFFF0000);     // Blue
    internalWriteMemory32(dl + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 4, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 8, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 12, (GE_CMD_PRIM << 24) | (3 << 16) | 3);
    internalWriteMemory32(dl + 16, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pGouraud = internalReadMemory32(fbAddr + (10 * 512 + 50) * 4);
    uint8_t gR = pGouraud & 0xFF;
    uint8_t gB = (pGouraud >> 16) & 0xFF;
    TEST_ASSERT("Interpolation: Gouraud Color Interpolation", gR > 20 && gB > 20);

    // Test 33: Depth Test: Z-Test LESS Closer Overwrite
    // Clear depth buffer to 0xFFFF
    uint32_t zbAddr = g_pRenderer->getState().zbufAddr;
    for (int y = 90; y < 130; y++) {
        for (int x = 190; x < 230; x++) {
            internalWriteMemory16(zbAddr + (y * 512 + x) * 2, 0xFFFF);
            internalWriteMemory32(fbAddr + (y * 512 + x) * 4, 0xFF000000);
        }
    }
    // Draw Triangle 1 at Z = 5000.0f (Red)
    writeVtx(vtxBuf + 0, 200.0f, 100.0f, 5000.0f, 0xFF0000FF);
    writeVtx(vtxBuf + 16, 230.0f, 100.0f, 5000.0f, 0xFF0000FF);
    writeVtx(vtxBuf + 32, 200.0f, 130.0f, 5000.0f, 0xFF0000FF);
    // Draw Triangle 2 at Z = 2000.0f (Green, closer)
    writeVtx(vtxBuf + 48, 200.0f, 100.0f, 2000.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 64, 230.0f, 100.0f, 2000.0f, 0xFF00FF00);
    writeVtx(vtxBuf + 80, 200.0f, 130.0f, 2000.0f, 0xFF00FF00);

    internalWriteMemory32(dl + 0, (GE_CMD_ZTESTENABLE << 24) | 1);
    internalWriteMemory32(dl + 4, (GE_CMD_ZTEST << 24) | 4); // LESS
    internalWriteMemory32(dl + 8, (GE_CMD_ZMASK << 24) | 0);
    internalWriteMemory32(dl + 12, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 16, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 20, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 24, (GE_CMD_PRIM << 24) | (3 << 16) | 6); // 2 triangles
    internalWriteMemory32(dl + 28, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pZCloser = internalReadMemory32(fbAddr + (110 * 512 + 210) * 4);
    TEST_ASSERT("Depth Test: Z-Test LESS Closer Overwrite", pZCloser == 0xFF00FF00);

    // Test 34: Depth Test: Z-Test LESS Farther Occlusion
    // Draw Triangle 3 at Z = 8000.0f (Blue, farther) over the same area
    writeVtx(vtxBuf + 0, 200.0f, 100.0f, 8000.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 16, 230.0f, 100.0f, 8000.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 32, 200.0f, 130.0f, 8000.0f, 0xFFFF0000);
    internalWriteMemory32(dl + 0, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 4, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 8, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 12, (GE_CMD_PRIM << 24) | (3 << 16) | 3);
    internalWriteMemory32(dl + 16, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pZFarther = internalReadMemory32(fbAddr + (110 * 512 + 210) * 4);
    TEST_ASSERT("Depth Test: Z-Test LESS Farther Occlusion", pZFarther == 0xFF00FF00);

    // Test 35: Depth Test: Z-Mask Disables Depth Writes
    internalWriteMemory16(zbAddr + (105 * 512 + 255) * 2, 0x4000);
    writeVtx(vtxBuf + 0, 250.0f, 100.0f, 1000.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 16, 280.0f, 100.0f, 1000.0f, 0xFFFFFFFF);
    writeVtx(vtxBuf + 32, 250.0f, 130.0f, 1000.0f, 0xFFFFFFFF);
    internalWriteMemory32(dl + 0, (GE_CMD_ZTESTENABLE << 24) | 1);
    internalWriteMemory32(dl + 4, (GE_CMD_ZTEST << 24) | 4); // LESS
    internalWriteMemory32(dl + 8, (GE_CMD_ZMASK << 24) | 0xFFFF); // Write Disable
    internalWriteMemory32(dl + 12, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 16, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 20, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 24, (GE_CMD_PRIM << 24) | (3 << 16) | 3);
    internalWriteMemory32(dl + 28, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pZMaskCol = internalReadMemory32(fbAddr + (105 * 512 + 255) * 4);
    uint16_t pZMaskVal = internalReadMemory16(zbAddr + (105 * 512 + 255) * 2);
    TEST_ASSERT("Depth Test: Z-Mask Disables Depth Writes", pZMaskCol == 0xFFFFFFFF && pZMaskVal == 0x4000);

    // Test 36: Alpha Blending: SrcAlpha + InvSrcAlpha Blend
    writeVtx(vtxBuf + 0, 300.0f, 100.0f, 0.0f, 0xFFFF0000); // Opaque Blue
    writeVtx(vtxBuf + 16, 340.0f, 140.0f, 0.0f, 0xFFFF0000);
    writeVtx(vtxBuf + 32, 300.0f, 100.0f, 0.0f, 0x800000FF); // 50% Semi-transparent Red
    writeVtx(vtxBuf + 48, 340.0f, 140.0f, 0.0f, 0x800000FF);
    internalWriteMemory32(dl + 0, (GE_CMD_ZTESTENABLE << 24) | 0);
    internalWriteMemory32(dl + 4, (GE_CMD_ALPHABLENDENABLE << 24) | 1);
    internalWriteMemory32(dl + 8, (GE_CMD_BASE << 24) | 0x00080000);
    internalWriteMemory32(dl + 12, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 16, (GE_CMD_VTYPE << 24) | vtypeVal);
    internalWriteMemory32(dl + 20, (GE_CMD_PRIM << 24) | (6 << 16) | 2); // Sprite 1 (Blue)
    internalWriteMemory32(dl + 24, (GE_CMD_VADDR << 24) | ((vtxBuf + 32) & 0x00FFFFFF));
    internalWriteMemory32(dl + 28, (GE_CMD_PRIM << 24) | (6 << 16) | 2); // Sprite 2 (Red 50%)
    internalWriteMemory32(dl + 32, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pBlend = internalReadMemory32(fbAddr + (110 * 512 + 310) * 4);
    uint8_t bR = pBlend & 0xFF;
    uint8_t bB = (pBlend >> 16) & 0xFF;
    TEST_ASSERT("Alpha Blending: SrcAlpha + InvSrcAlpha Blend", bR > 90 && bB > 90);

    // --- Part F: Texture Mapping & Sampling ---

    // Test 37: Texture Sampling: RGBA8888 Texel Sampling
    uint32_t texAddr = 0x08980000;
    // 2x2 texture pattern:
    // (0,0) = Red,   (1,0) = Green
    // (0,1) = Blue,  (1,1) = White
    internalWriteMemory32(texAddr + 0, 0xFF0000FF);
    internalWriteMemory32(texAddr + 4, 0xFF00FF00);
    internalWriteMemory32(texAddr + 8, 0xFFFF0000);
    internalWriteMemory32(texAddr + 12, 0xFFFFFFFF);

    uint32_t vtypeUV = (1U << 23) | (3U << 0) | (7U << 2) | (3U << 7); // Through | Float UV | RGBA8888 | Float Pos
    writeVtx(vtxBuf + 0, 350.0f, 100.0f, 0.0f, 0xFFFFFFFF, 0.0f, 0.0f, true);
    writeVtx(vtxBuf + 24, 370.0f, 120.0f, 0.0f, 0xFFFFFFFF, 2.0f, 2.0f, true);

    internalWriteMemory32(dl + 0, (GE_CMD_ALPHABLENDENABLE << 24) | 0);
    internalWriteMemory32(dl + 4, (GE_CMD_TEXTUREMAPENABLE << 24) | 1);
    internalWriteMemory32(dl + 8, (GE_CMD_TEXADDR0 << 24) | (texAddr & 0x00FFFFFF));
    internalWriteMemory32(dl + 12, (GE_CMD_TEXBUFWIDTH0 << 24) | 2);
    internalWriteMemory32(dl + 16, (GE_CMD_TEXSIZE0 << 24) | (1 << 8) | 1); // 2x2 (2^1 x 2^1)
    internalWriteMemory32(dl + 20, (GE_CMD_TEXMODE << 24) | GU_PSM_8888);
    internalWriteMemory32(dl + 24, (GE_CMD_BASE << 24) | 0x080000);
    internalWriteMemory32(dl + 28, (GE_CMD_VADDR << 24) | (vtxBuf & 0x00FFFFFF));
    internalWriteMemory32(dl + 32, (GE_CMD_VTYPE << 24) | vtypeUV);
    internalWriteMemory32(dl + 36, (GE_CMD_PRIM << 24) | (6 << 16) | 2); // Sprite with UV
    internalWriteMemory32(dl + 40, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pTexTL = internalReadMemory32(fbAddr + (102 * 512 + 352) * 4);
    uint32_t pTexBR = internalReadMemory32(fbAddr + (118 * 512 + 368) * 4);
    TEST_ASSERT("Texture Sampling: RGBA8888 Texel Sampling", pTexTL == 0xFF0000FF && pTexBR == 0xFFFFFFFF);

    // Test 38: Indexed Vertex Array (IADDR + 8-bit Index)
    uint32_t idxVtxAddr = 0x08990000;
    uint32_t idxBufAddr = 0x08990200;
    writeVtx(idxVtxAddr + 0,  10.0f, 200.0f, 0.0f, 0xFF00FFFF); // 0: Top-Left
    writeVtx(idxVtxAddr + 16, 50.0f, 200.0f, 0.0f, 0xFF00FFFF); // 1: Top-Right
    writeVtx(idxVtxAddr + 32, 10.0f, 240.0f, 0.0f, 0xFF00FFFF); // 2: Bottom-Left
    writeVtx(idxVtxAddr + 48, 50.0f, 240.0f, 0.0f, 0xFF00FFFF); // 3: Bottom-Right

    // 2 triangles: [0, 1, 2], [1, 3, 2]
    internalWriteMemory8(idxBufAddr + 0, 0);
    internalWriteMemory8(idxBufAddr + 1, 1);
    internalWriteMemory8(idxBufAddr + 2, 2);
    internalWriteMemory8(idxBufAddr + 3, 1);
    internalWriteMemory8(idxBufAddr + 4, 3);
    internalWriteMemory8(idxBufAddr + 5, 2);

    uint32_t vtypeIndexed = (1U << 23) | (1U << 11) | (7U << 2) | (3U << 7); // Through | 8-bit index | RGBA8888 | Float Pos
    internalWriteMemory32(dl + 0, (GE_CMD_TEXTUREMAPENABLE << 24) | 0);
    internalWriteMemory32(dl + 4, (GE_CMD_BASE << 24) | 0x080000);
    internalWriteMemory32(dl + 8, (GE_CMD_VADDR << 24) | (idxVtxAddr & 0x00FFFFFF));
    internalWriteMemory32(dl + 12, (GE_CMD_IADDR << 24) | (idxBufAddr & 0x00FFFFFF));
    internalWriteMemory32(dl + 16, (GE_CMD_VTYPE << 24) | vtypeIndexed);
    internalWriteMemory32(dl + 20, (GE_CMD_PRIM << 24) | (3 << 16) | 6); // Triangles, 6 indices
    internalWriteMemory32(dl + 24, (GE_CMD_END << 24));
    g_geProcessor.enqueue(dl, 0);
    uint32_t pIndexed = internalReadMemory32(fbAddr + (220 * 512 + 30) * 4);
    TEST_ASSERT("Indexed Vertex Array (IADDR + 8-bit Index)", pIndexed == 0xFF00FFFF);

    // Framebuffer conversion test for output
    std::vector<uint32_t> rgbaBuffer(480 * 272, 0);
    g_pRenderer->getFramebufferRGBA(rgbaBuffer.data(), 480, 272);

    ss << "\n----------------------------------------\n"
       << "GE TESTS: " << passedTests << " passed / " << (totalTests - passedTests) << " failed\n"
       << "========================================\n";

    return ss.str();
}


// --- Debug Trace & Crash Reporting ---
struct InstructionTraceEntry {
    uint32_t pc;
    uint32_t instr;
};

static InstructionTraceEntry g_pcTrace[32];
static size_t g_pcTraceIndex = 0;
static size_t g_pcTraceTotal = 0;
static std::string g_lastCrashReport = "";

static void recordPcTrace(uint32_t pc, uint32_t instr) {
    g_pcTrace[g_pcTraceIndex].pc = pc;
    g_pcTrace[g_pcTraceIndex].instr = instr;
    g_pcTraceIndex = (g_pcTraceIndex + 1) % 32;
    g_pcTraceTotal++;
}

static std::string dumpPcTrace() {
    std::ostringstream ss;
    ss << "--- Last Executed Instructions Trace (32 max) ---\n";
    size_t count = (g_pcTraceTotal < 32) ? g_pcTraceTotal : 32;
    size_t start = (g_pcTraceTotal < 32) ? 0 : g_pcTraceIndex;
    for (size_t i = 0; i < count; i++) {
        size_t idx = (start + i) % 32;
        ss << "[" << std::dec << (i + 1) << "] PC: 0x" << std::hex << std::uppercase << g_pcTrace[idx].pc
           << " | Instr: 0x" << g_pcTrace[idx].instr << "\n";
    }
    return ss.str();
}

static void triggerCpuCrashDump(MipsCpu& cpu, const std::string& reason) {
    std::ostringstream ss;
    ss << "=== CPU DEBUG CRASH / EXCEPTION DUMP ===\n";
    ss << "Reason: " << reason << "\n";
    ss << "PC: 0x" << std::hex << std::uppercase << cpu.pc
       << " | NextPC: 0x" << cpu.nextPc
       << " | InDelaySlot: " << (cpu.inDelaySlot ? "YES" : "NO")
       << " | BranchPending: " << (cpu.branchPending ? "YES" : "NO") << "\n";
    ss << "CP0 EPC: 0x" << cpu.cp0_epc
       << " | Status: 0x" << cpu.cp0_status
       << " | Cause: 0x" << cpu.cp0_cause
       << " | PRId: 0x" << cpu.cp0_prid << "\n";
    ss << "HI: 0x" << cpu.hi << " | LO: 0x" << cpu.lo << "\n";
    ss << "--- General Purpose Registers (GPRs) ---\n";
    for (int i = 0; i < 32; i += 4) {
        ss << "r" << std::dec << i << "-r" << (i+3) << ": "
           << "0x" << std::hex << cpu.regs[i] << ", "
           << "0x" << cpu.regs[i+1] << ", "
           << "0x" << cpu.regs[i+2] << ", "
           << "0x" << cpu.regs[i+3] << "\n";
    }
    ss << dumpPcTrace();
    g_lastCrashReport = ss.str();
    __android_log_print(ANDROID_LOG_ERROR, "NextEmuCrash", "%s", g_lastCrashReport.c_str());
}

static void executeMipsInstruction(MipsCpu& cpu) {
    // Always enforce $r0 == 0 at instruction start
    cpu.regs[0] = 0;

    if (cpu.pc == 0) return;

    // 1. Fetch instruction at cpu.pc
    uint32_t instr = internalReadMemory32(cpu.pc);

    // Record debug trace
    recordPcTrace(cpu.pc, instr);

    // 2. Determine default next PC
    bool wasInDelaySlot = cpu.inDelaySlot;
    uint32_t currentPc = cpu.pc;
    
    // Default next PC assuming linear flow
    uint32_t defaultNextPc = currentPc + 4;
    
    // If a branch was pending from previous instruction, next PC will be branchTarget
    if (cpu.branchPending) {
        cpu.nextPc = cpu.branchTarget;
        cpu.branchPending = false;
        cpu.inDelaySlot = false;
    } else {
        cpu.nextPc = defaultNextPc;
        cpu.inDelaySlot = false;
    }

    // Decode fields
    uint32_t opcode = (instr >> 26) & 0x3F;
    uint32_t rs     = (instr >> 21) & 0x1F;
    uint32_t rt     = (instr >> 16) & 0x1F;
    uint32_t rd     = (instr >> 11) & 0x1F;
    uint32_t shamt  = (instr >> 6)  & 0x1F;
    uint32_t funct  = instr & 0x3F;
    int32_t  imm    = (int32_t)(int16_t)(instr & 0xFFFF);
    uint32_t uimm   = instr & 0xFFFF;
    uint32_t target = instr & 0x03FFFFFF;

    auto doBranch = [&](bool condition, uint32_t targetAddr, bool isLikely = false) {
        if (condition) {
            cpu.branchPending = true;
            cpu.branchTarget = targetAddr;
            cpu.inDelaySlot = true;
        } else if (isLikely) {
            // Branch likely NOT taken: skip delay slot!
            cpu.nextPc = currentPc + 8;
            cpu.branchPending = false;
            cpu.inDelaySlot = false;
        }
    };

    switch (opcode) {
        case 0x00: // SPECIAL
            switch (funct) {
                case 0x00: // SLL
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rt] << shamt;
                    break;
                case 0x02: // SRL or ROTR
                    if (rd != 0) {
                        if (rs == 1) { // ROTR (Allegrex extension)
                            uint32_t v = cpu.regs[rt];
                            uint32_t s = shamt & 0x1F;
                            cpu.regs[rd] = (v >> s) | (v << ((32 - s) & 0x1F));
                        } else { // SRL
                            cpu.regs[rd] = cpu.regs[rt] >> shamt;
                        }
                    }
                    break;
                case 0x03: // SRA
                    if (rd != 0) cpu.regs[rd] = (int32_t)cpu.regs[rt] >> shamt;
                    break;
                case 0x04: // SLLV
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rt] << (cpu.regs[rs] & 0x1F);
                    break;
                case 0x06: // SRLV or ROTRV
                    if (rd != 0) {
                        if (shamt == 1) { // ROTRV (Allegrex extension)
                            uint32_t v = cpu.regs[rt];
                            uint32_t s = cpu.regs[rs] & 0x1F;
                            cpu.regs[rd] = (v >> s) | (v << ((32 - s) & 0x1F));
                        } else { // SRLV
                            cpu.regs[rd] = cpu.regs[rt] >> (cpu.regs[rs] & 0x1F);
                        }
                    }
                    break;
                case 0x07: // SRAV
                    if (rd != 0) cpu.regs[rd] = (int32_t)cpu.regs[rt] >> (cpu.regs[rs] & 0x1F);
                    break;
                case 0x08: // JR
                    doBranch(true, cpu.regs[rs]);
                    break;
                case 0x09: { // JALR
                    uint32_t jumpTarget = cpu.regs[rs];
                    if (rd != 0) cpu.regs[rd] = currentPc + 8;
                    else cpu.regs[31] = currentPc + 8;
                    doBranch(true, jumpTarget);
                    break;
                }
                case 0x0C: // SYSCALL
                    triggerSyscall(cpu, (instr >> 6) & 0xFFFFF, wasInDelaySlot);
                    break;
                case 0x0D: // BREAK
                    triggerException(cpu, 9 /* Breakpoint */, wasInDelaySlot);
                    break;
                case 0x10: // MFHI
                    if (rd != 0) cpu.regs[rd] = cpu.hi;
                    break;
                case 0x11: // MTHI
                    cpu.hi = cpu.regs[rs];
                    break;
                case 0x12: // MFLO
                    if (rd != 0) cpu.regs[rd] = cpu.lo;
                    break;
                case 0x13: // MTLO
                    cpu.lo = cpu.regs[rs];
                    break;
                case 0x18: { // MULT
                    int64_t res = (int64_t)(int32_t)cpu.regs[rs] * (int64_t)(int32_t)cpu.regs[rt];
                    cpu.hi = (uint32_t)(res >> 32);
                    cpu.lo = (uint32_t)(res & 0xFFFFFFFF);
                    break;
                }
                case 0x19: { // MULTU
                    uint64_t res = (uint64_t)cpu.regs[rs] * (uint64_t)cpu.regs[rt];
                    cpu.hi = (uint32_t)(res >> 32);
                    cpu.lo = (uint32_t)(res & 0xFFFFFFFF);
                    break;
                }
                case 0x1A: // DIV
                    if (cpu.regs[rt] != 0) {
                        cpu.lo = (uint32_t)((int32_t)cpu.regs[rs] / (int32_t)cpu.regs[rt]);
                        cpu.hi = (uint32_t)((int32_t)cpu.regs[rs] % (int32_t)cpu.regs[rt]);
                    }
                    break;
                case 0x1B: // DIVU
                    if (cpu.regs[rt] != 0) {
                        cpu.lo = cpu.regs[rs] / cpu.regs[rt];
                        cpu.hi = cpu.regs[rs] % cpu.regs[rt];
                    }
                    break;
                case 0x20: { // ADD (safe uint32_t overflow check without C++ UB)
                    uint32_t u1 = cpu.regs[rs];
                    uint32_t u2 = cpu.regs[rt];
                    uint32_t sum = u1 + u2;
                    bool overflow = (((~(u1 ^ u2)) & (u1 ^ sum)) & 0x80000000U) != 0;
                    if (overflow) {
                        triggerException(cpu, 12 /* Overflow */, wasInDelaySlot);
                    } else {
                        if (rd != 0) cpu.regs[rd] = sum;
                    }
                    break;
                }
                case 0x21: // ADDU
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rs] + cpu.regs[rt];
                    break;
                case 0x22: { // SUB (safe uint32_t overflow check without C++ UB)
                    uint32_t u1 = cpu.regs[rs];
                    uint32_t u2 = cpu.regs[rt];
                    uint32_t diff = u1 - u2;
                    bool overflow = (((u1 ^ u2) & (u1 ^ diff)) & 0x80000000U) != 0;
                    if (overflow) {
                        triggerException(cpu, 12 /* Overflow */, wasInDelaySlot);
                    } else {
                        if (rd != 0) cpu.regs[rd] = diff;
                    }
                    break;
                }
                case 0x23: // SUBU
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rs] - cpu.regs[rt];
                    break;
                case 0x24: // AND
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rs] & cpu.regs[rt];
                    break;
                case 0x25: // OR
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rs] | cpu.regs[rt];
                    break;
                case 0x26: // XOR
                    if (rd != 0) cpu.regs[rd] = cpu.regs[rs] ^ cpu.regs[rt];
                    break;
                case 0x27: // NOR
                    if (rd != 0) cpu.regs[rd] = ~(cpu.regs[rs] | cpu.regs[rt]);
                    break;
                case 0x2A: // SLT
                    if (rd != 0) cpu.regs[rd] = ((int32_t)cpu.regs[rs] < (int32_t)cpu.regs[rt]) ? 1 : 0;
                    break;
                case 0x2B: // SLTU
                    if (rd != 0) cpu.regs[rd] = (cpu.regs[rs] < cpu.regs[rt]) ? 1 : 0;
                    break;
                default:
                    break;
            }
            break;

        case 0x01: // REGIMM
            switch (rt) {
                case 0x00: // BLTZ
                    doBranch((int32_t)cpu.regs[rs] < 0, currentPc + 4 + (imm << 2));
                    break;
                case 0x01: // BGEZ
                    doBranch((int32_t)cpu.regs[rs] >= 0, currentPc + 4 + (imm << 2));
                    break;
                case 0x02: // BLTZL (Branch likely)
                    doBranch((int32_t)cpu.regs[rs] < 0, currentPc + 4 + (imm << 2), true);
                    break;
                case 0x03: // BGEZL (Branch likely)
                    doBranch((int32_t)cpu.regs[rs] >= 0, currentPc + 4 + (imm << 2), true);
                    break;
                case 0x10: // BLTZAL
                    cpu.regs[31] = currentPc + 8;
                    doBranch((int32_t)cpu.regs[rs] < 0, currentPc + 4 + (imm << 2));
                    break;
                case 0x11: // BGEZAL
                    cpu.regs[31] = currentPc + 8;
                    doBranch((int32_t)cpu.regs[rs] >= 0, currentPc + 4 + (imm << 2));
                    break;
                default:
                    break;
            }
            break;

        case 0x02: // J
            doBranch(true, ((currentPc + 4) & 0xF0000000) | (target << 2));
            break;
        case 0x03: // JAL
            cpu.regs[31] = currentPc + 8;
            doBranch(true, ((currentPc + 4) & 0xF0000000) | (target << 2));
            break;
        case 0x04: // BEQ
            doBranch(cpu.regs[rs] == cpu.regs[rt], currentPc + 4 + (imm << 2));
            break;
        case 0x05: // BNE
            doBranch(cpu.regs[rs] != cpu.regs[rt], currentPc + 4 + (imm << 2));
            break;
        case 0x06: // BLEZ
            doBranch((int32_t)cpu.regs[rs] <= 0, currentPc + 4 + (imm << 2));
            break;
        case 0x07: // BGTZ
            doBranch((int32_t)cpu.regs[rs] > 0, currentPc + 4 + (imm << 2));
            break;
        case 0x08: { // ADDI (safe uint32_t overflow check without C++ UB)
            uint32_t u1 = cpu.regs[rs];
            uint32_t u2 = (uint32_t)imm;
            uint32_t sum = u1 + u2;
            bool overflow = (((~(u1 ^ u2)) & (u1 ^ sum)) & 0x80000000U) != 0;
            if (overflow) {
                triggerException(cpu, 12 /* Overflow */, wasInDelaySlot);
            } else {
                if (rt != 0) cpu.regs[rt] = sum;
            }
            break;
        }
        case 0x09: // ADDIU
            if (rt != 0) cpu.regs[rt] = cpu.regs[rs] + imm;
            break;
        case 0x0A: // SLTI
            if (rt != 0) cpu.regs[rt] = ((int32_t)cpu.regs[rs] < imm) ? 1 : 0;
            break;
        case 0x0B: // SLTIU
            if (rt != 0) cpu.regs[rt] = (cpu.regs[rs] < (uint32_t)imm) ? 1 : 0;
            break;
        case 0x0C: // ANDI
            if (rt != 0) cpu.regs[rt] = cpu.regs[rs] & uimm;
            break;
        case 0x0D: // ORI
            if (rt != 0) cpu.regs[rt] = cpu.regs[rs] | uimm;
            break;
        case 0x0E: // XORI
            if (rt != 0) cpu.regs[rt] = cpu.regs[rs] ^ uimm;
            break;
        case 0x0F: // LUI
            if (rt != 0) cpu.regs[rt] = uimm << 16;
            break;

        case 0x10: // COP0 (System Coprocessor)
            switch (rs) {
                case 0x00: // MFC0
                    if (rt != 0) {
                        if (rd == 12) cpu.regs[rt] = cpu.cp0_status;
                        else if (rd == 13) cpu.regs[rt] = cpu.cp0_cause;
                        else if (rd == 14) cpu.regs[rt] = cpu.cp0_epc;
                        else if (rd == 15) cpu.regs[rt] = cpu.cp0_prid;
                        else cpu.regs[rt] = 0;
                    }
                    break;
                case 0x04: // MTC0
                    if (rd == 12) cpu.cp0_status = cpu.regs[rt];
                    else if (rd == 13) cpu.cp0_cause = cpu.regs[rt];
                    else if (rd == 14) cpu.cp0_epc = cpu.regs[rt];
                    break;
                case 0x10: // ERET (Exception Return)
                    if (funct == 0x18) {
                        cpu.nextPc = cpu.cp0_epc;
                        cpu.cp0_status &= ~0x02; // Clear EXL bit
                    }
                    break;
                default:
                    break;
            }
            break;

        case 0x14: // BEQL
            doBranch(cpu.regs[rs] == cpu.regs[rt], currentPc + 4 + (imm << 2), true);
            break;
        case 0x15: // BNEL
            doBranch(cpu.regs[rs] != cpu.regs[rt], currentPc + 4 + (imm << 2), true);
            break;
        case 0x16: // BLEZL
            doBranch((int32_t)cpu.regs[rs] <= 0, currentPc + 4 + (imm << 2), true);
            break;
        case 0x17: // BGTZL
            doBranch((int32_t)cpu.regs[rs] > 0, currentPc + 4 + (imm << 2), true);
            break;

        // Load / Store Instructions
        case 0x20: // LB (Load Byte Signed)
            if (rt != 0) cpu.regs[rt] = (int32_t)(int8_t)internalReadMemory8(cpu.regs[rs] + imm);
            break;
        case 0x21: // LH (Load Halfword Signed)
            if (rt != 0) cpu.regs[rt] = (int32_t)(int16_t)internalReadMemory16(cpu.regs[rs] + imm);
            break;
        case 0x22: // LWL (Load Word Left)
            if (rt != 0) {
                uint32_t a = cpu.regs[rs] + imm;
                uint32_t shift = (a & 3) * 8;
                uint32_t mem = internalReadMemory32(a & ~3);
                uint32_t mask = 0x00FFFFFF >> (24 - shift);
                cpu.regs[rt] = (cpu.regs[rt] & mask) | (mem << shift);
            }
            break;
        case 0x23: // LW (Load Word)
            if (rt != 0) cpu.regs[rt] = internalReadMemory32(cpu.regs[rs] + imm);
            break;
        case 0x24: // LBU (Load Byte Unsigned)
            if (rt != 0) cpu.regs[rt] = internalReadMemory8(cpu.regs[rs] + imm);
            break;
        case 0x25: // LHU (Load Halfword Unsigned)
            if (rt != 0) cpu.regs[rt] = internalReadMemory16(cpu.regs[rs] + imm);
            break;
        case 0x26: // LWR (Load Word Right)
            if (rt != 0) {
                uint32_t a = cpu.regs[rs] + imm;
                uint32_t shift = (a & 3) * 8;
                uint32_t mem = internalReadMemory32(a & ~3);
                uint32_t mask = 0xFFFFFF00 << shift;
                cpu.regs[rt] = (cpu.regs[rt] & mask) | (mem >> (24 - shift));
            }
            break;

        case 0x28: // SB (Store Byte)
            internalWriteMemory8(cpu.regs[rs] + imm, cpu.regs[rt] & 0xFF);
            break;
        case 0x29: // SH (Store Halfword)
            internalWriteMemory16(cpu.regs[rs] + imm, cpu.regs[rt] & 0xFFFF);
            break;
        case 0x2A: { // SWL (Store Word Left)
            uint32_t a = cpu.regs[rs] + imm;
            uint32_t shift = (a & 3) * 8;
            uint32_t mem = internalReadMemory32(a & ~3);
            uint32_t mask = 0xFFFFFF00 << (24 - shift);
            uint32_t val = (mem & mask) | (cpu.regs[rt] >> shift);
            internalWriteMemory32(a & ~3, val);
            break;
        }
        case 0x2B: // SW (Store Word)
            internalWriteMemory32(cpu.regs[rs] + imm, cpu.regs[rt]);
            break;
        case 0x2E: { // SWR (Store Word Right)
            uint32_t a = cpu.regs[rs] + imm;
            uint32_t shift = (a & 3) * 8;
            uint32_t mem = internalReadMemory32(a & ~3);
            uint32_t mask = 0x00FFFFFF >> shift;
            uint32_t val = (mem & mask) | (cpu.regs[rt] << (24 - shift));
            internalWriteMemory32(a & ~3, val);
            break;
        }

        default:
            break;
    }

    // Advance PC to nextPc and enforce r0 == 0 at instruction exit
    cpu.pc = cpu.nextPc;
    cpu.regs[0] = 0;
}

// MIPS Opcode Helper Encoders
static inline uint32_t encR(uint32_t opcode, uint32_t rs, uint32_t rt, uint32_t rd, uint32_t shamt, uint32_t funct) {
    return ((opcode & 0x3F) << 26) | ((rs & 0x1F) << 21) | ((rt & 0x1F) << 16) | ((rd & 0x1F) << 11) | ((shamt & 0x1F) << 6) | (funct & 0x3F);
}

static inline uint32_t encI(uint32_t opcode, uint32_t rs, uint32_t rt, int16_t imm) {
    return ((opcode & 0x3F) << 26) | ((rs & 0x1F) << 21) | ((rt & 0x1F) << 16) | ((uint32_t)(uint16_t)imm);
}

static inline uint32_t encJ(uint32_t opcode, uint32_t target) {
    return ((opcode & 0x3F) << 26) | (target & 0x03FFFFFF);
}

static std::string runCpuAutoTests() {
    std::ostringstream ss;
    ss << "==================================================\n";
    ss << "=== NextEmu Allegrex MIPS CPU Full Test Suite  ===\n";
    ss << "==================================================\n";

    int passCount = 0;
    int failCount = 0;

    auto assertTest = [&](const std::string& name, bool cond) {
        if (cond) {
            ss << "[PASS] " << name << "\n";
            passCount++;
        } else {
            ss << "[FAIL] " << name << "\n";
            failCount++;
        }
    };

    MipsCpu tCpu;
    auto resetCpu = [&](uint32_t startPc = 0x08000100) {
        memset(&tCpu, 0, sizeof(MipsCpu));
        tCpu.pc = startPc;
        tCpu.nextPc = startPc + 4;
        tCpu.cp0_prid = 0x00018000;
    };

    // --- TEST 1: R0 Invariance (R0 must ALWAYS remain 0) ---
    {
        resetCpu(0x08000100);
        uint32_t base = 0x08000100;
        internalWriteMemory32(base + 0, encI(0x09, 0, 0, 100));     // ADDIU r0, r0, 100
        internalWriteMemory32(base + 4, encI(0x0F, 0, 0, 0x1234)); // LUI r0, 0x1234
        internalWriteMemory32(base + 8, encR(0, 1, 2, 0, 0, 0x21)); // ADDU r0, r1, r2

        tCpu.regs[1] = 50;
        tCpu.regs[2] = 50;

        executeMipsInstruction(tCpu); // ADDIU r0
        bool r0_check1 = (tCpu.regs[0] == 0);

        executeMipsInstruction(tCpu); // LUI r0
        bool r0_check2 = (tCpu.regs[0] == 0);

        executeMipsInstruction(tCpu); // ADDU r0
        bool r0_check3 = (tCpu.regs[0] == 0);

        assertTest("R0 Invariance: Writing to R0 leaves R0 == 0", r0_check1 && r0_check2 && r0_check3);
    }

    // --- TEST 2: Branch + Delay Slot Pipeline (BEQ, BNE, BLEZ, BGTZ, BLTZ, BGEZ) ---
    {
        uint32_t base = 0x08000100;

        // 2a. BEQ (taken) + Delay Slot
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x04, 1, 2, 2));      // BEQ r1, r2, +2 (target base + 12)
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 111));    // ADDIU r3, r0, 111 (Delay Slot)
        internalWriteMemory32(base + 8, encI(0x09, 0, 3, 222));    // ADDIU r3, r0, 222 (Fallthrough)
        internalWriteMemory32(base + 12, encI(0x09, 0, 4, 333));   // ADDIU r4, r0, 333 (Branch Target)

        tCpu.regs[1] = 42;
        tCpu.regs[2] = 42;

        executeMipsInstruction(tCpu); // BEQ
        bool beq_pipeline_ok = (tCpu.pc == base + 4) && tCpu.inDelaySlot && tCpu.branchPending && (tCpu.branchTarget == base + 12);

        executeMipsInstruction(tCpu); // Delay Slot executed
        bool delay_slot_ok = (tCpu.regs[3] == 111) && (tCpu.pc == base + 12);

        executeMipsInstruction(tCpu); // Target executed
        bool target_ok = (tCpu.regs[4] == 333) && (tCpu.pc == base + 16);

        assertTest("BEQ (taken): Delay Slot executed BEFORE Branch Target jump", beq_pipeline_ok && delay_slot_ok && target_ok);

        // 2b. BNE (taken)
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x05, 1, 2, 2));      // BNE r1, r2, +2
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 555));    // Delay slot
        internalWriteMemory32(base + 12, encI(0x09, 0, 4, 777));   // Target
        tCpu.regs[1] = 10;
        tCpu.regs[2] = 20;

        executeMipsInstruction(tCpu); // BNE
        executeMipsInstruction(tCpu); // Delay Slot
        executeMipsInstruction(tCpu); // Target
        assertTest("BNE (taken): Delay Slot & Target executed", tCpu.regs[3] == 555 && tCpu.regs[4] == 777 && tCpu.pc == base + 16);

        // 2c. BLEZ (taken), BGTZ (taken), BLTZ (taken), BGEZ (taken)
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x06, 1, 0, 2));      // BLEZ r1, +2
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 10));     // Delay slot: r3 = 10
        internalWriteMemory32(base + 12, encI(0x09, 0, 4, 20));    // Target: r4 = 20
        tCpu.regs[1] = (uint32_t)-5;
        executeMipsInstruction(tCpu);
        executeMipsInstruction(tCpu);
        executeMipsInstruction(tCpu);
        assertTest("BLEZ (r1 <= 0 taken): Delay Slot & Target executed", tCpu.regs[3] == 10 && tCpu.regs[4] == 20);

        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x07, 1, 0, 2));      // BGTZ r1, +2
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 15));     // Delay slot: r3 = 15
        internalWriteMemory32(base + 12, encI(0x09, 0, 4, 25));    // Target: r4 = 25
        tCpu.regs[1] = 5;
        executeMipsInstruction(tCpu);
        executeMipsInstruction(tCpu);
        executeMipsInstruction(tCpu);
        assertTest("BGTZ (r1 > 0 taken): Delay Slot & Target executed", tCpu.regs[3] == 15 && tCpu.regs[4] == 25);
    }

    // --- TEST 3: Branch-Likely (BEQL, BNEL, BLEZL, BGTZL, BLTZL, BGEZL) ---
    {
        uint32_t base = 0x08000100;

        // 3a. BEQL TAKEN: Delay Slot MUST BE EXECUTED
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x14, 1, 2, 2));      // BEQL r1, r2, +2
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 888));    // Delay Slot: r3 = 888
        internalWriteMemory32(base + 8, encI(0x09, 0, 3, 999));    // Fallthrough: r3 = 999
        internalWriteMemory32(base + 12, encI(0x09, 0, 4, 1111));  // Target: r4 = 1111

        tCpu.regs[1] = 100;
        tCpu.regs[2] = 100;

        executeMipsInstruction(tCpu); // BEQL
        executeMipsInstruction(tCpu); // Delay slot
        executeMipsInstruction(tCpu); // Target
        assertTest("BEQL (taken): Delay Slot IS executed & target reached", tCpu.regs[3] == 888 && tCpu.regs[4] == 1111 && tCpu.pc == base + 16);

        // 3b. BEQL NOT TAKEN: Delay Slot MUST BE SKIPPED (next PC = base + 8)
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x14, 1, 2, 2));      // BEQL r1, r2, +2
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 888));    // Delay Slot: r3 = 888
        internalWriteMemory32(base + 8, encI(0x09, 0, 5, 2222));   // Instruction at base + 8: r5 = 2222

        tCpu.regs[1] = 100;
        tCpu.regs[2] = 200; // NOT EQUAL -> NOT TAKEN

        executeMipsInstruction(tCpu); // BEQL NOT TAKEN
        bool skipped_delay_pc = (tCpu.pc == base + 8);
        executeMipsInstruction(tCpu); // Executed base + 8
        bool delay_slot_not_run = (tCpu.regs[3] == 0) && (tCpu.regs[5] == 2222);

        assertTest("BEQL (not-taken): Delay Slot SKIPPED, PC resumed at PC+8", skipped_delay_pc && delay_slot_not_run);

        // 3c. BNEL, BLEZL, BGTZL, BLTZL, BGEZL Not-Taken Skip Test
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x15, 1, 2, 2));      // BNEL r1, r2, +2 (NOT TAKEN since r1 == r2)
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 777));    // Delay slot
        internalWriteMemory32(base + 8, encI(0x09, 0, 6, 3333));   // Next instruction
        tCpu.regs[1] = 50;
        tCpu.regs[2] = 50;
        executeMipsInstruction(tCpu); // BNEL not taken
        executeMipsInstruction(tCpu);
        assertTest("BNEL (not-taken): Delay Slot SKIPPED", tCpu.regs[3] == 0 && tCpu.regs[6] == 3333);
    }

    // --- TEST 4: J / JAL / JR / JALR Jump Test ---
    {
        uint32_t base = 0x08000100;

        // 4a. J (Jump)
        resetCpu(base);
        uint32_t jTarget = 0x08000200;
        internalWriteMemory32(base + 0, encJ(0x02, (jTarget >> 2) & 0x03FFFFFF)); // J 0x08000200
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 50));                    // Delay slot: r3 = 50
        internalWriteMemory32(jTarget, encI(0x09, 0, 4, 60));                     // Target: r4 = 60

        executeMipsInstruction(tCpu); // J
        executeMipsInstruction(tCpu); // Delay Slot
        bool j_ok = (tCpu.regs[3] == 50) && (tCpu.pc == jTarget);
        executeMipsInstruction(tCpu); // Target
        assertTest("J (Jump): Delay Slot executed & Target reached", j_ok && tCpu.regs[4] == 60);

        // 4b. JAL (Jump and Link)
        resetCpu(base);
        internalWriteMemory32(base + 0, encJ(0x03, (jTarget >> 2) & 0x03FFFFFF)); // JAL 0x08000200
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 70));                    // Delay slot: r3 = 70

        executeMipsInstruction(tCpu); // JAL
        bool ra_saved = (tCpu.regs[31] == base + 8);
        executeMipsInstruction(tCpu); // Delay Slot
        bool jal_ok = ra_saved && (tCpu.regs[3] == 70) && (tCpu.pc == jTarget);
        assertTest("JAL (Jump and Link): $ra = PC+8 & Target reached", jal_ok);

        // 4c. JR (Jump Register)
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 0, 0, 0, 0x08)); // JR r1
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 80));      // Delay slot: r3 = 80
        tCpu.regs[1] = 0x08000300;

        executeMipsInstruction(tCpu); // JR
        executeMipsInstruction(tCpu); // Delay slot
        assertTest("JR (Jump Register): Delay Slot executed & Target reached", tCpu.regs[3] == 80 && tCpu.pc == 0x08000300);

        // 4d. JALR (Jump and Link Register)
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 0, 5, 0, 0x09)); // JALR r5, r1
        internalWriteMemory32(base + 4, encI(0x09, 0, 3, 90));      // Delay slot: r3 = 90
        tCpu.regs[1] = 0x08000400;

        executeMipsInstruction(tCpu); // JALR
        bool link_reg_ok = (tCpu.regs[5] == base + 8);
        executeMipsInstruction(tCpu); // Delay slot
        assertTest("JALR (Jump and Link Register): Link Reg = PC+8 & Target reached", link_reg_ok && tCpu.regs[3] == 90 && tCpu.pc == 0x08000400);
    }

    // --- TEST 5: HI / LO and MULT / MULTU / DIV / DIVU ---
    {
        uint32_t base = 0x08000100;

        // 5a. MULT (Signed Multiplication)
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 2, 0, 0, 0x18)); // MULT r1, r2
        internalWriteMemory32(base + 4, encR(0, 0, 0, 3, 0, 0x12)); // MFLO r3
        internalWriteMemory32(base + 8, encR(0, 0, 0, 4, 0, 0x10)); // MFHI r4

        tCpu.regs[1] = (uint32_t)-10; // -10
        tCpu.regs[2] = 50;           // 50

        executeMipsInstruction(tCpu); // MULT
        executeMipsInstruction(tCpu); // MFLO
        executeMipsInstruction(tCpu); // MFHI

        assertTest("MULT Signed Product (-10 * 50 == -500 in HI/LO)", tCpu.regs[3] == 0xFFFFFE0C && tCpu.regs[4] == 0xFFFFFFFF);

        // 5b. MULTU (Unsigned Multiplication)
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 2, 0, 0, 0x19)); // MULTU r1, r2
        internalWriteMemory32(base + 4, encR(0, 0, 0, 3, 0, 0x12)); // MFLO r3
        internalWriteMemory32(base + 8, encR(0, 0, 0, 4, 0, 0x10)); // MFHI r4

        tCpu.regs[1] = 0x80000000;
        tCpu.regs[2] = 4;

        executeMipsInstruction(tCpu); // MULTU
        executeMipsInstruction(tCpu); // MFLO
        executeMipsInstruction(tCpu); // MFHI

        assertTest("MULTU Unsigned Product (0x80000000 * 4 -> HI=2, LO=0)", tCpu.regs[3] == 0 && tCpu.regs[4] == 2);

        // 5c. DIV / DIVU & MTHI / MTLO
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 2, 0, 0, 0x1A)); // DIV r1, r2
        internalWriteMemory32(base + 4, encR(0, 0, 0, 3, 0, 0x12)); // MFLO r3 (quotient)
        internalWriteMemory32(base + 8, encR(0, 0, 0, 4, 0, 0x10)); // MFHI r4 (remainder)

        tCpu.regs[1] = (uint32_t)-100; // -100
        tCpu.regs[2] = 7;             // 7

        executeMipsInstruction(tCpu); // DIV
        executeMipsInstruction(tCpu); // MFLO
        executeMipsInstruction(tCpu); // MFHI

        assertTest("DIV Signed Division (-100 / 7 -> LO=-14, HI=-2)", tCpu.regs[3] == (uint32_t)-14 && tCpu.regs[4] == (uint32_t)-2);

        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 0, 0, 0, 0x11)); // MTHI r1
        internalWriteMemory32(base + 4, encR(0, 2, 0, 0, 0, 0x13)); // MTLO r2
        internalWriteMemory32(base + 8, encR(0, 0, 0, 3, 0, 0x10)); // MFHI r3
        internalWriteMemory32(base + 12, encR(0, 0, 0, 4, 0, 0x12)); // MFLO r4

        tCpu.regs[1] = 0x12345678;
        tCpu.regs[2] = 0x87654321;

        executeMipsInstruction(tCpu); // MTHI
        executeMipsInstruction(tCpu); // MTLO
        executeMipsInstruction(tCpu); // MFHI
        executeMipsInstruction(tCpu); // MFLO

        assertTest("MTHI / MTLO / MFHI / MFLO Roundtrip", tCpu.regs[3] == 0x12345678 && tCpu.regs[4] == 0x87654321);
    }

    // --- TEST 6: Load / Store Memory Instructions (LB, LBU, LH, LHU, LW, SB, SH, SW) ---
    {
        uint32_t base = 0x08000100;
        uint32_t dataAddr = 0x08000500;

        // 6a. Byte Store & Load (LB vs LBU)
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x28, 2, 1, 0));       // SB r1, 0(r2)
        internalWriteMemory32(base + 4, encI(0x20, 2, 3, 0));       // LB r3, 0(r2) (Signed)
        internalWriteMemory32(base + 8, encI(0x24, 2, 4, 0));       // LBU r4, 0(r2) (Unsigned)

        tCpu.regs[1] = 0x80; // Negative byte in int8_t (-128)
        tCpu.regs[2] = dataAddr;

        executeMipsInstruction(tCpu); // SB
        executeMipsInstruction(tCpu); // LB
        executeMipsInstruction(tCpu); // LBU

        assertTest("LB Sign-Extension (0x80 -> 0xFFFFFF80)", tCpu.regs[3] == 0xFFFFFF80);
        assertTest("LBU Zero-Extension (0x80 -> 0x00000080)", tCpu.regs[4] == 0x00000080);

        // 6b. Halfword Store & Load (LH vs LHU)
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x29, 2, 1, 0));       // SH r1, 0(r2)
        internalWriteMemory32(base + 4, encI(0x21, 2, 3, 0));       // LH r3, 0(r2) (Signed)
        internalWriteMemory32(base + 8, encI(0x25, 2, 4, 0));       // LHU r4, 0(r2) (Unsigned)

        tCpu.regs[1] = 0x8000; // Negative halfword in int16_t (-32768)
        tCpu.regs[2] = dataAddr;

        executeMipsInstruction(tCpu); // SH
        executeMipsInstruction(tCpu); // LH
        executeMipsInstruction(tCpu); // LHU

        assertTest("LH Sign-Extension (0x8000 -> 0xFFFF8000)", tCpu.regs[3] == 0xFFFF8000);
        assertTest("LHU Zero-Extension (0x8000 -> 0x00008000)", tCpu.regs[4] == 0x00008000);

        // 6c. Word Store & Load (SW & LW)
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x2B, 2, 1, 0));       // SW r1, 0(r2)
        internalWriteMemory32(base + 4, encI(0x23, 2, 3, 0));       // LW r3, 0(r2)

        tCpu.regs[1] = 0xAABBCCDD;
        tCpu.regs[2] = dataAddr;

        executeMipsInstruction(tCpu); // SW
        executeMipsInstruction(tCpu); // LW

        assertTest("SW / LW 32-bit Word Roundtrip (0xAABBCCDD)", tCpu.regs[3] == 0xAABBCCDD);
    }

    // --- TEST 7: CP0 Coprocessor 0 & ERET Pipeline ---
    {
        uint32_t base = 0x08000100;

        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0x10, 4, 1, 12, 0, 0)); // MTC0 r1, reg12 (Status)
        internalWriteMemory32(base + 4, encR(0x10, 4, 2, 14, 0, 0)); // MTC0 r2, reg14 (EPC)
        internalWriteMemory32(base + 8, encR(0x10, 0, 3, 12, 0, 0)); // MFC0 r3, reg12
        internalWriteMemory32(base + 12, encR(0x10, 0, 4, 14, 0, 0)); // MFC0 r4, reg14
        internalWriteMemory32(base + 16, 0x42000018);               // ERET

        tCpu.regs[1] = 0x00000003; // Status
        tCpu.regs[2] = 0x08000600; // EPC

        executeMipsInstruction(tCpu); // MTC0 Status
        executeMipsInstruction(tCpu); // MTC0 EPC
        executeMipsInstruction(tCpu); // MFC0 Status
        executeMipsInstruction(tCpu); // MFC0 EPC

        bool cp0_rw_ok = (tCpu.regs[3] == 0x00000003) && (tCpu.regs[4] == 0x08000600);

        tCpu.cp0_status |= 0x02; // Set EXL bit
        executeMipsInstruction(tCpu); // ERET

        bool eret_ok = (tCpu.nextPc == 0x08000600) && ((tCpu.cp0_status & 0x02) == 0);

        assertTest("CP0 MTC0 / MFC0 Status & EPC Read/Write", cp0_rw_ok);
        assertTest("ERET Exception Return clears EXL bit & jumps to CP0 EPC", eret_ok);
    }

    // --- TEST 8: Safe Arithmetic Overflow Check (ADD, SUB, ADDI without C++ UB) ---
    {
        uint32_t base = 0x08000100;

        // 8a. ADD Overflow
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 2, 3, 0, 0x20)); // ADD r3, r1, r2
        tCpu.regs[1] = 0x7FFFFFFF;
        tCpu.regs[2] = 1;

        executeMipsInstruction(tCpu); // ADD overflowing
        bool add_overflow_caught = (tCpu.cp0_cause >> 2) == 12 && (tCpu.cp0_status & 0x02) != 0;

        // 8b. ADD Normal
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 2, 3, 0, 0x20)); // ADD r3, r1, r2
        tCpu.regs[1] = 10;
        tCpu.regs[2] = 20;

        executeMipsInstruction(tCpu); // ADD normal
        bool add_normal_ok = (tCpu.regs[3] == 30);

        // 8c. SUB Overflow
        resetCpu(base);
        internalWriteMemory32(base + 0, encR(0, 1, 2, 3, 0, 0x22)); // SUB r3, r1, r2
        tCpu.regs[1] = 0x80000000;
        tCpu.regs[2] = 1;

        executeMipsInstruction(tCpu); // SUB overflowing
        bool sub_overflow_caught = (tCpu.cp0_cause >> 2) == 12;

        // 8d. ADDI Overflow
        resetCpu(base);
        internalWriteMemory32(base + 0, encI(0x08, 1, 3, 1)); // ADDI r3, r1, 1
        tCpu.regs[1] = 0x7FFFFFFF;

        executeMipsInstruction(tCpu); // ADDI overflowing
        bool addi_overflow_caught = (tCpu.cp0_cause >> 2) == 12;

        assertTest("Safe ADD Overflow exception (0x7FFFFFFF + 1 -> Exception 12)", add_overflow_caught);
        assertTest("Safe ADD Normal sum (10 + 20 == 30)", add_normal_ok);
        assertTest("Safe SUB Overflow exception (0x80000000 - 1 -> Exception 12)", sub_overflow_caught);
        assertTest("Safe ADDI Overflow exception (0x7FFFFFFF + 1 -> Exception 12)", addi_overflow_caught);
    }

    ss << "==================================================\n";
    ss << "Summary: Passed " << passCount << " / " << (passCount + failCount) << " tests.\n";
    if (failCount == 0) {
        ss << "Result: ALL " << passCount << " CPU SUITE TESTS PASSED PERFECTLY! [STABLE]";
    } else {
        ss << "Result: " << failCount << " TESTS FAILED!";
    }

    return ss.str();
}

static bool loadElf(const std::string& path) {
    FILE* fp = fopen(path.c_str(), "rb");
    if (!fp) return false;

    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (size <= 0) {
        
        return false;
    }

    std::vector<uint8_t> buf(size);
    size_t readSize = fread(buf.data(), 1, size, fp);
    

    return parseAndLoadElfBuffer(buf.data(), readSize);
}

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_getEngineVersion(
        JNIEnv* env,
        jobject /* this */) {
    std::string ver = "NextEmu Core v2.0 | MIPS Allegrex R4000 | 50+ instr + Branch Delay Pipeline | ISO+ELF+PRX | HLE Syscalls";
    return env->NewStringUTF(ver.c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_initCoreFd(
        JNIEnv* env,
        jobject /* this */,
        jint fd,
        jlong fileSize,
        jstring gamePath) {
    for (auto& pair : g_vfsMap) {
        if (pair.second.fp) pair.second.fp = nullptr;
    }
    g_vfsMap.clear();
    g_nextFd = 1;
    initSyscalls();

    if (g_gameFd >= 0) {
        close(g_gameFd);
        g_gameFd = -1;
    }

    g_gameFd = fd;
    g_gameFileSize = fileSize;

    const char* pathStr = env->GetStringUTFChars(gamePath, nullptr);
    if (pathStr) {
        g_currentGamePath = std::string(pathStr);
        env->ReleaseStringUTFChars(gamePath, pathStr);
    } else {
        g_currentGamePath = "";
    }
    
    std::fill(mainRAM.begin(), mainRAM.end(), 0);
    g_gameInfo = parseIso(openGameImage());
    bool loadOk = loadEboot();
    
    g_isInitialized = loadOk;
    g_frameCount = 0;
    g_totalInstructions = 0;
    g_startTime = std::chrono::steady_clock::now();
    return loadOk ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_initCore(
        JNIEnv* env,
        jobject thiz,
        jstring gamePath) {
    return Java_com_nextemu_psp_engine_NativeEmuEngine_initCoreFd(env, thiz, -1, 0, gamePath);
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_getCoreStatus(
        JNIEnv* env,
        jobject /* this */) {
    std::ostringstream ss;
    if (g_isInitialized) {
        ss << "Core Active | Module: " << g_activeModule.name
           << " | Status: " << g_loaderStatus
           << " | Frames: " << g_frameCount;
    } else {
        ss << "Core Idle | Loader: " << g_loaderStatus;
    }
    return env->NewStringUTF(ss.str().c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_stepFrame(
        JNIEnv* env,
        jobject /* this */) {
    pthread_mutex_lock(&g_cpuMutex);
    
    if (!g_isInitialized) {
        pthread_mutex_unlock(&g_cpuMutex);
        return env->NewStringUTF("Error: Core not initialized");
    }
    
    if (g_syscallTable.empty()) initSyscalls();

    uint32_t targetInstructionBudget = 25000;
    uint32_t executedThisFrame = 0;

    for (uint32_t i = 0; i < targetInstructionBudget; i++) {
        bool isValidPc = ((g_cpu.pc & 3) == 0) &&
                         ((g_cpu.pc >= 0x00010000 && g_cpu.pc < 0x00010000 + 16 * 1024) ||
                          (g_cpu.pc >= 0x04000000 && g_cpu.pc < 0x04000000 + 2 * 1024 * 1024) ||
                          (g_cpu.pc >= 0x08000000 && g_cpu.pc < 0x08000000 + 32 * 1024 * 1024) ||
                          (g_cpu.pc >= 0x88000000 && g_cpu.pc < 0x88000000 + 4 * 1024 * 1024));
        if (!isValidPc) {
            triggerCpuCrashDump(g_cpu, "Invalid PC Address or Misalignment (Bus Error)");
            triggerException(g_cpu, 4 /* Address Error Fetch */, g_cpu.inDelaySlot);
            pthread_mutex_unlock(&g_cpuMutex);
            std::ostringstream ss;
            ss << "Error: CPU Crash - Invalid PC 0x" << std::hex << std::uppercase << g_cpu.pc;
            return env->NewStringUTF(ss.str().c_str());
        }

        executeMipsInstruction(g_cpu);
        executedThisFrame++;

        if (g_geProcessor.isRunning() && (i % 16 == 0)) {
            gpuStep();
        }
    }
    
    g_frameCount++;
    g_totalInstructions += executedThisFrame;
    
    std::ostringstream ss;
    ss << "Frame #" << g_frameCount << " rendered (" << executedThisFrame << " MIPS instrs executed)";
    
    pthread_mutex_unlock(&g_cpuMutex);
    return env->NewStringUTF(ss.str().c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_executeNativeScript(
        JNIEnv* env,
        jobject /* this */,
        jstring script) {
    const char* scriptStr = env->GetStringUTFChars(script, nullptr);
    std::string s = scriptStr ? scriptStr : "";
    if (scriptStr) env->ReleaseStringUTFChars(script, scriptStr);

    std::ostringstream ss;
    if (s.find("emu.mount ") == 0) {
        return env->NewStringUTF("Not implemented directly via script, use openIso");
    }
    if (s == "emu.imageinfo" || s == "emu.imageinfo()") {
        auto img = openGameImage();
        if (!img) return env->NewStringUTF("No image loaded");
        std::ostringstream ss_info;
        ss_info << "Format: " << img->format() << "\n"
           << "Size: " << (img->size() / 1024 / 1024) << " MB\n";
        auto cso = std::dynamic_pointer_cast<CsoReader>(img);
        if (cso) ss_info << "Block size: " << cso->blockSize() << "\nCompression: supported\n";
        ss_info << "ISO9660: OK\n";
        GameInfo info = parseIso(img);
        ss_info << "PSP_GAME: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\n"
                << "PARAM.SFO: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\n"
                << "EBOOT.BIN: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING");
        return env->NewStringUTF(ss_info.str().c_str());
    }
    if (s == "emu.gameinfo" || s == "emu.gameinfo()") {
        auto img = openGameImage();
        if (!img) return env->NewStringUTF("No image loaded");
        GameInfo info = parseIso(img);
        std::ostringstream ss_info;
        ss_info << "Title: " << info.title << "\n"
           << "Game ID: " << info.gameId << "\n"
           << "PSP_GAME: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\n"
           << "PARAM.SFO: " << (info.gameId != "UNKNOWN" ? "FOUND" : "MISSING") << "\n";
        return env->NewStringUTF(ss_info.str().c_str());
    }
    if (s == "sys.native") {
        ss << "C++ Native Memory Allocation: OK (38 MB RAM mapped)\n"
           << "Vulkan Pipeline: Ready\n"
           << "Allegrex CPU Core: Active (Branch Delay Pipeline Enabled)";
    } else if (s == "emu.cputest" || s == "emu.cputest()") {
        std::string res = runCpuAutoTests();
        ss << res;
    } else if (s == "emu.hletest" || s == "emu.hletest()") {
        std::string res = runHleAutoTests();
        ss << res;
    } else if (s == "emu.getest" || s == "emu.getest()" || s == "emu.gputest" || s == "emu.gputest()") {
        std::string res = runGeAutoTests();
        ss << res;
    } else if (s == "emu.geinfo" || s == "emu.geinfo()") {
        const GeState& st = g_pRenderer->getState();
        ss << "PSP GE Status:\n"
           << "  PC: 0x" << std::hex << g_geProcessor.getPC() << "\n"
           << "  Status: " << std::dec << g_geProcessor.getStatus() << "\n"
           << "  Framebuf: 0x" << std::hex << st.framebufAddr << " (stride=" << std::dec << st.framebufStride << ", fmt=" << st.pixelFormat << ")\n"
           << "  Depthbuf: 0x" << std::hex << st.zbufAddr << " (stride=" << std::dec << st.zbufStride << ")\n"
           << "  Vtype: 0x" << std::hex << st.vtype << " (Through=" << (st.isThrough ? "YES" : "NO") << ")\n"
           << "  ClearMode: " << (st.clearMode ? "ON" : "OFF") << " ClearColor: 0x" << std::hex << st.clearColor;
    } else if (s == "emu.gelog" || s == "emu.gelog()") {
        ss << "=== PSP GE Command Trace Log ===\n" << g_geProcessor.getTraceLog();
    } else if (s == "emu.crashreport" || s == "emu.crashdump") {
        if (g_lastCrashReport.empty()) {
            ss << "No CPU crashes recorded.";
        } else {
            ss << g_lastCrashReport;
        }
    } else if (s.rfind("core.", 0) == 0) {
        ss << "[Native C++] Executed core command: " << s;
    } else {
        ss << "[Native C++] Unrecognized native directive: " << s;
    }
    return env->NewStringUTF(ss.str().c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_saveState(
        JNIEnv* env,
        jobject /* this */,
        jint slot) {
    pthread_mutex_lock(&g_cpuMutex);
    
    if (!g_isInitialized) {
        pthread_mutex_unlock(&g_cpuMutex);
        return JNI_FALSE;
    }
    
    mkdir(g_savesDir.c_str(), 0777);
    
    std::ostringstream ss;
    ss << g_savesDir << "/slot_" << slot << ".nss";
    
    FILE* fp = fopen(ss.str().c_str(), "wb");
    if (!fp) {
        pthread_mutex_unlock(&g_cpuMutex);
        return JNI_FALSE;
    }

    uint32_t magic = 0x4C53454E; // "NESL"
    uint32_t version = 2;
    fwrite(&magic, 1, sizeof(magic), fp);
    fwrite(&version, 1, sizeof(version), fp);
    fwrite(&g_cpu, 1, sizeof(MipsCpu), fp);
    fwrite(mainRAM.data(), 1, mainRAM.size(), fp);
    
    
    pthread_mutex_unlock(&g_cpuMutex);
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_loadState(
        JNIEnv* env,
        jobject /* this */,
        jint slot) {
    pthread_mutex_lock(&g_cpuMutex);
    
    if (!g_isInitialized) {
        pthread_mutex_unlock(&g_cpuMutex);
        return JNI_FALSE;
    }
    
    std::ostringstream ss;
    ss << g_savesDir << "/slot_" << slot << ".nss";
    
    FILE* fp = fopen(ss.str().c_str(), "rb");
    if (!fp) {
        pthread_mutex_unlock(&g_cpuMutex);
        return JNI_FALSE;
    }

    uint32_t magic = 0, version = 0;
    if (fread(&magic, 1, sizeof(magic), fp) != sizeof(magic)) {  pthread_mutex_unlock(&g_cpuMutex); return JNI_FALSE; }
    if (fread(&version, 1, sizeof(version), fp) != sizeof(version)) {  pthread_mutex_unlock(&g_cpuMutex); return JNI_FALSE; }
    
    if (magic != 0x4C53454E || (version != 1 && version != 2)) {  pthread_mutex_unlock(&g_cpuMutex); return JNI_FALSE; }

    fread(&g_cpu, 1, sizeof(MipsCpu), fp);
    fread(mainRAM.data(), 1, mainRAM.size(), fp);
    
    
    pthread_mutex_unlock(&g_cpuMutex);
    return JNI_TRUE;
}

JNIEXPORT jint JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_readMemory32(
        JNIEnv* env,
        jobject /* this */,
        jlong addr) {
    return internalReadMemory32((uint32_t)addr);
}

JNIEXPORT void JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_writeMemory32(
        JNIEnv* env,
        jobject /* this */,
        jlong addr,
        jint value) {
    internalWriteMemory32((uint32_t)addr, (uint32_t)value);
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeGetCpuState(
        JNIEnv* env,
        jobject /* this */) {
    std::ostringstream ss;
    ss << "{ \"pc\": " << g_cpu.pc << ", \"regs\": [";
    for(int i = 0; i < 32; i++) {
        ss << g_cpu.regs[i] << (i < 31 ? ", " : "");
    }
    ss << "] }";
    return env->NewStringUTF(ss.str().c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeGetGameInfo(
        JNIEnv* env,
        jobject /* this */) {
    if (g_gameInfo.gameId == "UNKNOWN" || g_gameInfo.title == "Unknown") {
        g_gameInfo = parseIso(openGameImage());
    }
    std::ostringstream ss;
    ss << "{ \"title\": \"" << g_gameInfo.title << "\", \"gameId\": \"" << g_gameInfo.gameId << "\", \"fileSize\": " << g_gameFileSize << " }";
    return env->NewStringUTF(ss.str().c_str());
}

JNIEXPORT void JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeGpuStep(
        JNIEnv* env,
        jobject /* this */) {
    gpuStep();
}

JNIEXPORT void JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeGpuSetDisplayList(
        JNIEnv* env,
        jobject /* this */,
        jlong addr) {
    g_geProcessor.enqueue((uint32_t)addr, 0);
}

JNIEXPORT void JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeSetSavesDir(
        JNIEnv* env,
        jobject /* this */,
        jstring path) {
    const char* pathStr = env->GetStringUTFChars(path, nullptr);
    if (pathStr) {
        g_savesDir = std::string(pathStr);
        env->ReleaseStringUTFChars(path, pathStr);
    }
}

JNIEXPORT jboolean JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeLoadElf(
        JNIEnv* env,
        jobject /* this */,
        jstring path) {
    const char* pathStr = env->GetStringUTFChars(path, nullptr);
    bool result = false;
    if (pathStr) {
        result = loadElf(std::string(pathStr));
        env->ReleaseStringUTFChars(path, pathStr);
        if (result) {
            initSyscalls();
            g_isInitialized = true;
            g_frameCount = 0;
            g_totalInstructions = 0;
            g_startTime = std::chrono::steady_clock::now();
        }
    }
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jlong JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeGetIPS(
        JNIEnv* env,
        jobject /* this */) {
    if (!g_isInitialized) return 0;
    auto now = std::chrono::steady_clock::now();
    auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_startTime).count();
    if (elapsedMs <= 0) return (jlong)g_totalInstructions;
    return (jlong)((g_totalInstructions * 1000ULL) / (uint64_t)elapsedMs);
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeRunCpuTests(
        JNIEnv* env,
        jobject /* this */) {
    std::string result = runCpuAutoTests();
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeRunHleTests(
        JNIEnv* env,
        jobject /* this */) {
    std::string result = runHleAutoTests();
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeRunGeTests(
        JNIEnv* env,
        jobject /* this */) {
    std::string result = runGeAutoTests();
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeRunGpuTests(
        JNIEnv* env,
        jobject /* this */) {
    std::string result = runGeAutoTests();
    return env->NewStringUTF(result.c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeGetFramebuffer(
        JNIEnv* env,
        jobject /* this */,
        jintArray outPixels, jint width, jint height) {
    if (!outPixels) return JNI_FALSE;
    jsize len = env->GetArrayLength(outPixels);
    if (len < width * height) return JNI_FALSE;

    std::vector<uint32_t> tempBuf(width * height);
    g_pRenderer->getFramebufferRGBA(tempBuf.data(), width, height);

    env->SetIntArrayRegion(outPixels, 0, width * height, (const jint*)tempBuf.data());
    return JNI_TRUE;
}

} // extern "C"

#ifdef STANDALONE_TEST_RUNNER
int main() {
    std::cout << ">>> STARTING CPU TESTS <<<\n";
    std::string cpuResult = runCpuAutoTests();
    std::cout << cpuResult << "\n\n";

    std::cout << ">>> STARTING HLE TESTS <<<\n";
    std::string hleResult = runHleAutoTests();
    std::cout << hleResult << "\n\n";

    std::cout << ">>> STARTING GPU/GE TESTS <<<\n";
    std::string geResult = runGeAutoTests();
    std::cout << geResult << "\n\n";

    return 0;
}
#endif


extern "C" JNIEXPORT void JNICALL
Java_com_nextemu_psp_engine_NativeEmuEngine_nativeSetButtonState(JNIEnv *env, jobject thiz, jint buttons, jint lx, jint ly) {
    g_padState.buttons = (uint32_t)buttons;
    g_padState.lx = (uint8_t)lx;
    g_padState.ly = (uint8_t)ly;
}
