package com.nextemu.psp

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.nextemu.psp.data.EmulatorDatabase
import com.nextemu.psp.data.GameFile
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StartupRobolectricTest {

    @Test
    fun testAppContextAndAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NextEmu", appName)
    }

    @Test
    fun testDatabaseInitializationAndDaoOperations() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val database = EmulatorDatabase.getDatabase(context)
        assertNotNull(database)

        val dao = database.gameFileDao()
        assertNotNull(dao)

        val game = GameFile(
            id = 99,
            title = "Test Game",
            path = "/sdcard/test.iso",
            fileSize = "500 MB",
            platform = "PSP",
            genre = "Action",
            rating = 4.5f
        )

        dao.insertGame(game)
        val loaded = dao.getGameById(99)
        assertNotNull(loaded)
        assertEquals("Test Game", loaded?.title)
    }
}
