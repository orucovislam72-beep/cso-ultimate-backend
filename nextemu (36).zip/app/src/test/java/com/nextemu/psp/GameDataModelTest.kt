package com.nextemu.psp

import com.nextemu.psp.data.GameFile
import com.nextemu.psp.viewmodel.PlatformFilter
import com.nextemu.psp.viewmodel.SortOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GameDataModelTest {

    @Test
    fun testGameFileCreationAndCopy() {
        val game = GameFile(
            id = 1,
            title = "God of War: Chains of Olympus",
            path = "/sdcard/PSP/GAME/GOW.ISO",
            fileSize = "1.2 GB",
            platform = "PSP",
            genre = "Action",
            rating = 4.9f,
            isFavorite = false,
            lastPlayedTimestamp = 1000L
        )

        assertEquals("God of War: Chains of Olympus", game.title)
        assertEquals("PSP", game.platform)
        assertEquals(4.9f, game.rating, 0.01f)

        val updatedGame = game.copy(isFavorite = true, lastPlayedTimestamp = 2000L)
        assertTrue(updatedGame.isFavorite)
        assertEquals(2000L, updatedGame.lastPlayedTimestamp)
    }

    @Test
    fun testPlatformFilterMatching() {
        val games = listOf(
            GameFile(id = 1, title = "Game PSP", path = "p1", fileSize = "1GB", platform = "PSP", genre = "RPG", rating = 4.5f),
            GameFile(id = 2, title = "Game PSX", path = "p2", fileSize = "500MB", platform = "PSX", genre = "Action", rating = 4.0f),
            GameFile(id = 3, title = "Game GBA", path = "p3", fileSize = "16MB", platform = "GBA", genre = "Racing", rating = 4.8f, isFavorite = true)
        )

        val pspGames = games.filter { it.platform.equals("PSP", ignoreCase = true) }
        assertEquals(1, pspGames.size)
        assertEquals("Game PSP", pspGames[0].title)

        val favGames = games.filter { it.isFavorite }
        assertEquals(1, favGames.size)
        assertEquals("Game GBA", favGames[0].title)
    }

    @Test
    fun testSortingAlgorithms() {
        val games = listOf(
            GameFile(id = 1, title = "Zelda", path = "p1", fileSize = "1GB", platform = "GBA", genre = "RPG", rating = 4.0f, lastPlayedTimestamp = 100L),
            GameFile(id = 2, title = "Apex", path = "p2", fileSize = "2GB", platform = "PSP", genre = "Action", rating = 5.0f, lastPlayedTimestamp = 300L),
            GameFile(id = 3, title = "Mario", path = "p3", fileSize = "500MB", platform = "GBA", genre = "Platformer", rating = 4.5f, lastPlayedTimestamp = 200L)
        )

        val sortedByTitle = games.sortedBy { it.title.lowercase() }
        assertEquals("Apex", sortedByTitle[0].title)
        assertEquals("Mario", sortedByTitle[1].title)
        assertEquals("Zelda", sortedByTitle[2].title)

        val sortedByRating = games.sortedByDescending { it.rating }
        assertEquals("Apex", sortedByRating[0].title)
        assertEquals("Mario", sortedByRating[1].title)
        assertEquals("Zelda", sortedByRating[2].title)

        val sortedByDate = games.sortedByDescending { it.lastPlayedTimestamp }
        assertEquals("Apex", sortedByDate[0].title)
        assertEquals("Mario", sortedByDate[1].title)
        assertEquals("Zelda", sortedByDate[2].title)
    }
}
