package com.nextemu.psp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NeslInterpreterTest {

    @Test
    fun testHelpCommand() {
        val env = mutableMapOf<String, String>()
        val result = neslExecute("help", env)
        assertTrue(result.contains("NEX-Script (NESL)"))
        assertTrue(result.contains("emu.cpu()"))
        assertTrue(result.contains("emu.gputest()"))
    }

    @Test
    fun testVariableAssignmentAndPrint() {
        val env = mutableMapOf<String, String>()
        val assignResult = neslExecute("let speed = 60", env)
        assertEquals("Set speed to 60", assignResult)
        assertEquals("60", env["speed"])

        val printResult = neslExecute("print speed", env)
        assertEquals("60", printResult)

        val printStringLiteral = neslExecute("print \"Hello NextEmu\"", env)
        assertEquals("Hello NextEmu", printStringLiteral)
    }

    @Test
    fun testSystemInfoAndClear() {
        val env = mutableMapOf<String, String>()
        env["testVar"] = "123"

        val infoResult = neslExecute("sys.info()", env)
        assertTrue(infoResult.contains("NextEmu Engine: Running"))

        val clearResult = neslExecute("sys.clear()", env)
        assertEquals("Environment cleared.", clearResult)
        assertTrue(env.isEmpty())
    }

    @Test
    fun testFpsSetting() {
        val env = mutableMapOf<String, String>()
        val fpsResult = neslExecute("emu.fps(60)", env)
        assertEquals("System FPS limit set to 60", fpsResult)
    }
}
