package com.nextemu.psp

import com.nextemu.psp.engine.NativeEmuEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InputMappingTest {

    @Test
    fun testPspButtonBitmaskValues() {
        assertEquals(0x4000, NativeEmuEngine.BTN_CROSS)
        assertEquals(0x2000, NativeEmuEngine.BTN_CIRCLE)
        assertEquals(0x8000, NativeEmuEngine.BTN_SQUARE)
        assertEquals(0x1000, NativeEmuEngine.BTN_TRIANGLE)
        assertEquals(0x0010, NativeEmuEngine.BTN_UP)
        assertEquals(0x0040, NativeEmuEngine.BTN_DOWN)
        assertEquals(0x0080, NativeEmuEngine.BTN_LEFT)
        assertEquals(0x0020, NativeEmuEngine.BTN_RIGHT)
        assertEquals(0x0100, NativeEmuEngine.BTN_L1)
        assertEquals(0x0200, NativeEmuEngine.BTN_R1)
        assertEquals(0x0008, NativeEmuEngine.BTN_START)
        assertEquals(0x0001, NativeEmuEngine.BTN_SELECT)
    }

    @Test
    fun testButtonBitmaskCombinationAndRelease() {
        var currentButtons = 0

        // Press Cross and Triangle
        currentButtons = currentButtons or NativeEmuEngine.BTN_CROSS
        currentButtons = currentButtons or NativeEmuEngine.BTN_TRIANGLE

        assertTrue((currentButtons and NativeEmuEngine.BTN_CROSS) != 0)
        assertTrue((currentButtons and NativeEmuEngine.BTN_TRIANGLE) != 0)
        assertFalse((currentButtons and NativeEmuEngine.BTN_CIRCLE) != 0)
        assertFalse((currentButtons and NativeEmuEngine.BTN_SQUARE) != 0)

        // Release Cross
        currentButtons = currentButtons and NativeEmuEngine.BTN_CROSS.inv()
        assertFalse((currentButtons and NativeEmuEngine.BTN_CROSS) != 0)
        assertTrue((currentButtons and NativeEmuEngine.BTN_TRIANGLE) != 0)

        // Release Triangle
        currentButtons = currentButtons and NativeEmuEngine.BTN_TRIANGLE.inv()
        assertEquals(0, currentButtons)
    }

    @Test
    fun testAnalogStickCoordinateClamping() {
        // Neutral position is 128, 128
        val neutralX = 128
        val neutralY = 128
        assertEquals(128, neutralX)
        assertEquals(128, neutralY)

        // Full left/up: 0, 0
        val minX = 0.coerceIn(0, 255)
        val minY = 0.coerceIn(0, 255)
        assertEquals(0, minX)
        assertEquals(0, minY)

        // Full right/down: 255, 255
        val maxX = 300.coerceIn(0, 255)
        val maxY = 300.coerceIn(0, 255)
        assertEquals(255, maxX)
        assertEquals(255, maxY)
    }
}
