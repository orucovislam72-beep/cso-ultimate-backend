import re
with open('/app/applet/app/src/main/java/com/example/engine/NativeEmuEngine.kt', 'r') as f:
    text = f.read()

text = text.replace('external fun nativeGetFramebuffer(outPixels: IntArray): Boolean',
                    'external fun nativeGetFramebuffer(outPixels: IntArray, width: Int, height: Int): Boolean')

with open('/app/applet/app/src/main/java/com/example/engine/NativeEmuEngine.kt', 'w') as f:
    f.write(text)
