import re

with open('app/src/main/java/com/nextemu/psp/GameplayScreen.kt', 'r') as f:
    text = f.read()

hud_old = """                        IconButton(onClick = { isPaused = !isPaused }) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Пауза",
                                tint = if (isPaused) Color.Yellow else Color.White
                            )
                        }"""

hud_new = """                        IconButton(onClick = {
                            val contentValues = ContentValues().apply {
                                put(MediaStore.MediaColumns.DISPLAY_NAME, "NextEmu_screenshot_${System.currentTimeMillis()}.png")
                                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NextEmu")
                            }
                            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                            if (uri != null) {
                                context.contentResolver.openOutputStream(uri)?.use { out ->
                                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                                }
                                android.widget.Toast.makeText(context, "Скриншот сохранён", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Скриншот",
                                tint = Color.White
                            )
                        }
                        IconButton(onClick = { isPaused = !isPaused }) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Пауза",
                                tint = if (isPaused) Color.Yellow else Color.White
                            )
                        }"""

if hud_old in text:
    text = text.replace(hud_old, hud_new)
else:
    print("Could not find HUD old")

with open('app/src/main/java/com/nextemu/psp/GameplayScreen.kt', 'w') as f:
    f.write(text)

