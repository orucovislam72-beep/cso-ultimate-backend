import re
with open('/app/applet/app/src/main/cpp/native-lib.cpp', 'r') as f:
    text = f.read()

old_func = """Java_com_example_engine_NativeEmuEngine_nativeGetFramebuffer(
        JNIEnv* env,
        jobject /* this */,
        jintArray outPixels) {
    if (!outPixels) return JNI_FALSE;
    jsize len = env->GetArrayLength(outPixels);
    if (len < 480 * 272) return JNI_FALSE;

    jint* buf = env->GetIntArrayElements(outPixels, nullptr);
    if (!buf) return JNI_FALSE;

    g_pRenderer->getFramebufferRGBA((uint32_t*)buf, 480, 272);

    env->ReleaseIntArrayElements(outPixels, buf, 0);
    return JNI_TRUE;
}"""

new_func = """Java_com_example_engine_NativeEmuEngine_nativeGetFramebuffer(
        JNIEnv* env,
        jobject /* this */,
        jintArray outPixels, jint width, jint height) {
    if (!outPixels) return JNI_FALSE;
    jsize len = env->GetArrayLength(outPixels);
    if (len < width * height) return JNI_FALSE;

    std::vector<uint32_t> tempBuf(width * height);
    g_pRenderer->getFramebufferRGBA(tempBuf.data(), width, height);

    env->SetIntArrayRegion(outPixels, 0, width * height, (const jint*)tempBuf.data());
    return JNI_TRUE;
}"""

if old_func in text:
    text = text.replace(old_func, new_func)
else:
    print("Could not find old_func!")

with open('/app/applet/app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(text)
