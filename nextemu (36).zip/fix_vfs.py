import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

content = content.replace('struct VfsFile {\n    bool inUse;\n    uint32_t extent;\n    uint32_t size;\n    uint32_t offset;\n    FILE* fp;\n    bool isDir;\n    std::string path;\n};',
                          'struct VfsFile {\n    bool inUse;\n    uint32_t extent;\n    uint32_t size;\n    uint32_t offset;\n    std::shared_ptr<IDiscImage> fp;\n    bool isDir;\n    std::string path;\n};')

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
