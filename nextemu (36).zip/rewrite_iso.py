import re

with open('app/src/main/cpp/native-lib.cpp', 'r') as f:
    content = f.read()

# 1. Add zlib and memory include if not there
if '<zlib.h>' not in content:
    content = content.replace('#include <jni.h>', '#include <jni.h>\n#include <zlib.h>\n#include <memory>\n#include <algorithm>')

# 2. Add IDiscImage, IsoReader, CsoReader definitions
disc_classes = """
class IDiscImage {
public:
    virtual ~IDiscImage() = default;
    virtual size_t read(uint64_t offset, void* buffer, size_t size) = 0;
    virtual uint64_t size() const = 0;
    virtual std::string format() const = 0;
};

class IsoReader : public IDiscImage {
    int fd;
    uint64_t fileSize;
public:
    IsoReader(int fd, uint64_t fileSize) : fd(fd), fileSize(fileSize) {}
    ~IsoReader() override { if (fd >= 0) close(fd); }
    size_t read(uint64_t offset, void* buffer, size_t size) override {
        if (offset >= fileSize) return 0;
        size_t toRead = std::min((uint64_t)size, fileSize - offset);
        lseek(fd, offset, SEEK_SET);
        return ::read(fd, buffer, toRead);
    }
    uint64_t size() const override { return fileSize; }
    std::string format() const override { return "ISO"; }
};

#pragma pack(push, 1)
struct CsoHeader {
    char magic[4]; // CISO
    uint32_t header_size;
    uint64_t total_bytes;
    uint32_t block_size;
    uint8_t version;
    uint8_t align;
    uint8_t reserved[2];
};
#pragma pack(pop)

class CsoReader : public IDiscImage {
    int fd;
    CsoHeader header;
    std::vector<uint32_t> index_table;
    uint32_t index_shift;
    
    uint32_t cached_block_idx = 0xFFFFFFFF;
    std::vector<uint8_t> cached_block_data;
    bool valid = false;

public:
    CsoReader(int fd) : fd(fd) {
        lseek(fd, 0, SEEK_SET);
        if (::read(fd, &header, sizeof(CsoHeader)) != sizeof(CsoHeader)) return;
        if (memcmp(header.magic, "CISO", 4) != 0) return;
        
        index_shift = header.align;
        uint32_t total_blocks = (header.total_bytes + header.block_size - 1) / header.block_size;
        index_table.resize(total_blocks + 1);
        if (::read(fd, index_table.data(), (total_blocks + 1) * sizeof(uint32_t)) != (total_blocks + 1) * sizeof(uint32_t)) return;
        
        cached_block_data.resize(header.block_size);
        valid = true;
    }
    ~CsoReader() override { if (fd >= 0) close(fd); }

    bool isValid() const { return valid; }

    size_t read(uint64_t offset, void* buffer, size_t size) override {
        if (!valid || offset >= header.total_bytes) return 0;
        size_t toRead = std::min((uint64_t)size, header.total_bytes - offset);
        size_t read_bytes = 0;
        uint8_t* out = (uint8_t*)buffer;

        while (read_bytes < toRead) {
            uint64_t current_offset = offset + read_bytes;
            uint32_t block_idx = current_offset / header.block_size;
            uint32_t block_offset = current_offset % header.block_size;
            uint32_t block_avail = header.block_size - block_offset;
            uint32_t chunk_size = std::min((uint32_t)(toRead - read_bytes), block_avail);

            if (block_idx != cached_block_idx) {
                if (!readBlock(block_idx)) break;
            }

            memcpy(out + read_bytes, cached_block_data.data() + block_offset, chunk_size);
            read_bytes += chunk_size;
        }
        return read_bytes;
    }
    uint64_t size() const override { return header.total_bytes; }
    std::string format() const override { return "CSO"; }
    uint32_t blockSize() const { return header.block_size; }

private:
    bool readBlock(uint32_t block_idx) {
        uint32_t entry = index_table[block_idx];
        uint32_t next_entry = index_table[block_idx + 1];
        
        uint32_t pos = (entry & 0x7FFFFFFF) << index_shift;
        uint32_t next_pos = (next_entry & 0x7FFFFFFF) << index_shift;
        uint32_t comp_size = next_pos - pos;
        bool is_plain = (entry & 0x80000000) != 0;

        lseek(fd, pos, SEEK_SET);

        if (is_plain) {
            if (comp_size > header.block_size) comp_size = header.block_size;
            if (::read(fd, cached_block_data.data(), comp_size) != comp_size) return false;
            cached_block_idx = block_idx;
            return true;
        } else {
            std::vector<uint8_t> comp_buf(comp_size);
            if (::read(fd, comp_buf.data(), comp_size) != comp_size) return false;

            z_stream zs;
            memset(&zs, 0, sizeof(zs));
            if (inflateInit2(&zs, -15) != Z_OK) return false;

            zs.next_in = comp_buf.data();
            zs.avail_in = comp_size;
            zs.next_out = cached_block_data.data();
            zs.avail_out = header.block_size;

            int status = inflate(&zs, Z_FINISH);
            inflateEnd(&zs);

            if (status == Z_STREAM_END || status == Z_OK) {
                cached_block_idx = block_idx;
                return true;
            }
            return false;
        }
    }
};

static std::shared_ptr<IDiscImage> g_currentImage;

static std::shared_ptr<IDiscImage> openGameImage() {
    if (g_gameFd < 0) return nullptr;
    int fd = dup(g_gameFd);
    if (fd < 0) return nullptr;

    char magic[4];
    lseek(fd, 0, SEEK_SET);
    if (::read(fd, magic, 4) == 4 && memcmp(magic, "CISO", 4) == 0) {
        auto cso = std::make_shared<CsoReader>(fd);
        if (cso->isValid()) return cso;
        return nullptr;
    }
    return std::make_shared<IsoReader>(fd, g_gameFileSize);
}
"""

content = re.sub(r'static FILE\* openGameStream\(\) \{.*?(?=\nstatic void clearGameStream)', disc_classes, content, flags=re.DOTALL)

with open('app/src/main/cpp/native-lib.cpp', 'w') as f:
    f.write(content)
